/**
 * AGAAHOST — QRIS Otomatis (per pesanan)
 * Membuat transaksi lewat server (/api/qris/create), menampilkan QR dinamis,
 * lalu mengecek status ke server sampai lunas / kedaluwarsa.
 */
(function () {
  const POLL_MS = 4000;
  const QR_LIB_URL = 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';

  let pollTimer = null;
  let countdownTimer = null;
  let currentOrder = null;
  let qrLibPromise = null;

  const $ = (id) => document.getElementById(id);

  function formatRupiah(n) {
    return 'Rp ' + Math.round(Number(n) || 0).toLocaleString('id-ID');
  }

  function loadQrLib() {
    if (window.QRCode) return Promise.resolve();
    if (!qrLibPromise) {
      qrLibPromise = new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = QR_LIB_URL;
        s.onload = resolve;
        s.onerror = () => { qrLibPromise = null; reject(new Error('Gagal memuat library QR')); };
        document.head.appendChild(s);
      });
    }
    return qrLibPromise;
  }

  function buildOverlay() {
    if ($('qris-auto-overlay')) return;
    const wrap = document.createElement('div');
    wrap.id = 'qris-auto-overlay';
    wrap.className = 'qris-overlay';
    wrap.setAttribute('role', 'dialog');
    wrap.setAttribute('aria-modal', 'true');
    wrap.setAttribute('aria-labelledby', 'qris-auto-title');
    wrap.innerHTML = `
      <div class="qris-sheet">
        <button type="button" class="qris-close" id="qris-close" aria-label="Tutup">✕</button>
        <h3 id="qris-auto-title">Bayar QRIS</h3>
        <p class="qris-order">Order <span id="qris-order-id">-</span></p>
        <div class="qris-qr-wrap"><div id="qris-qr"></div></div>
        <div class="qris-amount">Total yang harus dibayar
          <strong id="qris-total">-</strong>
        </div>
        <div class="qris-meta" id="qris-meta"></div>
        <div class="qris-status" id="qris-status" role="status" data-state="loading">Menyiapkan QRIS…</div>
        <div class="qris-countdown" id="qris-countdown"></div>
        <div class="qris-actions">
          <a class="qris-btn secondary" id="qris-open-link" target="_blank" rel="noopener noreferrer" hidden>Buka Halaman Bayar</a>
          <button type="button" class="qris-btn" id="qris-copy" hidden>Salin Kode QRIS</button>
          <button type="button" class="qris-btn" id="qris-retry" hidden>Coba Lagi</button>
        </div>
        <p class="qris-note">Pembayaran dicek otomatis. Jangan tutup halaman sampai status berubah menjadi LUNAS. Scan QR memakai aplikasi e-wallet atau m-banking apa pun.</p>
      </div>`;
    document.body.appendChild(wrap);

    $('qris-close').addEventListener('click', closeAutoQris);
    wrap.addEventListener('click', (e) => { if (e.target === wrap) closeAutoQris(); });
    $('qris-copy').addEventListener('click', async () => {
      if (!currentOrder || !currentOrder.qrisData) return;
      try {
        await navigator.clipboard.writeText(currentOrder.qrisData);
        $('qris-copy').textContent = 'Tersalin ✓';
      } catch (_) {
        $('qris-copy').textContent = 'Gagal salin, tahan kode manual';
      }
    });
    $('qris-retry').addEventListener('click', () => {
      if (lastRequest) startAutoQris(lastRequest);
    });
  }

  let lastRequest = null;

  function setStatus(text, state) {
    const el = $('qris-status');
    el.textContent = text;
    el.setAttribute('data-state', state);
  }

  function stopTimers() {
    clearInterval(pollTimer);
    clearInterval(countdownTimer);
    pollTimer = null;
    countdownTimer = null;
  }

  function renderQr(text) {
    const box = $('qris-qr');
    box.innerHTML = '';
    if (!text) return;
    if (!window.QRCode) {
      showQrFallback(box);
      return;
    }
    try {
      // qrcodejs (davidshimjs) — hasil berupa canvas/img
      new window.QRCode(box, {
        text,
        width: 220,
        height: 220,
        colorDark: '#0B0A1A',
        colorLight: '#FFFFFF',
        correctLevel: window.QRCode.CorrectLevel.M,
      });
    } catch (err) {
      showQrFallback(box);
    }
  }

  function showQrFallback(box) {
    const note = document.createElement('p');
    note.className = 'qris-qr-fallback';
    note.textContent = 'QR tidak bisa ditampilkan. Buka halaman bayar atau salin kode QRIS di bawah.';
    box.appendChild(note);
    const link = $('qris-open-link');
    if (link && currentOrder && currentOrder.paymentUrl) { link.href = currentOrder.paymentUrl; link.hidden = false; }
    $('qris-copy').hidden = !(currentOrder && currentOrder.qrisData);
  }

  function startCountdown(expiredAt) {
    clearInterval(countdownTimer);
    const end = Date.parse(expiredAt);
    if (!end) { $('qris-countdown').textContent = ''; return; }
    const tick = () => {
      const left = Math.max(0, end - Date.now());
      const m = Math.floor(left / 60000);
      const s = Math.floor((left % 60000) / 1000);
      $('qris-countdown').textContent = left > 0
        ? `Berlaku sampai ${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')} lagi`
        : 'QR sudah kedaluwarsa';
      if (left <= 0) clearInterval(countdownTimer);
    };
    tick();
    countdownTimer = setInterval(tick, 1000);
  }

  function showError(message) {
    stopTimers();
    setStatus(message, 'error');
    $('qris-retry').hidden = false;
  }

  async function postJson(url, body) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.success === false) {
      throw new Error(data.error || `Gagal (HTTP ${res.status})`);
    }
    return data;
  }

  function applyOrder(order) {
    currentOrder = order;
    $('qris-order-id').textContent = order.orderId;
    $('qris-total').textContent = formatRupiah(order.totalPayment);
    $('qris-meta').innerHTML = [
      `Produk: ${escape(order.productName)}${order.variantName ? ' — ' + escape(order.variantName) : ''}`,
      `Harga: ${formatRupiah(order.amount)} + biaya ${formatRupiah(order.fee)}`,
      `Pemesan: ${escape(order.buyerName)}`,
    ].join('<br>');
    const link = $('qris-open-link');
    if (order.paymentUrl) { link.href = order.paymentUrl; link.hidden = false; }
    startCountdown(order.expiredAt);
  }

  function escape(text) {
    const d = document.createElement('div');
    d.textContent = text || '';
    return d.innerHTML;
  }

  function onPaid(order) {
    stopTimers();
    setStatus('✅ LUNAS — pembayaran diterima. Terima kasih!', 'paid');
    $('qris-countdown').textContent = '';
    $('qris-open-link').hidden = true;
    if (typeof window.sendOrderNotification === 'function') {
      try { window.sendOrderNotification(); } catch (_) {}
    }
    if (typeof window.showDeployToast === 'function') {
      window.showDeployToast('Pembayaran QRIS ' + order.orderId + ' berhasil.', 'success');
    }
  }

  async function pollOnce() {
    if (!currentOrder) return;
    try {
      const res = await fetch('/api/qris/status/' + encodeURIComponent(currentOrder.orderId), { cache: 'no-store' });
      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data.error || 'Gagal cek status');
      const o = data.order;
      currentOrder = o;
      if (o.status === 'paid') return onPaid(o);
      if (o.status === 'expired') { stopTimers(); setStatus('QR kedaluwarsa. Buat pesanan baru untuk membayar.', 'expired'); $('qris-retry').hidden = false; return; }
      if (o.status === 'canceled') { stopTimers(); setStatus('Transaksi dibatalkan.', 'canceled'); $('qris-retry').hidden = false; return; }
      setStatus('⏳ Menunggu pembayaran… (cek otomatis)', 'waiting');
    } catch (err) {
      // Jaringan sesaat putus: coba lagi di polling berikutnya
      setStatus('⏳ Menunggu pembayaran… (koneksi sempat terputus, mencoba lagi)', 'waiting');
    }
  }

  /**
   * Mulai pembayaran QRIS otomatis.
   * @param {{productId:string, variantId?:string, buyerName:string, notes?:string}} req
   */
  async function startAutoQris(req) {
    buildOverlay();
    lastRequest = req;
    stopTimers();
    currentOrder = null;
    $('qris-retry').hidden = true;
    $('qris-open-link').hidden = true;
    $('qris-copy').hidden = true;
    $('qris-copy').textContent = 'Salin Kode QRIS';
    $('qris-qr').innerHTML = '';
    $('qris-countdown').textContent = '';
    $('qris-total').textContent = '-';
    $('qris-meta').textContent = '';
    setStatus('Menyiapkan QRIS…', 'loading');
    $('qris-auto-overlay').classList.add('active');
    document.body.style.overflow = 'hidden';

    try {
      const [{ order }] = await Promise.all([postJson('/api/qris/create', req), loadQrLib().catch(() => null)]);
      applyOrder(order);
      renderQr(order.qrisData || order.paymentUrl);
      setStatus('⏳ Menunggu pembayaran… (cek otomatis)', 'waiting');
      pollTimer = setInterval(pollOnce, POLL_MS);
      pollOnce();
    } catch (err) {
      showError('Gagal membuat QRIS: ' + err.message);
    }
  }

  function closeAutoQris() {
    stopTimers();
    const ov = $('qris-auto-overlay');
    if (ov) ov.classList.remove('active');
    document.body.style.overflow = '';
  }

  /** Di modal pembayaran, QRIS statis lama sudah dihapus: arahkan ke checkout. */
  function replaceStaticQrisNotice() {
    const notice = document.createElement('p');
    notice.className = 'qris-auto-notice';
    notice.textContent = 'QRIS sekarang dibuat otomatis untuk setiap pesanan. Pilih produk, isi nama, lalu pilih "QRIS (All Payment)" saat checkout.';
    const target = $('payment-card-dana') || document.querySelector('.payment-modal-sheet .modal-body');
    if (target && target.parentNode) target.parentNode.insertBefore(notice, target);
  }

  window.startAutoQris = startAutoQris;
  window.closeAutoQris = closeAutoQris;

  document.addEventListener('DOMContentLoaded', replaceStaticQrisNotice);
})();
