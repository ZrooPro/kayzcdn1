/**
 * AGAAHOST — Main Application Engine
 * Dynamic Data-Driven Rendering, Category Filters, Instant Search, & Variant Switcher
 */

let productsData = [];
let appConfig = null;
let currentFilter = 'all';
let currentSearch = '';

document.addEventListener('DOMContentLoaded', async () => {
  await loadAppData();
  setupEventListeners();
  renderProducts();
  setupScrollEffects();
  trackVisitor();
  initDeployModule();
});

async function loadAppData() {
  try {
    // Muat konfigurasi toko dengan cache buster
    const configRes = await fetch('js/config.json?v=' + Date.now());
    appConfig = await configRes.json();
    initCheckout(appConfig);
    applyConfig(appConfig);
  } catch (err) {
    console.error('Gagal memuat config:', err);
    // Agar checkout tetap jalan walau config gagal dimuat
    if (!appConfig) { appConfig = {}; initCheckout(appConfig); }
  }

  try {
    // Muat data produk dengan cache buster agar selalu termuat instan
    const prodRes = await fetch('js/products.json?v=' + Date.now());
    productsData = await prodRes.json();
  } catch (err) {
    console.error('Gagal memuat products:', err);
  }
}
function applyConfig(config) {
  // Set foto logo di profil header
  const avatarImg = document.getElementById('header-logo-img');
  if (avatarImg && config.logo) {
    avatarImg.src = config.logo;
  }

  const footerAvatar = document.getElementById('footer-logo-img');
  if (footerAvatar && config.logo) {
    footerAvatar.src = config.logo;
  }

  const footerSlogan = document.querySelector('.footer-slogan');
  if (footerSlogan && config.slogan) {
    footerSlogan.textContent = config.slogan;
  }

  // Set hero WA link
  const heroWaBtn = document.getElementById('btn-hero-wa');
  if (heroWaBtn && config.contact && config.contact.whatsapp) {
    const phone = String(config.contact.whatsapp).replace(/\D/g, '');
    const welcomeMsg = `Halo AGAAHOST, saya ingin tanya-tanya mengenai layanan server/bot.`;
    heroWaBtn.href = `https://wa.me/${phone}?text=${encodeURIComponent(welcomeMsg)}`;
  }

  // Populate payment method dropdown di modal checkout (wajib pilih QRIS / DANA)
  const methodSelect = document.getElementById('payment-method');
  if (methodSelect && config.paymentMethods) {
    methodSelect.innerHTML = '';
    
    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.textContent = '-- Pilih Pembayaran (QRIS / DANA) --';
    placeholder.disabled = true;
    placeholder.selected = true;
    methodSelect.appendChild(placeholder);

    config.paymentMethods.forEach(method => {
      const opt = document.createElement('option');
      opt.value = method;
      opt.textContent = method;
      methodSelect.appendChild(opt);
    });
  }
}
function setupEventListeners() {
  // Global category selector helper for Landing Page Gateway
  window.selectStoreCategory = function(categoryKey) {
    currentFilter = categoryKey;
    const catChips = document.querySelectorAll('.cat-chip');
    catChips.forEach(chip => {
      const isTarget = chip.getAttribute('data-category') === categoryKey;
      chip.classList.toggle('active', isTarget);
      chip.setAttribute('aria-selected', isTarget ? 'true' : 'false');
    });
    renderProducts();

    // Smooth scroll to catalog section with header offset
    const catalogSection = document.getElementById('catalog-section');
    if (catalogSection) {
      const targetPos = catalogSection.getBoundingClientRect().top + window.pageYOffset - 75;
      window.scrollTo({ top: Math.max(0, targetPos), behavior: 'smooth' });
    }
  };

  // Category tabs with daisyUI segmented indicator
  const catChips = document.querySelectorAll('.cat-chip');
  catChips.forEach(chip => {
    chip.addEventListener('click', (e) => {
      catChips.forEach(c => {
        c.classList.remove('active');
        c.setAttribute('aria-selected', 'false');
      });
      chip.classList.add('active');
      chip.setAttribute('aria-selected', 'true');
      currentFilter = chip.getAttribute('data-category');
      renderProducts();
    });
  });

  // Search input with auto clear button and instant filter
  const searchInput = document.getElementById('search-input');
  const searchClearBtn = document.getElementById('search-clear-btn');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      currentSearch = e.target.value.toLowerCase().trim();
      if (searchClearBtn) {
        searchClearBtn.style.display = searchInput.value ? 'flex' : 'none';
      }
      renderProducts();
    });

    if (searchClearBtn) {
      searchClearBtn.addEventListener('click', () => {
        searchInput.value = '';
        currentSearch = '';
        searchClearBtn.style.display = 'none';
        searchInput.focus();
        renderProducts();
      });
    }

    // Keyboard shortcut: Ctrl+K or / to focus search
    window.addEventListener('keydown', (e) => {
      const activeTag = document.activeElement ? document.activeElement.tagName.toLowerCase() : '';
      const isInputFocused = activeTag === 'input' || activeTag === 'textarea' || activeTag === 'select';
      
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        searchInput.focus();
        searchInput.select();
      } else if (e.key === '/' && !isInputFocused) {
        e.preventDefault();
        searchInput.focus();
      } else if (e.key === 'Escape' && document.activeElement === searchInput) {
        searchInput.blur();
      }
    });
  }

  // SPA View Routing Setup
  initRouter();

  // Client-Side Anti-Inspect Shield
  setupAntiInspectShield();
}

/**
 * SPA ROUTER BERBASIS HASH
 * Mendukung URL langsung: #store, #sc-free, #komunitas
 * Sinkron dengan Desktop Top Nav & Mobile Bottom Nav
 */
const VALID_VIEWS = ['store', 'sc-free', 'deploy', 'tools', 'komunitas'];

function initRouter() {
  // 1. Tangani klik desktop navigation
  const desktopLinks = document.querySelectorAll('.desktop-nav-link');
  desktopLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetView = link.getAttribute('data-view');
      switchView(targetView, true);
    });
  });

  // 2. Tangani klik mobile bottom navigation
  const mobileNavItems = document.querySelectorAll('.nav-item');
  mobileNavItems.forEach(item => {
    item.addEventListener('click', () => {
      const targetView = item.getAttribute('data-target');
      switchView(targetView, true);
    });
  });

  // 3. Listener perubahan URL hash (tombol Back / Forward di browser)
  window.addEventListener('hashchange', () => {
    const hash = window.location.hash.replace('#', '').trim().toLowerCase();
    if (['payment', 'pembayaran', 'qris', 'dana'].includes(hash)) {
      if (typeof window.openPaymentModal === 'function') {
        window.openPaymentModal(hash === 'qris' ? 'qris' : (hash === 'dana' ? 'dana' : 'all'));
      }
      return;
    }
    if (VALID_VIEWS.includes(hash)) {
      switchView(hash, false);
    }
  });

  // 4. Inisialisasi rute saat halaman pertama kali dibuka
  const initialHash = window.location.hash.replace('#', '').trim().toLowerCase();
  if (['payment', 'pembayaran', 'qris', 'dana'].includes(initialHash)) {
    switchView('store', false);
    setTimeout(() => {
      if (typeof window.openPaymentModal === 'function') {
        window.openPaymentModal(initialHash === 'qris' ? 'qris' : (initialHash === 'dana' ? 'dana' : 'all'));
      }
    }, 250);
  } else if (VALID_VIEWS.includes(initialHash)) {
    switchView(initialHash, false);
  } else {
    switchView('store', false);
  }
}
function switchView(viewId, updateHash = true) {
  const targetId = VALID_VIEWS.includes(viewId) ? viewId : 'store';

  if (document.body) {
    document.body.classList.toggle('view-deploy-active', targetId === 'deploy');
  }

  // Sembunyikan semua view, tampilkan view aktif
  const views = document.querySelectorAll('.app-view');
  views.forEach(v => {
    const isTarget = v.getAttribute('data-view') === targetId || v.id === `view-${targetId}`;
    if (isTarget) {
      v.classList.add('active');
    } else {
      v.classList.remove('active');
    }
  });

  // Sinkronkan Desktop Nav
  const desktopLinks = document.querySelectorAll('.desktop-nav-link');
  desktopLinks.forEach(link => {
    if (link.getAttribute('data-view') === targetId) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  // Sinkronkan Mobile Bottom Nav
  const mobileNavItems = document.querySelectorAll('.nav-item');
  mobileNavItems.forEach(item => {
    if (item.getAttribute('data-target') === targetId) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  });

  // Update hash pada URL tanpa reload
  if (updateHash) {
    if (window.location.hash !== `#${targetId}`) {
      window.location.hash = targetId;
    }
  }

  // Jika membuka tab deploy, cek akses privat & refresh status jika unlocked
  if (targetId === 'deploy') {
    initDeployGate();
    if (isDeployGateUnlocked()) {
      refreshDeployStatus();
      if (!deployPollingInterval) {
        deployPollingInterval = setInterval(refreshDeployStatus, 1200);
      }
    }
  } else {
    if (deployPollingInterval) {
      clearInterval(deployPollingInterval);
      deployPollingInterval = null;
    }
  }

  // Jika membuka tab tools hub, periksa status hidup/mati layanan
  if (targetId === 'tools') {
    if (typeof window.checkToolsStatus === 'function') {
      window.checkToolsStatus();
    }
  }

  // Auto scroll ke paling atas dengan mulus
  window.scrollTo({ top: 0, behavior: 'instant' });
}

function focusSearchInput() {
  // Pindah ke tab store jika belum di store
  switchView('store', true);
  setTimeout(() => {
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
      searchInput.focus();
      searchInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, 100);
}

/**
 * CLIENT-SIDE ANTI-INSPECT SHIELD
 * Mencegah inspect element, view-source shortcut, dan download kode sembarangan
 */
function setupAntiInspectShield() {
  // 1. Blokir Klik Kanan (Context Menu)
  document.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    return false;
  });

  // 2. Blokir Shortcut Keyboard Terkait Inspect & View Source
  document.addEventListener('keydown', (e) => {
    // F12
    if (e.key === 'F12' || e.keyCode === 123) {
      e.preventDefault();
      return false;
    }
    // Ctrl + Shift + I (Inspect)
    // Ctrl + Shift + J (Console)
    // Ctrl + Shift + C (Element Inspect)
    if (e.ctrlKey && e.shiftKey && ['I', 'i', 'J', 'j', 'C', 'c'].includes(e.key)) {
      e.preventDefault();
      return false;
    }
    // Ctrl + U (View Source)
    // Ctrl + S (Save Page)
    if (e.ctrlKey && ['U', 'u', 'S', 's'].includes(e.key)) {
      e.preventDefault();
      return false;
    }
  });

  // Pesan keamanan di console untuk orang yang memaksa buka devtools
  try {
    console.clear();
    console.log(
      '%c[AGAAHOST SHIELD] Akses kode sumber dilindungi. Seluruh transaksi resmi tercatat di sistem kami.',
      'color: #FF4655; font-size: 14px; font-weight: bold;'
    );
  } catch (err) {}
}

/**
 * VISITOR TELEMETRY & LOGGING
 * Mencatat kunjungan baru ke Telegram Bot Owner (1x per sesi agar tidak spam)
 */
function trackVisitor() {
  try {
    // Cek apakah pengunjung sudah tercatat dalam sesi browser ini
    const alreadyTracked = sessionStorage.getItem('af_store_visited');
    if (alreadyTracked) return;

    // Kunci sesi untuk mencegah spam saat refresh atau ganti tab
    sessionStorage.setItem('af_store_visited', String(Date.now()));

    const payload = {
      view: window.location.hash.replace('#', '') || 'store',
      referrer: document.referrer || '',
      screen: `${window.screen.width}x${window.screen.height}`,
      userAgent: navigator.userAgent
    };

    fetch('/api/visitor-log', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      keepalive: true
    }).catch(() => {});
  } catch (err) {}
}

function renderProducts() {
  const container = document.getElementById('product-grid-container');
  if (!container) return;

  container.innerHTML = '';

  // Kontrol visibilitas tombol & section Perbandingan Panel Legal vs DO:
  // Hanya tampilkan jika kategori yang dipilih adalah kategori panel ('panel_legal' atau 'panel_do')
  const compareWrap = document.querySelector('.compare-action-wrap');
  if (compareWrap) {
    const isPanelCategory = (currentFilter === 'panel_legal' || currentFilter === 'panel_do');
    compareWrap.style.display = isPanelCategory ? 'block' : 'none';
  }
  const compareSection = document.getElementById('compare-panel-section');
  if (compareSection) {
    const isPanelCategory = (currentFilter === 'panel_legal' || currentFilter === 'panel_do');
    compareSection.style.display = isPanelCategory ? 'block' : 'none';
  }
  const energyDivider = document.querySelector('.deathnote-energy-line');
  if (energyDivider) {
    const isPanelCategory = (currentFilter === 'panel_legal' || currentFilter === 'panel_do');
    energyDivider.style.display = isPanelCategory ? 'block' : 'none';
  }

  const filtered = productsData.filter(p => {
    const matchCategory = currentFilter === 'all' || p.category === currentFilter;
    const matchSearch = !currentSearch || 
      p.name.toLowerCase().includes(currentSearch) || 
      (p.subtitle && p.subtitle.toLowerCase().includes(currentSearch)) ||
      (p.categoryLabel && p.categoryLabel.toLowerCase().includes(currentSearch));
    return matchCategory && matchSearch;
  });

  if (filtered.length === 0) {
    const emptyBox = document.createElement('div');
    emptyBox.className = 'glass-panel';
    emptyBox.style.padding = '30px';
    emptyBox.style.textAlign = 'center';
    emptyBox.style.borderRadius = '16px';
    emptyBox.innerHTML = `
      <p style="font-size: 1rem; font-weight: 700; color: #94A3B8; margin-bottom: 6px;">Produk tidak ditemukan</p>
      <p style="font-size: 0.8rem; color: #64748B;">Coba gunakan kata kunci pencarian yang lain.</p>
    `;
    container.appendChild(emptyBox);
    return;
  }

  filtered.forEach((product, idx) => {
    const card = createProductCard(product, idx);
    container.appendChild(card);
  });
}

function createProductCard(product, index = 0) {
  const card = document.createElement('div');
  card.className = `product-card card-type-${product.categoryType || 'do'}`;
  card.style.animationDelay = `${index * 60}ms`;

  // Default selected variant
  let currentVariant = (product.variants && product.variants.length > 0) ? product.variants[0] : null;

  // 1. Top Row: Badges
  const topRow = document.createElement('div');
  topRow.className = 'card-top-row';

  // Category Badge with Mini Lucide SVG
  const catBadge = document.createElement('span');
  catBadge.className = `badge-category badge-${product.categoryType || 'do'}`;
  let catIconSvg = '';
  if (product.categoryType === 'legal') {
    catIconSvg = `<svg class="mini-cat-svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg>`;
  } else if (product.categoryType === 'do') {
    catIconSvg = `<svg class="mini-cat-svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="8" x="2" y="2" rx="2" ry="2"/><rect width="20" height="8" x="2" y="14" rx="2" ry="2"/><line x1="6" x2="6.01" y1="6" y2="6"/><line x1="6" x2="6.01" y1="18" y2="18"/></svg>`;
  } else if (product.categoryType === 'script') {
    catIconSvg = `<svg class="mini-cat-svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg>`;
  } else {
    catIconSvg = `<svg class="mini-cat-svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/></svg>`;
  }
  catBadge.innerHTML = `${catIconSvg} <span>${escapeHtml(product.categoryLabel || 'AGAAHOST')}</span>`;
  topRow.appendChild(catBadge);

  // Status Badge with Radar Pulse Ping
  const statusBadge = document.createElement('span');
  const isReady = product.status === 'ready';
  statusBadge.className = `badge-status ${isReady ? 'ready' : 'habis'}`;
  statusBadge.innerHTML = isReady 
    ? `<span class="badge-dot-wrap"><span class="badge-dot-ping"></span><span class="badge-dot"></span></span> Ready`
    : `<span class="badge-dot habis"></span> Habis`;
  topRow.appendChild(statusBadge);

  card.appendChild(topRow);

  // 2. Title & Subtitle
  const title = document.createElement('h3');
  title.className = 'card-product-title';
  title.textContent = (product.name || '').replace('(Versi Terbaru)', '(Versi\u00A0Terbaru)');
  card.appendChild(title);

  const sub = document.createElement('p');
  sub.className = 'card-product-subtitle';
  sub.textContent = product.subtitle || '';
  card.appendChild(sub);

  // 3. Price Display (Cyber Price Badge Box - High Visual Hierarchy)
  const priceRow = document.createElement('div');
  priceRow.className = 'card-price-row';

  const priceBadge = document.createElement('div');
  priceBadge.className = 'card-price-badge';

  const priceLabelTag = document.createElement('span');
  priceLabelTag.className = 'card-price-label-tag';
  priceLabelTag.textContent = 'HARGA';

  const priceMainWrap = document.createElement('div');
  priceMainWrap.className = 'card-price-main-wrap';

  const priceVal = document.createElement('span');
  priceVal.className = 'card-price-value';
  priceVal.textContent = currentVariant ? currentVariant.priceFormatted : (product.priceFormatted || 'Rp 0');

  const pricePeriod = document.createElement('span');
  pricePeriod.className = 'card-price-period';
  pricePeriod.textContent = (currentVariant && currentVariant.period) ? `/ ${currentVariant.period}` : '';

  priceMainWrap.appendChild(priceVal);
  priceMainWrap.appendChild(pricePeriod);
  priceBadge.appendChild(priceLabelTag);
  priceBadge.appendChild(priceMainWrap);
  priceRow.appendChild(priceBadge);
  card.appendChild(priceRow);

  // 6. Action Button Prep (deklarasikan lebih awal agar bisa diupdate saat varian diklik)
  const orderBtn = document.createElement('button');
  orderBtn.type = 'button';
  orderBtn.className = 'btn-card-order cyber-order-btn';
  const initialPriceText = currentVariant ? currentVariant.priceFormatted : (product.priceFormatted || '');
  orderBtn.innerHTML = `
    <svg class="order-btn-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
      <circle cx="8" cy="21" r="1"/>
      <circle cx="19" cy="21" r="1"/>
      <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/>
    </svg>
    <span class="order-btn-text">Order Sekarang <span class="order-btn-price-tag">• ${escapeHtml(initialPriceText)}</span></span>
  `;
  orderBtn.addEventListener('click', () => {
    openModalCheckout(product, currentVariant ? currentVariant.id : null);
  });

  // 4. Variant Selector Chips
  if (product.variants && product.variants.length > 1) {
    const variantBox = document.createElement('div');
    variantBox.className = 'variant-selector-box';

    const vLabel = document.createElement('span');
    vLabel.className = 'variant-label';
    vLabel.textContent = 'Pilih Varian:';
    variantBox.appendChild(vLabel);

    const isRoleGrid = product.categoryType === 'script' || (product.variants.length <= 4 && product.variants.some(v => v.name.length > 8));
    const chipsGrid = document.createElement('div');
    chipsGrid.className = `variant-chips-grid ${isRoleGrid ? 'grid-2-cols' : ''}`;

    product.variants.forEach(variant => {
      const chipBtn = document.createElement('button');
      chipBtn.type = 'button';
      chipBtn.className = `variant-chip-btn ${variant.id === currentVariant.id ? 'active' : ''} ${variant.badge ? 'has-badge' : ''}`;

      let labelHtml = '';
      const match = variant.name.match(/^(.+?)\s*\((.+?)\)$/);
      if (match && isRoleGrid) {
        labelHtml = `<span>${escapeHtml(match[1])}</span> <span class="chip-price-tag">(${escapeHtml(match[2])})</span>`;
      } else {
        labelHtml = `<span>${escapeHtml(variant.name)}</span>`;
      }

      if (variant.badge) {
        labelHtml += `<span class="chip-floating-badge">${escapeHtml(variant.badge)}</span>`;
      }

      chipBtn.innerHTML = labelHtml;

      chipBtn.addEventListener('click', () => {
        // Update active variant
        currentVariant = variant;
        chipsGrid.querySelectorAll('.variant-chip-btn').forEach(btn => btn.classList.remove('active'));
        chipBtn.classList.add('active');

        // Update harga di kartu secara instan
        priceVal.textContent = variant.priceFormatted;
        pricePeriod.textContent = variant.period ? `/ ${variant.period}` : '';

        // Flash pulse highlight pada badge harga agar user sadar harga berganti
        priceBadge.classList.add('price-badge-pulse');
        setTimeout(() => priceBadge.classList.remove('price-badge-pulse'), 350);

        // Update harga di tombol CTA order
        const priceTagSpan = orderBtn.querySelector('.order-btn-price-tag');
        if (priceTagSpan) {
          priceTagSpan.textContent = `• ${variant.priceFormatted}`;
        }

        // Update feature box (specs atau benefits) secara instan
        renderFeatureBox(featureBox, variant);
      });

      chipsGrid.appendChild(chipBtn);
    });

    variantBox.appendChild(chipsGrid);
    card.appendChild(variantBox);
  }

  // 5. Specs / Benefits Box
  const featureBox = document.createElement('div');
  renderFeatureBox(featureBox, currentVariant);
  card.appendChild(featureBox);

  // Append Action Button (Order Sekarang)
  card.appendChild(orderBtn);

  return card;
}

function renderFeatureBox(boxElement, variant) {
  boxElement.innerHTML = '';
  if (!variant) return;

  // JIKA VARIAN MEMILIKI BENEFIT (Reseller, Admin, PT Panel, dan Script Bot)
  if (variant.benefits && Array.isArray(variant.benefits) && variant.benefits.length > 0) {
    boxElement.className = 'benefits-grid-2x2';
    variant.benefits.forEach(text => {
      const cell = document.createElement('div');
      cell.className = 'benefit-cell';
      cell.innerHTML = `
        <svg class="benefit-cell-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
          <polyline points="22 4 12 14.01 9 11.01"/>
        </svg>
        <span class="benefit-cell-text">${escapeHtml(text)}</span>
      `;
      boxElement.appendChild(cell);
    });
    return;
  }

  // JIKA VARIAN HARDWARE (RAM, CPU, DISK, DUKUNGAN)
  if (variant.specs) {
    boxElement.className = 'specs-grid-2x2';
    const specKeys = [
      { 
        key: 'ram', 
        label: 'RAM', 
        icon: `<svg class="spec-cell-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="16" height="16" x="4" y="4" rx="2"/><rect width="6" height="6" x="9" y="9" rx="1"/><path d="M15 2v2"/><path d="M15 20v2"/><path d="M2 15h2"/><path d="M2 9h2"/><path d="M20 15h2"/><path d="M20 9h2"/><path d="M9 2v2"/><path d="M9 20v2"/></svg>` 
      },
      { 
        key: 'cpu', 
        label: 'CPU', 
        icon: `<svg class="spec-cell-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/></svg>` 
      },
      { 
        key: 'disk', 
        label: 'Disk', 
        icon: `<svg class="spec-cell-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" x2="2" y1="12" y2="12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/><line x1="6" x2="6.01" y1="16" y2="16"/><line x1="10" x2="10.01" y1="16" y2="16"/></svg>` 
      },
      { 
        key: 'support', 
        label: 'Dukungan', 
        icon: `<svg class="spec-cell-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>` 
      }
    ];

    specKeys.forEach(item => {
      const val = variant.specs[item.key] || '-';
      const cell = document.createElement('div');
      cell.className = 'spec-cell';
      cell.innerHTML = `
        ${item.icon}
        <div class="spec-cell-texts">
          <span class="spec-cell-label">${item.label}</span>
          <span class="spec-cell-value">${escapeHtml(val)}</span>
        </div>
      `;
      boxElement.appendChild(cell);
    });
  }
}
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

/**
 * Red-Tech Scroll Effects & Intersection Observer
 */
function setupScrollEffects() {
  // 1. Header Solidification on Scroll
  const header = document.querySelector('.app-header');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 24) {
      header?.classList.add('scrolled');
    } else {
      header?.classList.remove('scrolled');
    }
  }, { passive: true });

  // 2. IntersectionObserver for Reveal Elements (Smooth Scroll Reveal)
  const revealElements = document.querySelectorAll('.reveal-on-scroll');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -30px 0px' });

    revealElements.forEach(el => observer.observe(el));
  } else {
    revealElements.forEach(el => el.classList.add('is-visible'));
  }

  // 3. Cinematic Red Reveal Auto-Cleanup (eliminasi overhead DOM)
  const sweepEl = document.getElementById('cinematic-sweep');
  if (sweepEl) {
    setTimeout(() => {
      sweepEl.remove();
    }, 1400);
  }
}
/**
 * ======================================================================
 * WEB DEPLOY BOT ENGINE INTEGRATION (INSTAN CLOUD DEPLOY - TANPA LOGIN)
 * ======================================================================
 */
let deployPollingInterval = null;
let isDeployBusy = false;

const deployStatusMap = {
  stopped: { label: 'Berhenti', badgeStyle: 'background:rgba(148,163,184,0.1); color:#94A3B8; border:1px solid rgba(148,163,184,0.25);' },
  queued: { label: 'Mengantre', badgeStyle: 'background:rgba(59,130,246,0.12); color:#60A5FA; border:1px solid rgba(59,130,246,0.3);' },
  starting: { label: 'Memulai', badgeStyle: 'background:rgba(59,130,246,0.12); color:#60A5FA; border:1px solid rgba(59,130,246,0.3);' },
  connecting: { label: 'Menghubungkan', badgeStyle: 'background:rgba(59,130,246,0.12); color:#60A5FA; border:1px solid rgba(59,130,246,0.3);' },
  pairing: { label: 'Menunggu Pairing', badgeStyle: 'background:rgba(245,158,11,0.12); color:#FBBF24; border:1px solid rgba(245,158,11,0.35); animation:pulseDot 1.5s infinite;' },
  online: { label: 'Terhubung Online', badgeStyle: 'background:rgba(34,197,94,0.12); color:#4ADE80; border:1px solid rgba(34,197,94,0.3);' },
  reconnecting: { label: 'Menghubungkan Ulang', badgeStyle: 'background:rgba(245,158,11,0.12); color:#FBBF24; border:1px solid rgba(245,158,11,0.35);' },
  error: { label: 'Error', badgeStyle: 'background:rgba(239,68,68,0.12); color:#F87171; border:1px solid rgba(239,68,68,0.3);' },
  stopping: { label: 'Menghentikan', badgeStyle: 'background:rgba(148,163,184,0.1); color:#94A3B8; border:1px solid rgba(148,163,184,0.25);' },
  unresponsive: { label: 'Tidak Merespons', badgeStyle: 'background:rgba(239,68,68,0.12); color:#F87171; border:1px solid rgba(239,68,68,0.3);' }
};

let deployBotMissingCycles = 0;
let deployPollSequence = 0;

function getActiveDeployId() {
  return localStorage.getItem('af_active_deploy_id') || '';
}

function setActiveDeployId(id) {
  if (id) localStorage.setItem('af_active_deploy_id', id);
  else localStorage.removeItem('af_active_deploy_id');
}

function getBotToken(botId) {
  if (!botId) return '';
  try {
    return localStorage.getItem('af_bot_token_' + botId) || sessionStorage.getItem('af_bot_token_' + botId) || '';
  } catch (_) {
    return '';
  }
}
function setBotToken(botId, token) {
  if (!botId || !token) return;
  try {
    localStorage.setItem('af_bot_token_' + botId, token);
    sessionStorage.setItem('af_bot_token_' + botId, token);
  } catch (_) {}
}

function clearBotToken(botId) {
  if (!botId) return;
  try {
    localStorage.removeItem('af_bot_token_' + botId);
    sessionStorage.removeItem('af_bot_token_' + botId);
  } catch (_) {}
}

function getLinkedBots() {
  let list = [];
  try {
    const raw = localStorage.getItem('af_linked_bots');
    if (raw) {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) list = arr.slice();
    }
  } catch (_) {}

  // Temukan bot lain yang pernah terdaftar dari token bot di localStorage
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith('af_bot_token_bot_')) {
        const botId = k.replace('af_bot_token_', '');
        const phone = botId.replace('bot_', '');
        if (!list.some(b => b.id === botId)) {
          list.push({ id: botId, phone });
        }
      }
    }
  } catch (_) {}

  const activeId = getActiveDeployId();
  const activePhone = localStorage.getItem('af_active_deploy_phone');
  if (activeId && !list.some(b => b.id === activeId)) {
    list.push({ id: activeId, phone: activePhone || activeId.replace('bot_', '') });
  }

  // Deduplikasi & validasi
  const unique = [];
  const seenIds = new Set();
  for (const b of list) {
    if (b && b.id && !seenIds.has(b.id)) {
      seenIds.add(b.id);
      unique.push({ id: b.id, phone: String(b.phone || '').replace(/\D/g, '') });
    }
  }

  const result = unique.slice(0, 2);
  saveLinkedBots(result);
  return result;
}

function saveLinkedBots(bots) {
  try {
    localStorage.setItem('af_linked_bots', JSON.stringify(bots));
  } catch (_) {}
}

function addLinkedBot(id, phone, token) {
  if (!id || !phone) return;
  const cleanPhone = String(phone).replace(/\D/g, '');
  const current = getLinkedBots().filter(b => b.id !== id && b.phone !== cleanPhone);
  current.push({ id, phone: cleanPhone });
  const hasDual = localStorage.getItem('af_allow_dual_account') === '1';
  const maxBots = hasDual ? 2 : 1;
  const trimmed = current.slice(-maxBots);
  saveLinkedBots(trimmed);
  setActiveDeployId(id);
  localStorage.setItem('af_active_deploy_phone', cleanPhone);
  if (token) setBotToken(id, token);
}

function removeLinkedBot(id) {
  const current = getLinkedBots().filter(b => b.id !== id);
  saveLinkedBots(current);
  clearBotToken(id);
  if (getActiveDeployId() === id) {
    if (current.length > 0) {
      setActiveDeployId(current[0].id);
      localStorage.setItem('af_active_deploy_phone', current[0].phone);
    } else {
      setActiveDeployId('');
      localStorage.removeItem('af_active_deploy_phone');
    }
  }
}
window.switchActiveConsoleBot = function(botId) {
  if (!botId) return;
  const list = getLinkedBots();
  const target = list.find(b => b.id === botId);
  if (target) {
    setActiveDeployId(target.id);
    localStorage.setItem('af_active_deploy_phone', target.phone);
    terminalClearedAt = Date.now();
    const consoleBody = document.getElementById('web-deploy-console-body');
    if (consoleBody) {
      consoleBody.dataset.lastFingerprint = '';
      consoleBody.innerHTML = '';
    }
    refreshDeployStatus();
    const consoleCard = document.getElementById('web-deploy-console-card');
    if (consoleCard) {
      consoleCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }
}


;

function getDeployDevKey() {
  try {
    return sessionStorage.getItem('af_deploy_access_key') || '';
  } catch (e) {
    return '';
  }
}
async function safeDeployFetch(url, options = {}) {
  const devKey = getDeployDevKey();
  const activeBotId = getActiveDeployId();
  const explicitToken = options.headers && (options.headers['x-bot-token'] || options.headers['X-Bot-Token']);
  const botToken = explicitToken !== undefined ? explicitToken : (activeBotId ? getBotToken(activeBotId) : '');
  const headers = Object.assign({
    'x-deploy-key': devKey || 'public',
    'Cache-Control': 'no-cache'
  }, options.headers || {}, {
    'x-bot-token': explicitToken !== undefined ? explicitToken : botToken
  });

  let res;
  try {
    res = await fetch(url, { ...options, headers });
  } catch (netErr) {
    const err = new Error('Layanan deploy bot sedang offline atau gangguan jaringan. Silakan coba beberapa saat lagi.');
    err.status = 503;
    err.code = 'SERVER_OFFLINE';
    throw err;
  }

  const text = await res.text();
  let data = null;
  try {
    data = JSON.parse(text);
  } catch (_) {
    const err = new Error('Layanan deploy bot sedang offline. Silakan coba beberapa saat lagi.');
    err.status = res.status || 503;
    err.code = 'SERVER_OFFLINE';
    throw err;
  }

  if (res.status === 403 && data && data.locked) {
    if (typeof window.relockDeployGate === 'function') window.relockDeployGate();
    const err = new Error(data.error || 'Fitur deploy bot sedang dikunci (Mode Pengembangan).');
    err.status = 403;
    err.code = 'GATE_LOCKED';
    err.data = data;
    throw err;
  }

  if (!res.ok) {
    const msg = data && (data.error || data.message) ? (data.error || data.message) : `Gagal memproses permintaan (Status: ${res.status})`;
    const err = new Error(msg);
    err.status = res.status;
    err.code = data?.code || (res.status === 401 ? 'AUTH_REQUIRED' : (res.status === 403 ? 'FORBIDDEN' : (res.status === 503 ? 'SERVICE_UNAVAILABLE' : 'API_ERROR')));
    err.data = data;
    throw err;
  }
  return data;
}

async function safeDeployGet(url, fallbackValue = {}, extraHeaders = {}) {
  try {
    const devKey = getDeployDevKey();
    const activeBotId = getActiveDeployId();
    const botToken = (extraHeaders && extraHeaders['x-bot-token']) ? extraHeaders['x-bot-token'] : (activeBotId ? getBotToken(activeBotId) : '');
    const headers = Object.assign({
      'x-deploy-key': devKey || 'public',
      'x-bot-token': botToken,
      'Cache-Control': 'no-cache'
    }, extraHeaders);
    const res = await fetch(url, { headers });
    if (res.status === 403) {
      const text = await res.text();
      let data = {};
      try { data = JSON.parse(text); } catch (_) {}
      if (data && data.locked && typeof window.relockDeployGate === 'function') {
        window.relockDeployGate();
      }
      return data || fallbackValue;
    }
    const text = await res.text();
    return JSON.parse(text);
  } catch (_) {
    return fallbackValue;
  }
}
function initDeployModule() {
  let currentDeployPlatform = 'whatsapp';

  const tierInfoBox = document.getElementById('deploy-tier-info-box');
  const tierNameLabel = document.getElementById('deploy-tier-name-label');
  const tierDescLabel = document.getElementById('deploy-tier-desc-label');
  const tierBadgeLabel = document.getElementById('deploy-tier-badge-label');
  const unlicensedBox = document.getElementById('deploy-unlicensed-box');
  const unlicensedTitle = document.getElementById('deploy-unlicensed-title');
  const unlicensedDesc = document.getElementById('deploy-unlicensed-desc');
  const phoneInputEl = document.getElementById('web-deploy-phone');

  async function checkPhoneLicenseStatus(phone, platform = currentDeployPlatform) {
    if (!phone) return null;
    const clean = String(phone).replace(/\D/g, '');
    if (clean.length < 8) return null;
    try {
      const res = await safeDeployFetch(`/api/deploy/check-license?phone=${encodeURIComponent(clean)}&platform=${encodeURIComponent(platform)}`);
      return res;
    } catch (_) {
      return null;
    }
  }

  // 0.0 Switcher Platform (WhatsApp Bot vs Telegram Userbot)
  window.selectDeployPlatform = function(platform) {
    currentDeployPlatform = platform;
    const optWa = document.getElementById('opt-platform-wa');
    const optTg = document.getElementById('opt-platform-tg');
    const tiersWa = document.getElementById('deploy-tiers-whatsapp');
    const tiersTg = document.getElementById('deploy-tiers-telegram');
    const methodsWa = document.getElementById('deploy-methods-whatsapp');
    const methodsTg = document.getElementById('deploy-methods-telegram');
    const tgNotice = document.getElementById('deploy-field-tg-notice');
    const phoneLabel = document.getElementById('deploy-phone-label');
    const phoneHint = document.getElementById('deploy-phone-hint');
    const submitBtnText = document.getElementById('web-deploy-submit-btn-text');
    const ownerSummary = document.getElementById('deploy-owner-summary-text');
    const ownerAddon = document.getElementById('deploy-owner-addon');
    const ownerInput = document.getElementById('web-deploy-owner');
    const ownerHint = document.getElementById('deploy-owner-hint');

    if (platform === 'telegram') {
      if (optWa) optWa.classList.remove('active');
      if (optTg) optTg.classList.add('active');
      const radioTg = optTg?.querySelector('input[type="radio"]');
      if (radioTg) radioTg.checked = true;

      if (tiersWa) tiersWa.style.display = 'none';
      if (tiersTg) tiersTg.style.display = 'grid';
      if (methodsWa) methodsWa.style.display = 'none';
      if (methodsTg) methodsTg.style.display = 'grid';
      if (tgNotice) tgNotice.style.display = 'block';

      const radioTgOtp = document.querySelector('#deploy-methods-telegram input[name="deploy-pair-method"]');
      if (radioTgOtp) radioTgOtp.checked = true;

      if (phoneLabel) phoneLabel.textContent = 'Nomor Akun Telegram';
      if (phoneHint) phoneHint.textContent = 'Gunakan format internasional (contoh: 628123456789, akun Telegram aktif).';
      if (submitBtnText) submitBtnText.textContent = 'Mulai Pairing Bot Telegram';

      if (ownerSummary) ownerSummary.textContent = 'Pengaturan ID Owner Telegram (Opsional)';
      if (ownerAddon) ownerAddon.textContent = 'ID';
      if (ownerInput) {
        ownerInput.placeholder = 'Contoh: 6312908558 (Kosongkan jika akun sendiri = owner)';
      }
      if (ownerHint) ownerHint.textContent = 'ID angka Telegram kamu. Karena ini Userbot, akun kamu otomatis 100% menjadi owner utama!';

      // Aktifkan default tier TG Free
      const optTgFree = document.getElementById('opt-tier-tg-free');
      if (optTgFree) optTgFree.click();
    } else {
      if (optTg) optTg.classList.remove('active');
      if (optWa) optWa.classList.add('active');
      const radioWa = optWa?.querySelector('input[type="radio"]');
      if (radioWa) radioWa.checked = true;

      if (tiersTg) tiersTg.style.display = 'none';
      if (tiersWa) tiersWa.style.display = 'grid';
      if (methodsTg) methodsTg.style.display = 'none';
      if (methodsWa) methodsWa.style.display = 'grid';
      if (tgNotice) tgNotice.style.display = 'none';

      const radioWaCode = document.querySelector('#deploy-methods-whatsapp #opt-method-code input[name="deploy-pair-method"]');
      if (radioWaCode) radioWaCode.checked = true;

      if (phoneLabel) phoneLabel.textContent = 'Nomor WhatsApp Bot';
      if (phoneHint) phoneHint.textContent = 'Gunakan kode negara (contoh: 628123456789, tanpa spasi/strip).';
      if (submitBtnText) submitBtnText.textContent = 'Mulai Pairing Bot WhatsApp';

      if (ownerSummary) ownerSummary.textContent = 'Pengaturan Nomor Owner (Opsional)';
      if (ownerAddon) ownerAddon.textContent = '+';
      if (ownerInput) {
        ownerInput.placeholder = '628xxxxxxxxxx (Kosongkan jika nomor bot = owner)';
      }
      if (ownerHint) ownerHint.textContent = 'Nomor yang memiliki akses penuh ke bot. Kosongkan jika nomor bot bertindak sebagai owner.';

      // Aktifkan default tier WA Free
      const optFree = document.getElementById('opt-tier-free');
      if (optFree) optFree.click();
    }
  };

  // Pasang listener platform switcher
  const optWaEl = document.getElementById('opt-platform-wa');
  if (optWaEl) optWaEl.addEventListener('click', () => window.selectDeployPlatform('whatsapp'));
  const optTgEl = document.getElementById('opt-platform-tg');
  if (optTgEl) {
    // Otomatis buka kunci di lingkungan localhost / IP lokal pengujian
    const isLocalEnv = ['localhost', '127.0.0.1'].includes(window.location.hostname) ||
                       window.location.hostname.startsWith('192.168.') ||
                       window.location.hostname.startsWith('10.') ||
                       window.location.search.includes('unlock_tg=1');
    if (isLocalEnv) {
      optTgEl.classList.remove('is-locked');
      optTgEl.style.opacity = '1';
      optTgEl.style.cursor = 'pointer';
      optTgEl.removeAttribute('title');
      const radioTg = optTgEl.querySelector('input[type="radio"]');
      if (radioTg) radioTg.removeAttribute('disabled');
      const tagEl = optTgEl.querySelector('.segment-tag');
      if (tagEl) {
        tagEl.className = 'segment-tag tag-tg';
        tagEl.style = '';
        tagEl.textContent = 'SC UBOT';
      }
    }

    optTgEl.addEventListener('click', (e) => {
      if (optTgEl.classList.contains('is-locked')) {
        e.preventDefault();
        e.stopPropagation();
        if (typeof showDeployToast === 'function') {
          showDeployToast('Fitur Telegram Ubot sedang dalam tahap pengujian akhir & akan segera hadir!', 'info');
        }
        return;
      }
      window.selectDeployPlatform('telegram');
    });
  }

  // 0. Toggle Pilihan Edisi Bot (Free Trial vs Premium Buyer)
  const tierOptions = document.querySelectorAll('.deploy-tier-option');
  tierOptions.forEach(opt => {
    opt.addEventListener('click', async () => {
      // Hilangkan active dari sesama sibling di container yang sama
      const parentContainer = opt.closest('.deploy-segmented-tabs');
      if (parentContainer) {
        parentContainer.querySelectorAll('.deploy-tier-option').forEach(o => o.classList.remove('active'));
      } else {
        tierOptions.forEach(o => o.classList.remove('active'));
      }
      opt.classList.add('active');
      const radio = opt.querySelector('input[type="radio"]');
      if (radio) radio.checked = true;

      const selectedTier = radio?.value || 'wa-free';
      if (selectedTier === 'wa-buy') {
        if (tierNameLabel) tierNameLabel.textContent = 'SC JPM PREMIUM EDITION';
        if (tierDescLabel) tierDescLabel.textContent = 'Versi Terbaru · Premium WhatsApp';
        if (tierBadgeLabel) {
          tierBadgeLabel.textContent = 'PREMIUM';
          tierBadgeLabel.style.color = '#FBBF24';
          tierBadgeLabel.style.background = 'rgba(245, 158, 11, 0.15)';
          tierBadgeLabel.style.borderColor = 'rgba(245, 158, 11, 0.35)';
        }
        if (unlicensedTitle) unlicensedTitle.textContent = 'Nomor Belum Berlisensi Premium';
        if (unlicensedDesc) {
          unlicensedDesc.innerHTML = `Nomor WhatsApp ini belum terdaftar di database lisensi resmi AGAAHOST. Beli lisensi resmi:<br>• <strong>No Update:</strong> Rp 15.000 (Permanen)<br>• <strong>Full Update:</strong> Rp 25.000 (Permanen + Free Panel DO)`;
        }

        // Cek lisensi nomor yang sedang diketik
        const phone = (phoneInputEl?.value || '').replace(/\D/g, '');
        if (phone && phone.length >= 8) {
          const lic = await checkPhoneLicenseStatus(phone, 'whatsapp');
          if (lic && !lic.licensed) {
            if (unlicensedBox) unlicensedBox.style.display = 'block';
          } else {
            if (unlicensedBox) unlicensedBox.style.display = 'none';
          }
        }
      } else if (selectedTier === 'tg-buy') {
        if (tierNameLabel) tierNameLabel.textContent = 'TELEGRAM USERBOT PREMIUM';
        if (tierDescLabel) tierDescLabel.textContent = 'Telegram Ubot · Lisensi Resmi GitHub';
        if (tierBadgeLabel) {
          tierBadgeLabel.textContent = 'PREMIUM';
          tierBadgeLabel.style.color = '#38BDF8';
          tierBadgeLabel.style.background = 'rgba(34, 158, 217, 0.15)';
          tierBadgeLabel.style.borderColor = 'rgba(34, 158, 217, 0.35)';
        }
        if (unlicensedTitle) unlicensedTitle.textContent = 'Nomor Belum Berlisensi Telegram Ubot';
        if (unlicensedDesc) {
          unlicensedDesc.innerHTML = `Nomor ini belum terdaftar di database lisensi resmi Telegram Ubot AGAAHOST (<code>CharlesFergei/ubot-tele</code>). Silakan hubungi Owner Farel di <strong>wa.me/6285879220690</strong> untuk aktivasi lisensi.`;
        }

        const phone = (phoneInputEl?.value || '').replace(/\D/g, '');
        if (phone && phone.length >= 8) {
          const lic = await checkPhoneLicenseStatus(phone, 'telegram');
          if (lic && !lic.licensed) {
            if (unlicensedBox) unlicensedBox.style.display = 'block';
          } else {
            if (unlicensedBox) unlicensedBox.style.display = 'none';
          }
        }
      } else if (selectedTier === 'tg-free') {
        if (tierNameLabel) tierNameLabel.textContent = 'TELEGRAM USERBOT FREE TRIAL';
        if (tierDescLabel) tierDescLabel.textContent = 'Telegram Ubot · Uji Coba 3 Jam';
        if (tierBadgeLabel) {
          tierBadgeLabel.textContent = 'GRATIS';
          tierBadgeLabel.style.color = '#38BDF8';
          tierBadgeLabel.style.background = 'rgba(34, 158, 217, 0.12)';
          tierBadgeLabel.style.borderColor = 'rgba(34, 158, 217, 0.3)';
        }
        if (unlicensedBox) unlicensedBox.style.display = 'none';
      } else {
        if (tierNameLabel) tierNameLabel.textContent = 'SC JPM FREE EDITION';
        if (tierDescLabel) tierDescLabel.textContent = 'Versi Terbaru · Uji Coba 3 Jam';
        if (tierBadgeLabel) {
          tierBadgeLabel.textContent = 'GRATIS';
          tierBadgeLabel.style.color = '#4ADE80';
          tierBadgeLabel.style.background = 'rgba(34, 197, 94, 0.12)';
          tierBadgeLabel.style.borderColor = 'rgba(34, 197, 94, 0.3)';
        }
        if (unlicensedBox) unlicensedBox.style.display = 'none';
      }
    });
  });

  // Tombol Beli Lisensi di Alert Box
  const btnBuyLic = document.getElementById('btn-buy-license-modal');
  if (btnBuyLic) {
    btnBuyLic.addEventListener('click', () => {
      if (currentDeployPlatform === 'telegram') {
        const waUrl = 'https://wa.me/6285879220690?text=' + encodeURIComponent('Halo Owner Farel, saya mau beli Lisensi Resmi Telegram Ubot.');
        window.open(waUrl, '_blank', 'noopener,noreferrer');
        return;
      }
      const prod = (typeof productsData !== 'undefined' && Array.isArray(productsData))
        ? productsData.find(p => p.id === 'script-bot-whatsapp-jpm')
        : null;
      if (prod && typeof openOrderModal === 'function') {
        openOrderModal(prod);
      } else {
        const waUrl = 'https://wa.me/6285879220690?text=' + encodeURIComponent('Halo Owner Farel, saya mau beli Lisensi Resmi SC JPM Bot WhatsApp.');
        window.open(waUrl, '_blank', 'noopener,noreferrer');
      }
    });
  }

  // Tombol Switch to Free di Alert Box
  const btnSwitchFree = document.getElementById('btn-switch-to-free');
  if (btnSwitchFree) {
    btnSwitchFree.addEventListener('click', () => {
      if (currentDeployPlatform === 'telegram') {
        const optTgFree = document.getElementById('opt-tier-tg-free');
        if (optTgFree) optTgFree.click();
      } else {
        const optFree = document.getElementById('opt-tier-free');
        if (optFree) optFree.click();
      }
    });
  }

  // Live checker lisensi saat mengetik nomor (Debounce 600ms)
  let phoneDebounceTimer = null;
  if (phoneInputEl) {
    phoneInputEl.addEventListener('input', () => {
      clearTimeout(phoneDebounceTimer);
      phoneDebounceTimer = setTimeout(async () => {
        const currentTier = document.querySelector('input[name="deploy-template-tier"]:checked')?.value || 'wa-free';
        if (currentTier === 'wa-buy' || currentTier === 'tg-buy') {
          const phone = (phoneInputEl.value || '').replace(/\D/g, '');
          if (phone && phone.length >= 8) {
            const platform = currentTier.startsWith('tg') ? 'telegram' : 'whatsapp';
            const lic = await checkPhoneLicenseStatus(phone, platform);
            if (lic && !lic.licensed) {
              if (unlicensedBox) unlicensedBox.style.display = 'block';
            } else {
              if (unlicensedBox) unlicensedBox.style.display = 'none';
            }
          }
        }
      }, 600);
    });
  }

  // 0.1 Toggle Pilihan Metode Penautan (Kode Pairing vs QR Code)
  const methodOptions = document.querySelectorAll('.deploy-method-option');
  methodOptions.forEach(opt => {
    opt.addEventListener('click', () => {
      methodOptions.forEach(o => o.classList.remove('active'));
      opt.classList.add('active');
      const radio = opt.querySelector('input[type="radio"]');
      if (radio) radio.checked = true;
    });
  });

  // 1. Form Deploy WhatsApp Bot
  const deployForm = document.getElementById('web-deploy-form');
  if (deployForm) {
    deployForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      if (window.__isDeployActive === false || document.getElementById('web-deploy-submit-btn')?.disabled) {
        showDeployToast('Layanan sedang tidak aktif', 'error');
        return;
      }

      const phoneInput = document.getElementById('web-deploy-phone');
      const ownerInput = document.getElementById('web-deploy-owner');
      const passInput = document.getElementById('web-deploy-password');
      const tokenInput = document.getElementById('web-deploy-token');
      const submitBtn = document.getElementById('web-deploy-submit-btn');

      const phone = (phoneInput?.value || '').replace(/\D/g, '');
      const owner = (ownerInput?.value || '').replace(/\D/g, '') || phone;
      const password = (passInput?.value || '').trim();
      const tokenCode = (tokenInput?.value || '').trim().toUpperCase();
      const pairMethod = document.querySelector('input[name="deploy-pair-method"]:checked')?.value || 'code';
      const template = document.querySelector('input[name="deploy-template-tier"]:checked')?.value || (currentDeployPlatform === 'telegram' ? 'tg-free' : 'wa-free');
      const isTg = currentDeployPlatform === 'telegram' || String(template).startsWith('tg');

      if (!phone || phone.length < 7) {
        showDeployToast(isTg ? 'Nomor akun Telegram wajib diisi (minimal 7 digit).' : 'Nomor WhatsApp wajib diisi (minimal 7 digit).');
        if (phoneInput) phoneInput.focus();
        return;
      }

      if (!password || password.length < 6) {
        showDeployToast('Password keamanan bot wajib diisi (minimal 6 karakter).');
        if (passInput) passInput.focus();
        return;
      }

      // Batasi 1 bot per browser/cache (Kecuali sudah redeem Token Dual Akun)
      const hasDualAccount = localStorage.getItem('af_allow_dual_account') === '1';
      const activeId = getActiveDeployId();
      const activePhone = (localStorage.getItem('af_active_deploy_phone') || '').replace(/\D/g, '');
      const isSamePhone = phone && (phone === activePhone || `bot_${phone}` === activeId);

      // Jika mendaftarkan nomor baru yang berbeda dan belum mengaktifkan dual akun:
      if (!isSamePhone && !hasDualAccount) {
        const currentBots = getLinkedBots();
        const otherBots = currentBots.filter(b => b.phone && b.phone !== phone && b.id !== `bot_${phone}`);

        if (otherBots.length > 0) {
          let hasRealActiveBot = false;
          for (const ob of otherBots) {
            try {
              const checkOld = await safeDeployGet(`/api/deploy/bot/${ob.id}`, { exists: false });
              if (checkOld && checkOld.exists && checkOld.bot) {
                hasRealActiveBot = true;
                break;
              } else {
                // Bot lama sudah tidak valid di server, bersihkan dari penyimpanan lokal
                removeLinkedBot(ob.id);
                if (activeId === ob.id) {
                  setActiveDeployId('');
                  localStorage.removeItem('af_active_deploy_phone');
                }
              }
            } catch (_) {
              hasRealActiveBot = true;
              break;
            }
          }

          if (hasRealActiveBot) {
            showDeployToast('Batas bot aktif maksimal 1 bot per browser. Beli atau redeem Token Dual Akun untuk menambah bot kedua!');
            return;
          }
        } else if (activeId && !isSamePhone) {
          setActiveDeployId('');
          localStorage.removeItem('af_active_deploy_phone');
        }
      }

      submitBtn.disabled = true;
      const originalBtnHtml = submitBtn.innerHTML;
      submitBtn.innerHTML = `<span>${isTg ? 'Mendaftarkan & Menyiapkan Login Telegram...' : 'Mendaftarkan & Meminta Pairing...'}</span>`;

      try {
        const data = await safeDeployFetch('/api/deploy/bot', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ phone, owner: owner || phone, pairMethod, template, password })
        });

        // Jika nomor sudah memiliki bot aktif dan diproteksi password (Opsi B)
        if (data.requirePassword) {
          openVerifyPasswordModal(data.botId, data.phone);
          showDeployToast('Nomor sudah terdaftar. Masukkan password untuk masuk.');
          return;
        }

        addLinkedBot(data.botId, phone, data.token);
        if (data.allowDualAccount) {
          localStorage.setItem('af_allow_dual_account', '1');
        }

        // Jika token diisi saat deploy, klaim otomatis untuk bot baru ini
        if (tokenCode) {
          try {
            const redeemRes = await safeDeployFetch('/api/deploy/redeem', {
              method: 'POST',
              headers: { 'content-type': 'application/json' },
              body: JSON.stringify({ phone, code: tokenCode })
            });
            if (tokenInput) tokenInput.value = '';
            if (redeemRes.type === 'dual' || redeemRes.account?.allowDualAccount) {
              localStorage.setItem('af_allow_dual_account', '1');
            }
            showDeployToast('🎁 ' + (redeemRes.message || 'Token berhasil digunakan!'));
          } catch (tokErr) {
            console.warn('Gagal redeem token saat deploy:', tokErr.message);
          }
        }

        if (data.resumed) {
          showDeployToast(`Sesi bot +${phone} ditemukan & berhasil dipulihkan!`);
        } else if (isTg) {
          showDeployToast(`Nomor +${phone} terdaftar! Menunggu kode OTP Telegram...`);
          setTimeout(() => {
            window.openTelegramOtpModal(data.botId, phone, false);
          }, 350);
        } else {
          showDeployToast(`Nomor +${phone} terdaftar! Menyiapkan koneksi ${pairMethod === 'qr' ? 'QR Code' : 'Kode Pairing'}...`);
        }
        phoneInput.value = '';
        ownerInput.value = '';
        if (passInput) passInput.value = '';
        if (tokenInput) tokenInput.value = '';
        
        // Tandai agar layar otomatis mengarah dan fokus langsung ke banner kode pairing/QR
        window.__shouldScrollToPairing = true;
        await refreshDeployStatus();

        // Arahkan scroll layar langsung ke kotak Kode Pairing / QR Code
        const targetBox = pairMethod === 'qr'
          ? document.getElementById('web-deploy-qr-box')
          : document.getElementById('web-deploy-pairing-box');
        if (targetBox && targetBox.style.display !== 'none') {
          setTimeout(() => {
            targetBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
            targetBox.classList.add('highlight-focus');
            setTimeout(() => targetBox.classList.remove('highlight-focus'), 1200);
          }, 120);
        }
      } catch (err) {
        showDeployToast(err.message, 'error');
      } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnHtml;
      }
    });
  }

  // 2. Salin Kode Pairing Button Listener
  const copyBtn = document.getElementById('web-deploy-copy-btn');
  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      const codeEl = document.getElementById('web-deploy-pairing-code');
      const code = (codeEl?.textContent || '').trim();
      if (!code || code === '---- ----') return;

      if (navigator.clipboard) {
        navigator.clipboard.writeText(code);
      } else {
        const ta = document.createElement('textarea');
        ta.value = code;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
      }

      const origHtml = copyBtn.innerHTML;
      copyBtn.innerHTML = `
        <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
        <span>Tersalin!</span>
      `;
      copyBtn.style.background = '#22C55E';
      setTimeout(() => {
        copyBtn.innerHTML = origHtml;
        copyBtn.style.background = '';
      }, 2000);
    });
  }

  // 3. Keyboard Navigation untuk Terminal Interaktif CLI (Arrow Up/Down History)
  const termInput = document.getElementById('terminal-cmd-input');
  if (termInput) {
    termInput.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (terminalHistory.length > 0 && terminalHistoryIndex > 0) {
          terminalHistoryIndex--;
          termInput.value = terminalHistory[terminalHistoryIndex] || '';
        }
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (terminalHistoryIndex < terminalHistory.length - 1) {
          terminalHistoryIndex++;
          termInput.value = terminalHistory[terminalHistoryIndex] || '';
        } else {
          terminalHistoryIndex = terminalHistory.length;
          termInput.value = '';
        }
      }
    });
  }
}


// ============================================================================
// MODAL CONTROLLER: TELEGRAM OTP & 2FA AUTHENTICATION
// ============================================================================
window.openTelegramOtpModal = function(botId, phone, is2fa = false, hint = '') {
  const modal = document.getElementById('modal-tg-otp-overlay');
  const botIdInput = document.getElementById('tg-otp-bot-id');
  const botId2faInput = document.getElementById('tg-2fa-bot-id');
  const stepOtp = document.getElementById('tg-step-otp');
  const step2fa = document.getElementById('tg-step-2fa');
  const otpInput = document.getElementById('input-tg-otp');
  const passInput = document.getElementById('input-tg-2fa');
  const otpErr = document.getElementById('tg-otp-error');
  const err2fa = document.getElementById('tg-2fa-error');
  const hintEl = document.getElementById('tg-2fa-hint');

  if (botIdInput) botIdInput.value = botId || '';
  if (botId2faInput) botId2faInput.value = botId || '';
  if (otpErr) otpErr.style.display = 'none';
  if (err2fa) err2fa.style.display = 'none';

  if (is2fa) {
    if (stepOtp) stepOtp.style.display = 'none';
    if (step2fa) step2fa.style.display = 'block';
    if (hintEl) {
      if (hint) {
        hintEl.textContent = 'Petunjuk: ' + hint;
        hintEl.style.display = 'block';
      } else {
        hintEl.style.display = 'none';
      }
    }
    if (modal) modal.style.display = 'flex';
    setTimeout(() => passInput?.focus(), 150);
  } else {
    if (stepOtp) stepOtp.style.display = 'block';
    if (step2fa) step2fa.style.display = 'none';
    if (modal) modal.style.display = 'flex';
    setTimeout(() => otpInput?.focus(), 150);
  }
};

window.closeTelegramOtpModal = function() {
  const modal = document.getElementById('modal-tg-otp-overlay');
  if (modal) modal.style.display = 'none';
};

window.toggleTg2faEye = function() {
  const input = document.getElementById('input-tg-2fa');
  if (input) input.type = input.type === 'password' ? 'text' : 'password';
};

window.handleTelegramOtpSubmit = async function(e) {
  if (e && e.preventDefault) e.preventDefault();
  const botId = document.getElementById('tg-otp-bot-id')?.value || getActiveDeployId();
  const otpInput = document.getElementById('input-tg-otp');
  const submitBtn = document.getElementById('btn-submit-tg-otp');
  const errEl = document.getElementById('tg-otp-error');
  const code = (otpInput?.value || '').trim();

  if (!code) {
    if (errEl) {
      errEl.textContent = 'Kode OTP Telegram wajib diisi.';
      errEl.style.display = 'block';
    }
    return;
  }

  if (submitBtn) {
    submitBtn.disabled = true;
    const span = submitBtn.querySelector('span:not(.cyber-btn-glare)');
    if (span) span.textContent = 'Memverifikasi Kode OTP...';
  }

  try {
    const token = getBotToken(botId);
    const headers = { 'content-type': 'application/json' };
    if (token) headers['x-bot-token'] = token;

    const res = await safeDeployFetch(`/api/deploy/bot/${botId}/tg-otp`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ code })
    });

    if (res.require2fa || res.status === 'await_2fa') {
      window.openTelegramOtpModal(botId, '', true, res.hint || '');
      showDeployToast('OTP diterima! Akun menggunakan verifikasi 2FA.');
    } else {
      window.closeTelegramOtpModal();
      showDeployToast('Kode OTP berhasil dikonfirmasi! Menghubungkan userbot...');
      if (otpInput) otpInput.value = '';
      await refreshDeployStatus();
    }
  } catch (err) {
    if (errEl) {
      errEl.textContent = err.message || 'Gagal memverifikasi OTP Telegram.';
      errEl.style.display = 'block';
    }
  } finally {
    if (submitBtn) {
      submitBtn.disabled = false;
      const span = submitBtn.querySelector('span:not(.cyber-btn-glare)');
      if (span) span.textContent = 'Verifikasi & Masuk';
    }
  }
};

window.handleTelegram2faSubmit = async function(e) {
  if (e && e.preventDefault) e.preventDefault();
  const botId = document.getElementById('tg-2fa-bot-id')?.value || getActiveDeployId();
  const passInput = document.getElementById('input-tg-2fa');
  const submitBtn = document.getElementById('btn-submit-tg-2fa');
  const errEl = document.getElementById('tg-2fa-error');
  const password = (passInput?.value || '').trim();

  if (!password) {
    if (errEl) {
      errEl.textContent = 'Kata sandi 2FA wajib diisi.';
      errEl.style.display = 'block';
    }
    return;
  }

  if (submitBtn) {
    submitBtn.disabled = true;
    const span = submitBtn.querySelector('span:not(.cyber-btn-glare)');
    if (span) span.textContent = 'Memverifikasi 2FA...';
  }

  try {
    const token = getBotToken(botId);
    const headers = { 'content-type': 'application/json' };
    if (token) headers['x-bot-token'] = token;

    await safeDeployFetch(`/api/deploy/bot/${botId}/tg-2fa`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ password })
    });

    window.closeTelegramOtpModal();
    showDeployToast('Kata sandi 2FA berhasil dikonfirmasi! Userbot segera online.');
    if (passInput) passInput.value = '';
    await refreshDeployStatus();
  } catch (err) {
    if (errEl) {
      errEl.textContent = err.message || 'Gagal memverifikasi kata sandi 2FA.';
      errEl.style.display = 'block';
    }
  } finally {
    if (submitBtn) {
      submitBtn.disabled = false;
      const span = submitBtn.querySelector('span:not(.cyber-btn-glare)');
      if (span) span.textContent = 'Kirim Sandi 2FA';
    }
  }
};

let terminalClearedAt = 0;
let deployLogFilterMode = localStorage.getItem('af_deploy_log_mode') || 'clean';

function parseAndBeautifyConsoleEvents(events, filterMode = deployLogFilterMode) {
  const result = [];
  let i = 0;

  while (i < events.length) {
    const ev = events[i];
    const text = String(ev.text || '').trim();

    // Saring prompt interaktif readline / duplikasi noisy text
    if (/Ketik (ya|tidak|1|2|nomor|owner) lalu Enter/i.test(text) ||
        /1\.\s*Kode Pairing|2\.\s*QR Code|1 atau 2 lalu Enter|Gunakan nomor terdaftar/i.test(text) ||
        /Masukkan nomor WhatsApp|Nomor Owner:/i.test(text) ||
        /AutoSwgc Free diproteksi/i.test(text) ||
        text.includes('AutoSwgc Free diproteksi permanen') ||
        /pre-key|app-state-sync|AppStateSync|NoiseHandshake|Socket connection/i.test(text)) {
      i++;
      continue;
    }

    // 0. Deteksi format baris tunggal ⚡ [CMD] dari Deploy Server
    if (text.includes('[CMD]') || text.startsWith('⚡ [CMD]')) {
      const cmdMatch = text.match(/\[CMD\]\s*([^\s·]+)/i);
      const userMatch = text.match(/Pengirim:\s*\+?([^\s·]+)/i);
      const statusMatch = text.match(/Status:\s*\[?\s*([^\]·()]+)\]?/i);
      const modeMatch = text.match(/\((PUBLIC|SELF)\)/i);

      result.push({
        type: 'card_cmd',
        time: ev.time,
        label: ev.label,
        cmd: cmdMatch ? cmdMatch[1].trim() : '.cmd',
        user: userMatch ? userMatch[1].trim() : (ev.label || '-'),
        cmdTime: ev.time ? ev.time.slice(11, 19) : '',
        status: statusMatch && statusMatch[1].includes('ERROR') ? 'ERROR' : 'SUCCESS',
        mode: modeMatch ? modeMatch[1].trim() : 'PUBLIC',
        version: 'V13.5.5'
      });
      i++;
      continue;
    }

    // 0.1 Deteksi blok Startup Banner AGAAHOST (Logo ASCII, Versi, Tier, Node)
    const isBannerAscii = /[▄▀█]{3,}/.test(text);
    const isBannerSub = /WhatsApp Marketing Bot/i.test(text);
    if (isBannerAscii || isBannerSub) {
      let ascii1 = '';
      let ascii2 = '';
      let subTitle = 'WhatsApp Marketing Bot';
      let verStr = 'v13.5.5 (Latest)';
      let tierStr = 'FREE EDITION';
      let nodeStr = 'Node v20.18.0';
      let lastTime = ev.time;
      let label = ev.label;

      let j = i;
      while (j < events.length && j < i + 14) {
        const line = String(events[j].text || '').replace(/^[║│|]\s*/, '').replace(/\s*[║│|]$/, '');
        if (events[j].time) lastTime = events[j].time;
        if (events[j].label) label = events[j].label;

        if (/[▄▀█]{3,}/.test(line)) {
          if (!ascii1) ascii1 = line.trim();
          else if (!ascii2 && line.trim() !== ascii1) ascii2 = line.trim();
        }
        if (/WhatsApp Marketing Bot/i.test(line)) subTitle = 'WhatsApp Marketing Bot';
        const vMatch = line.match(/Versi\s*:\s*([^\s(║│|]+(?:\s*\(Latest\))?)/i);
        if (vMatch) verStr = vMatch[1].trim();
        const tMatch = line.match(/Tier\s*:\s*\[?\s*([^\]║│|]+)\s*\]?/i);
        if (tMatch) tierStr = tMatch[1].trim();
        const nMatch = line.match(/Node\s*:\s*([^\s║│|]+)/i);
        if (nMatch) {
          let nv = nMatch[1].trim();
          if (nv.includes('22')) nv = nv.replace('22', '20');
          nodeStr = 'Node ' + nv;
        } else {
          nodeStr = 'Node v20.18.0';
        }

        const isEnd = /^[╠╚└]/.test(line.trim()) || /Kontak CS/i.test(line) || /SYSTEM ONLINE/i.test(line);
        j++;
        if (isEnd && (ascii1 || verStr)) break;
      }

      const pinnedHero = document.getElementById('web-deploy-pinned-hero');
      if (pinnedHero) {
        const vEl = pinnedHero.querySelector('.pill-ver');
        const tEl = pinnedHero.querySelector('.pill-tier');
        const nEl = pinnedHero.querySelector('.pill-node');
        if (vEl && verStr) vEl.textContent = verStr;
        if (tEl && tierStr) tEl.textContent = `[ ${tierStr} ]`;
        if (nEl && nodeStr) nEl.textContent = nodeStr.replace(/v?22(\.\d+)*/, 'v20.18.0');
      }

      result.push({
        type: 'card_info',
        time: lastTime,
        text: `🚀 Server Bot WhatsApp Aktif · ${verStr} · Tier: ${tierStr} · Node: v20.x · Baileys AGAAHOST`
      });
      i = j;
      continue;
    }

    // 1. Deteksi blok Command Box (AF BOT SYSTEM, INCOMING COMMAND, atau baris dengan CMD »)
    const isCmdPattern = /INCOMING COMMAND|AF BOT SYSTEM/i.test(text) ||
                         (/CMD\s*[:»\u00BB\u203A\-A]+/i.test(text) && !text.includes('·'));

    if (isCmdPattern) {
      let cmdName = '';
      let userPhone = '';
      let cmdTime = '';
      let statusStr = '';
      let modeStr = '';
      let versionStr = '';
      let lastTime = ev.time;
      let label = ev.label;

      let j = i;
      while (j < events.length && j < i + 18) {
        const line = String(events[j].text || '');
        if (events[j].time) lastTime = events[j].time;
        if (events[j].label) label = events[j].label;

        const cmdMatch = line.match(/CMD\s*[:»\u00BB\u203A\-A]+\s*([^\s║│|]+)/i);
        if (cmdMatch && !cmdName) cmdName = cmdMatch[1].trim();

        const userMatch = line.match(/USER\s*[:»\u00BB\u203A\-A]+\s*([^\s║│|]+)/i);
        if (userMatch && !userPhone) userPhone = userMatch[1].trim();

        const timeMatch = line.match(/TIME\s*[:»\u00BB\u203A\-A]+\s*([^\s║│|]+)/i);
        if (timeMatch && !cmdTime) cmdTime = timeMatch[1].trim();

        const statusMatch = line.match(/STATUS\s*[:»\u00BB\u203A\-A]+\s*\[?\s*([^\]║│|]+)\]?/i);
        if (statusMatch && !statusStr) statusStr = statusMatch[1].trim();

        const modeMatch = line.match(/MODE\s*[:»\u00BB\u203A\-A]+\s*([^\s║│|]+)/i);
        if (modeMatch && !modeStr) modeStr = modeMatch[1].trim();

        const verMatch = line.match(/VERSION\s*[:»\u00BB\u203A\-A]+\s*([^\s║│|]+)/i);
        if (verMatch && !versionStr) versionStr = verMatch[1].trim();

        const isEnd = /^[╚└]/.test(line.trim());
        j++;
        if (isEnd) break;
      }

      if (cmdName || statusStr) {
        result.push({
          type: 'card_cmd',
          time: lastTime,
          label: label,
          cmd: cmdName || 'Perintah Bot',
          user: userPhone || '-',
          cmdTime: cmdTime || '',
          status: statusStr.includes('ERROR') ? 'ERROR' : 'SUCCESS',
          mode: modeStr || 'PUBLIC',
          version: versionStr || 'V13.5.5'
        });
        i = j;
        continue;
      }
    }

    // 2. Deteksi status Bot Online (Menggantikan Lisensi Resmi Aktif sesuai permintaan Farel)
    const isLicenseBox = /LISENSI RESMI AKTIF|STATUS BOT AKTIF|BOT ON/i.test(text);
    if (isLicenseBox) {
      let accNum = '';
      let hakLic = '';
      let statusDb = '';
      let lastTime = ev.time;
      let label = ev.label;

      let j = i;
      while (j < events.length && j < i + 10) {
        const line = String(events[j].text || '');
        if (events[j].time) lastTime = events[j].time;
        if (events[j].label) label = events[j].label;

        const accMatch = line.match(/(?:Nomor Akun|Akun)\s*:\s*([^\s║│|]+)/i);
        if (accMatch && !accNum) accNum = accMatch[1].trim();

        const hakMatch = line.match(/(?:Hak Lisensi|Status)\s*:\s*\[?([^\]║│|]+)\]?/i);
        if (hakMatch && !hakLic) hakLic = hakMatch[1].trim();

        const dbMatch = line.match(/(?:Status DB|Database)\s*:\s*([^║│|]+)/i);
        if (dbMatch && !statusDb) statusDb = dbMatch[1].trim();

        const isEnd = /^[╚└]/.test(line.trim());
        j++;
        if (isEnd) break;
      }

      result.push({
        type: 'card_license',
        time: lastTime,
        label: label,
        account: accNum || label,
        rights: 'BOT ON',
        dbStatus: 'Terhubung & Aktif'
      });
      i = j;
      continue;
    }

    // 3. Deteksi blok Kontak CS Resmi
    const isCsBox = /Kontak CS Resmi/i.test(text);
    if (isCsBox) {
      let j = i;
      while (j < events.length && j < i + 10) {
        const line = String(events[j].text || '').trim();
        const isEnd = /^[╚└]/.test(line);
        j++;
        if (isEnd) break;
      }
      result.push({
        type: 'card_info',
        time: ev.time,
        label: ev.label,
        text: 'Kontak CS Resmi AGAAHOST: WA wa.me/6285879220690 · Telegram t.me/Vnzxok'
      });
      i = j;
      continue;
    }

    // 4. Baris border ASCII mentah yang berdiri sendiri -> ABAIKAN/BUANG
    const isBorderOnly = /^[╔╠╚═─┌└├┬┴┼─\s│║\u2500-\u257F\uFFFD?]+$/.test(text) ||
                         /^[║│|]\s*[─═\s-]*[║│|]$/.test(text) ||
                         text.replace(/[╔╠╚═─┌└├┬┴┼─\s│║\u2500-\u257F\uFFFD?]/g, '').trim().length === 0;

    if (isBorderOnly) {
      i++;
      continue;
    }

    // 5. Baris teks biasa yang mungkin masih memiliki bingkai ║ di kiri/kanan
    let cleanText = text
      .replace(/^[║│|]\s*/, '')
      .replace(/\s*[║│|]$/, '')
      .trim();

    if (!cleanText || /^[─═-]+$/.test(cleanText)) {
      i++;
      continue;
    }

    // Filter Mode Ringkas (Clean Mode): Saring baris-baris teknis mentah agar konsol buyer rapi
    if (filterMode === 'clean') {
      const isImportant =
        cleanText.includes('[CMD]') ||
        cleanText.includes('⚡') ||
        cleanText.includes('TERHUBUNG ONLINE') ||
        cleanText.includes('KODE PAIRING') ||
        cleanText.includes('QR Code') ||
        cleanText.includes('Auto SWGC') ||
        cleanText.includes('broadcast') ||
        cleanText.includes('Sukses upload') ||
        cleanText.startsWith('[ERROR]') ||
        cleanText.startsWith('[INPUT USER]') ||
        cleanText.startsWith('[AUTH]') ||
        cleanText.includes('dihentikan') ||
        cleanText.includes('Expired') ||
        cleanText.includes('✅') ||
        cleanText.includes('🔑') ||
        cleanText.includes('⚠️');

      if (!isImportant) {
        i++;
        continue;
      }
    }

    result.push({
      type: 'log_line',
      time: ev.time,
      id: ev.id,
      label: ev.label,
      text: cleanText
    });
    i++;
  }

  return result;
}

function renderBotItemHtml(myBot, isSelectedConsole, totalBots, botIndex) {
  const isOnline = myBot.status === 'online';
  const isExpired = Boolean(myBot.isExpired || (myBot.expiresAt && myBot.expiresAt <= Date.now()));
  const isUnlimitedBot = Boolean(myBot.isUnlimited || myBot.durationHours === 0);
  const isPremiumBot = Boolean(myBot.tier === 'premium' || ['wa-buy', 'tg-buy'].includes(myBot.template));
  const isTgBot = myBot.platform === 'telegram' || (myBot.template && String(myBot.template).startsWith('tg'));
  const remMs = myBot.remainingMs || 0;
  const hours = Math.floor(remMs / 3600000);
  const mins = Math.floor((remMs % 3600000) / 60000);
  const secs = Math.floor((remMs % 60000) / 1000);

  let statusInfo = { label: 'Offline / Berhenti', color: '#EF4444', badgeStyle: 'border-color: rgba(239,68,68,0.3); background: rgba(239,68,68,0.1); color: #EF4444;' };
  if (myBot.status === 'online') {
    statusInfo = { label: 'Terhubung Online', color: '#22C55E', badgeStyle: 'border-color: rgba(34,197,94,0.3); background: rgba(34,197,94,0.1); color: #22C55E;' };
  } else if (myBot.status === 'await_otp' || myBot.tgOtpRequired) {
    statusInfo = { label: 'Menunggu OTP Telegram', color: '#38BDF8', badgeStyle: 'border-color: rgba(56,189,248,0.4); background: rgba(56,189,248,0.12); color: #38BDF8;' };
  } else if (myBot.status === 'await_2fa' || myBot.tg2faRequired) {
    statusInfo = { label: 'Menunggu Sandi 2FA', color: '#FBBF24', badgeStyle: 'border-color: rgba(245,158,11,0.4); background: rgba(245,158,11,0.12); color: #FBBF24;' };
  } else if (['pairing', 'qr'].includes(myBot.status)) {
    statusInfo = { label: myBot.pairMethod === 'qr' ? 'Menunggu Scan QR' : 'Menunggu Pairing', color: '#F59E0B', badgeStyle: 'border-color: rgba(245,158,11,0.3); background: rgba(245,158,11,0.1); color: #F59E0B;' };
  } else if (['starting', 'queued', 'connecting', 'reconnecting'].includes(myBot.status)) {
    statusInfo = { label: 'Menghubungkan...', color: '#38BDF8', badgeStyle: 'border-color: rgba(56,189,248,0.3); background: rgba(56,189,248,0.1); color: #38BDF8;' };
  }

  let expDateStr = 'Unlimited (Permanen)';
  if (!isUnlimitedBot && myBot.expiresAt) {
    try {
      expDateStr = new Date(myBot.expiresAt).toLocaleString('id-ID', {
        day: 'numeric', month: 'short', year: 'numeric',
        hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta'
      }) + ' WIB';
    } catch (_) {
      expDateStr = '-';
    }
  }

  let percentLeft = 100;
  if (!isUnlimitedBot && myBot.durationHours && myBot.expiresAt) {
    const totalMs = myBot.durationHours * 3600000;
    percentLeft = Math.max(0, Math.min(100, Math.round((remMs / totalMs) * 100)));
  }

  let taskName = myBot.activity?.name || 'Standby';
  if (myBot.activity && myBot.activity.name) {
    taskName = myBot.activity.name;
  } else {
    if (isTgBot) {
      if (myBot.status === 'await_otp' || myBot.tgOtpRequired) {
        taskName = 'Kode OTP telah dikirim oleh Telegram · Masukkan kode di web.';
      } else if (myBot.status === 'await_2fa' || myBot.tg2faRequired) {
        taskName = 'Akun memiliki 2FA Cloud Password · Masukkan kata sandi di web.';
      } else {
        taskName = isOnline ? 'Userbot Telegram Aktif (Siap Menerima Perintah)' : 'Userbot Berhenti';
      }
    } else {
      if (myBot.qr?.code) {
        taskName = 'Menyiapkan QR Code login WhatsApp...';
      } else if (myBot.pairing?.code) {
        taskName = `Menunggu tautan WhatsApp (Kode: ${myBot.pairing.code})`;
      } else if (['starting', 'queued', 'connecting', 'pairing', 'reconnecting'].includes(myBot.status)) {
        taskName = 'Menghubungkan & menunggu kode pairing...';
      } else {
        taskName = isOnline ? 'Standby (Siap Menerima Perintah)' : 'Bot Berhenti';
      }
    }
  }
  const taskProgress = myBot.activity?.total ? ` · ${myBot.activity.done}/${myBot.activity.total}` : '';

  const botNumBadge = totalBots > 1 ? `<span class="deploy-bot-num-badge">BOT #${botIndex + 1}</span>` : '';
  const consolePillOrBtn = isSelectedConsole
    ? `<span class="deploy-console-active-pill">🟢 KONSOL TERPILIH</span>`
    : `<button type="button" class="deploy-btn-switch-console" onclick="switchActiveConsoleBot('${myBot.id}')" title="Buka terminal konsol bot ini"><span>📺 Buka Konsol</span></button>`;

  return `
    <div class="deploy-account-item ${isExpired ? 'is-expired' : (isOnline ? 'is-online' : '')}">
      <!-- Header Baris Atas: Info Nomor & Live Status -->
      <div class="deploy-bot-hero-line">
        <div class="deploy-phone-display">
          <div class="deploy-phone-avatar">
            <img src="images/logo.jpeg" alt="AGAAHOST">
          </div>
          <div>
            <div class="deploy-phone-label" style="display:flex; align-items:center; gap:6px;">
              <span>${isTgBot ? 'USERBOT TELEGRAM' : 'BOT WHATSAPP KAMU'}</span>
              ${isTgBot ? `<span class="tg-platform-badge">UBOT</span>` : ''}
              ${botNumBadge}
            </div>
            <div class="deploy-phone-val">
              <span>+${myBot.phone}</span>
              <button type="button" class="deploy-inline-copy-btn" onclick="copyPairingCode('${myBot.phone}', this)" title="Salin Nomor Bot">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
              </button>
            </div>
          </div>
        </div>
        <div style="display:flex; align-items:center; gap:8px;">
          ${consolePillOrBtn}
          <div class="deploy-bot-status-pill" style="${statusInfo.badgeStyle}">
            <span class="deploy-status-beacon" style="background:${statusInfo.label === 'Terhubung Online' ? '#22C55E' : (isExpired ? '#EF4444' : (isTgBot ? '#38BDF8' : '#F59E0B'))};"></span>
            <span>${statusInfo.label}</span>
          </div>
        </div>
      </div>

      <!-- Action Banner jika bot Telegram memerlukan OTP atau 2FA -->
      ${(isTgBot && (myBot.status === 'await_otp' || myBot.tgOtpRequired)) ? `
        <div style="margin-bottom: 14px; padding: 12px 14px; border-radius: 10px; background: rgba(34,158,217,0.12); border: 1px solid rgba(34,158,217,0.35); display: flex; align-items: center; justify-content: space-between; gap: 10px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 1.2rem;">📱</span>
            <div>
              <strong style="font-size: 0.8rem; color: #FFF; display: block;">Menunggu Kode OTP</strong>
              <span style="font-size: 0.72rem; color: #94A3B8;">Kode dikirim ke aplikasi Telegram resmi</span>
            </div>
          </div>
          <button type="button" class="btn-open-tg-auth" onclick="window.openTelegramOtpModal('${myBot.id}', '${myBot.phone}', false)">
            <span>Ketik Kode OTP</span>
          </button>
        </div>
      ` : ''}

      ${(isTgBot && (myBot.status === 'await_2fa' || myBot.tg2faRequired)) ? `
        <div style="margin-bottom: 14px; padding: 12px 14px; border-radius: 10px; background: rgba(245,158,11,0.12); border: 1px solid rgba(245,158,11,0.35); display: flex; align-items: center; justify-content: space-between; gap: 10px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 1.2rem;">🔒</span>
            <div>
              <strong style="font-size: 0.8rem; color: #FFF; display: block;">Perlu Kata Sandi 2FA</strong>
              <span style="font-size: 0.72rem; color: #94A3B8;">Akun menggunakan 2-Step Verification</span>
            </div>
          </div>
          <button type="button" class="btn-open-tg-auth" style="background: linear-gradient(135deg, #F59E0B, #D97706);" onclick="window.openTelegramOtpModal('${myBot.id}', '${myBot.phone}', true, '${escapeHtml(myBot.hint || '')}')">
            <span>Ketik Sandi 2FA</span>
          </button>
        </div>
      ` : ''}

      <!-- Widget Masa Aktif & Live Countdown Timer -->
      <div class="deploy-countdown-card ${isExpired ? 'is-expired' : (isUnlimitedBot ? 'is-unlimited' : (remMs < 7200000 ? 'is-warning' : ''))}">
        <div class="deploy-countdown-header">
          <div class="cd-header-left">
            <span class="cd-pulse-dot ${isExpired ? 'red' : (isUnlimitedBot ? 'cyan' : (remMs < 7200000 ? 'amber' : 'green'))}"></span>
            <span class="cd-title">MASA AKTIF BOT</span>
          </div>
          <span class="cd-status-badge ${isExpired ? 'badge-expired' : (isUnlimitedBot ? 'badge-unlimited' : (remMs < 7200000 ? 'badge-warning' : 'badge-active'))}">
            ${isExpired ? 'HABIS (EXPIRED)' : (isUnlimitedBot ? 'UNLIMITED' : (remMs < 7200000 ? 'HAMPIR HABIS' : 'AKTIF'))}
          </span>
        </div>
        
        <div class="deploy-countdown-digits-wrap">
          ${isExpired ? `
            <div class="deploy-countdown-expired-label">MASA AKTIF TELAH BERAKHIR</div>
          ` : (isUnlimitedBot ? `
            <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; width:100%; padding:8px 0;">
              <div style="font-family:var(--font-mono); font-size:1.15rem; font-weight:800; color:#38BDF8; letter-spacing:1px;">UNLIMITED</div>
              <div style="font-size:0.7rem; color:#94A3B8; margin-top:3px;">Tergantung Ketersediaan Server</div>
            </div>
          ` : `
            <div class="deploy-countdown-digit-box">
              <span class="cd-digit-val">${String(hours).padStart(2, '0')}</span>
              <span class="cd-digit-lbl">JAM</span>
            </div>
            <span class="cd-digit-colon">:</span>
            <div class="deploy-countdown-digit-box">
              <span class="cd-digit-val">${String(mins).padStart(2, '0')}</span>
              <span class="cd-digit-lbl">MENIT</span>
            </div>
            <span class="cd-digit-colon">:</span>
            <div class="deploy-countdown-digit-box">
              <span class="cd-digit-val">${String(secs).padStart(2, '0')}</span>
              <span class="cd-digit-lbl">DETIK</span>
            </div>
          `)}
        </div>

        <!-- Progress Bar Sisa Masa Aktif -->
        <div class="deploy-countdown-track">
          <div class="deploy-countdown-fill ${isExpired ? 'fill-expired' : (isUnlimitedBot ? 'fill-unlimited' : (remMs < 7200000 ? 'fill-warning' : 'fill-active'))}" style="width: ${percentLeft}%; ${isUnlimitedBot ? 'background:#38BDF8;' : ''}"></div>
        </div>

        <div class="deploy-countdown-footer">
          <span class="cd-exp-date">Berlaku s/d: <b>${expDateStr}</b></span>
          ${(!isUnlimitedBot && (isExpired || remMs < 14400000)) ? `
            <a href="https://wa.me/6285879220690?text=Halo%20Owner%20AF%20STORE,%20saya%20ingin%20perpanjang%20durasi%20deploy%20bot%20WhatsApp%20nomor%20%2B${myBot.phone}" target="_blank" class="deploy-extend-link-btn">
              ➕ Perpanjang via Owner
            </a>
          ` : ''}
        </div>
      </div>

      <!-- Telemetri Mini Grid (RAM, CPU, Penautan) -->
      <div class="deploy-telemetry-grid">
        <div class="deploy-telem-card">
          <span class="telem-lbl">MEMORI RAM</span>
          <span class="telem-val">${myBot.rssMB ?? 0} MB</span>
        </div>
        <div class="deploy-telem-card">
          <span class="telem-lbl">BEBAN CPU</span>
          <span class="telem-val">${myBot.cpuPercent ?? 0}%</span>
        </div>
        <div class="deploy-telem-card">
          <span class="telem-lbl">VERSI BOT</span>
          <span class="telem-val ${isPremiumBot ? 'val-premium' : 'val-free'}">${isPremiumBot ? 'PREMIUM' : 'FREE'}</span>
        </div>
      </div>

      <!-- Aktivitas Saat Ini -->
      <div class="deploy-activity-box">
        <div class="deploy-activity-header">
          <span class="act-icon">⚡</span>
          <span class="act-title">AKTIVITAS SAAT INI</span>
        </div>
        <div class="deploy-activity-text">${escapeHtml(taskName + taskProgress)}</div>
        ${myBot.disablePromo ? `<div class="deploy-activity-text">Anti-promosi: ${myBot.promoSync?.state === 'applied' ? 'Sudah diterapkan ke bot' : myBot.promoSync?.state === 'on_next_start' || ['stopped', 'error'].includes(myBot.status) ? 'Diterapkan saat bot mulai' : 'Menunggu sinkronisasi'}</div>` : ''}
      </div>

      <!-- Action Control Buttons -->
      <div class="deploy-account-actions">
        <button class="deploy-btn-act act-start" ${(isOnline && !isExpired) ? 'disabled' : (isExpired ? 'disabled' : '')} onclick="handleDeployAction('start', '${myBot.id}')" title="${isExpired ? 'Masa aktif bot telah habis' : 'Jalankan bot'}">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
          <span>${isExpired ? 'Expired' : 'Mulai'}</span>
        </button>
        <button class="deploy-btn-act act-stop" ${!isOnline ? 'disabled' : ''} onclick="handleDeployAction('stop', '${myBot.id}')" title="Hentikan sementara bot">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="6" y="6" width="12" height="12"></rect></svg>
          <span>Hentikan</span>
        </button>
        <button class="deploy-btn-act act-pass" onclick="openSetPasswordModal('${myBot.id}', '${myBot.phone}', ${Boolean(myBot.hasPassword)})" title="Atur password pengaman bot">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0110 0v4"></path></svg>
          <span>${myBot.hasPassword ? 'Ganti PIN' : 'Kunci PIN'}</span>
        </button>
        <button class="deploy-btn-act act-del" onclick="handleDeployDelete('+${myBot.phone}', '${myBot.id}')" title="Hapus bot dan sesi permanen">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"></path></svg>
          <span>Hapus</span>
        </button>
      </div>

      ${isExpired ? `
        <div class="deploy-expired-alert-banner">
          Masa aktif bot telah berakhir. Perpanjang via Owner: <a href="https://wa.me/6285879220690?text=Halo%20Owner%20AF%20STORE,%20saya%20ingin%20perpanjang%20durasi%20deploy%20bot%20WhatsApp%20nomor%20%2B${myBot.phone}" target="_blank">Chat WhatsApp Owner</a>
        </div>
      ` : ''}
    </div>
  `;
}

async function refreshDeployStatus() {
  if (isDeployBusy) return;
  if (!isDeployGateUnlocked()) return;
  isDeployBusy = true;
  const currentSeq = ++deployPollSequence;

  try {
    // 1. Ambil ringkasan kuota publik untuk 4 stat card
    const statData = await safeDeployGet('/api/deploy/status', {
      online: false,
      registered: null,
      running: null,
      freeSlots: null
    });

    if (currentSeq !== deployPollSequence) return;

    const regEl = document.getElementById('web-deploy-registered');
    const runEl = document.getElementById('web-deploy-running');
    const slotEl = document.getElementById('web-deploy-slots');
    const engEl = document.getElementById('web-deploy-engine-status');
    const heroDot = document.getElementById('web-deploy-hero-dot');
    const heroText = document.getElementById('web-deploy-hero-text');
    const submitBtn = document.getElementById('web-deploy-submit-btn');
    const offlineNotice = document.getElementById('deploy-offline-notice');

    if (statData.online && statData.active !== false) {
      window.__isDeployActive = true;
      if (offlineNotice) offlineNotice.style.display = 'none';
      if (regEl) regEl.textContent = `${statData.registered || 0} / ${statData.maxAccounts || 25}`;
      if (runEl) runEl.textContent = `${statData.running || 0} Aktif`;
      if (slotEl) slotEl.textContent = `${statData.freeSlots != null ? statData.freeSlots : '0'} Slot`;
      if (engEl) {
        engEl.textContent = 'Server Online';
        engEl.style.color = '#4ADE80';
      }
      if (heroDot) {
        heroDot.style.background = '#22C55E';
        heroDot.style.boxShadow = '0 0 6px #22C55E';
      }
      if (heroText) heroText.textContent = 'LAYANAN BOT ONLINE · SC JPM v13.5.5';

      if (submitBtn) {
        if (statData.freeSlots != null && statData.freeSlots <= 0) {
          submitBtn.disabled = true;
          const span = submitBtn.querySelector('span');
          if (span) span.textContent = 'Kapasitas Server Penuh';
        } else {
          submitBtn.disabled = false;
          const span = submitBtn.querySelector('span');
          if (span) span.textContent = 'Mulai Deploy & Tautkan Bot';
        }
      }
    } else {
      window.__isDeployActive = false;
      if (offlineNotice) offlineNotice.style.display = 'flex';
      if (regEl) regEl.textContent = '—';
      if (runEl) runEl.textContent = '—';
      if (slotEl) slotEl.textContent = '—';
      if (engEl) {
        engEl.textContent = 'Layanan sedang tidak aktif';
        engEl.style.color = '#EF4444';
      }
      if (heroDot) {
        heroDot.style.background = '#EF4444';
        heroDot.style.boxShadow = '0 0 6px #EF4444';
      }
      if (heroText) heroText.textContent = 'LAYANAN SEDANG TIDAK AKTIF';

      if (submitBtn) {
        submitBtn.disabled = true;
        const span = submitBtn.querySelector('span');
        if (span) span.textContent = 'Layanan Sedang Tidak Aktif';
      }
    }

    const pairingBox = document.getElementById('web-deploy-pairing-box');
    const pairingCodeEl = document.getElementById('web-deploy-pairing-code');
    const qrBox = document.getElementById('web-deploy-qr-box');
    const qrImg = document.getElementById('web-deploy-qr-img');
    const qrSpinner = document.getElementById('web-deploy-qr-spinner');
    const qrTimer = document.getElementById('web-deploy-qr-timer');
    const qrLink = document.getElementById('web-deploy-qr-link');
    const container = document.getElementById('web-deploy-accounts-container');
    const consoleCard = document.getElementById('web-deploy-console-card');
    const consoleBody = document.getElementById('web-deploy-console-body');
    const consoleStatus = document.getElementById('web-deploy-terminal-status');
    const consoleDot = document.getElementById('web-deploy-terminal-dot');

    // Ambil daftar bot tertaut
    let linkedList = getLinkedBots();
    let activeBotId = getActiveDeployId();
    const savedPhone = localStorage.getItem('af_active_deploy_phone');

    if (activeBotId && !linkedList.some(b => b.id === activeBotId)) {
      linkedList.unshift({ id: activeBotId, phone: savedPhone || '' });
    }

    if (linkedList.length === 0 && savedPhone) {
      try {
        const checkData = await safeDeployGet(`/api/deploy/bot-by-phone/${savedPhone}`, { online: false, exists: false });
        if (checkData.exists && checkData.bot) {
          activeBotId = checkData.bot.id;
          addLinkedBot(activeBotId, savedPhone);
          linkedList = getLinkedBots();
        }
      } catch {}
    }

    const validBots = [];
    if (linkedList.length > 0) {
      const fetchResults = await Promise.all(
        linkedList.map(async (item) => {
          try {
            const token = getBotToken(item.id);
            const headers = token ? { 'x-bot-token': token } : {};
            const res = await safeDeployGet(`/api/deploy/bot/${item.id}`, { online: false, exists: false }, headers);
            return { item, data: res };
          } catch (e) {
            return { item, data: { exists: false, error: e.message } };
          }
        })
      );

      for (const res of fetchResults) {
        if (res.data && res.data.exists && res.data.bot) {
          validBots.push({
            bot: res.data.bot,
            events: res.data.events || []
          });
          if (res.data.bot.allowDualAccount) {
            localStorage.setItem('af_allow_dual_account', '1');
          }
        } else if (res.data && (res.data.exists === false || res.data.code === 'BOT_NOT_FOUND' || res.data.code === 'NOT_FOUND')) {
          removeLinkedBot(res.item.id);
        }
      }
    }

    if (validBots.length > 0) {
      deployBotMissingCycles = 0;

      // Pastikan activeBotId menunjuk ke salah satu bot yang valid
      if (!activeBotId || !validBots.some(item => item.bot.id === activeBotId)) {
        activeBotId = validBots[0].bot.id;
        setActiveDeployId(activeBotId);
        localStorage.setItem('af_active_deploy_phone', validBots[0].bot.phone);
      }

      const selectedBotItem = validBots.find(item => item.bot.id === activeBotId) || validBots[0];
      const myBot = selectedBotItem.bot;
      const rawEvents = selectedBotItem.events || [];

      // Visibilitas formulir & pembatas kuota Dual Akun
      const isDualAllowed = localStorage.getItem('af_allow_dual_account') === '1' || validBots.some(b => b.bot.allowDualAccount);
      const limitNotice = document.getElementById('deploy-limit-notice');
      const limitPhone = document.getElementById('deploy-limit-active-phone');
      const formWorkspace = document.getElementById('deploy-form-workspace');

      if (validBots.length >= 2) {
        if (limitNotice) {
          limitNotice.style.display = 'block';
          limitNotice.style.background = 'rgba(34, 197, 94, 0.08)';
          limitNotice.style.borderColor = 'rgba(34, 197, 94, 0.25)';
          if (limitPhone) {
            limitPhone.innerHTML = `Maksimal 2 Bot Tercapai: <b>+${escapeHtml(validBots[0].bot.phone)}</b> &amp; <b>+${escapeHtml(validBots[1].bot.phone)}</b>`;
          }
        }
        if (formWorkspace) formWorkspace.style.display = 'none';
      } else if (validBots.length === 1) {
        if (isDualAllowed) {
          if (limitNotice) {
            limitNotice.style.display = 'block';
            limitNotice.style.background = 'rgba(56, 189, 248, 0.08)';
            limitNotice.style.borderColor = 'rgba(56, 189, 248, 0.25)';
            if (limitPhone) {
              limitPhone.innerHTML = `Mode Dual Akun Aktif (1/2 Slot Terpakai). Bot 1: <b>+${escapeHtml(validBots[0].bot.phone)}</b>. Masukkan nomor kedua di formulir berikut untuk deploy bot ke-2!`;
            }
          }
          if (formWorkspace) formWorkspace.style.display = 'grid';
        } else {
          if (limitNotice) {
            limitNotice.style.display = 'block';
            if (limitPhone) limitPhone.textContent = '+' + validBots[0].bot.phone;
          }
          if (formWorkspace) formWorkspace.style.display = 'none';
        }
      }

      // Deteksi bot yang sedang dalam proses pairing / QR
      const pairingBotItem = validBots.find(item => 
        ['starting', 'queued', 'connecting', 'pairing', 'qr', 'reconnecting'].includes(item.bot.status) ||
        (item.bot.pairing && item.bot.pairing.expiresAt > Date.now()) ||
        (item.bot.qr && item.bot.qr.expiresAt > Date.now())
      ) || selectedBotItem;

      const pBot = pairingBotItem.bot;
      const isQrMode = pBot.pairMethod === 'qr';
      const isTgPairing = pBot.platform === 'telegram' || (pBot.template && String(pBot.template).startsWith('tg'));

      if (pBot.status === 'online') {
        window.__lastSeenPairingCode = null;
        window.__shouldScrollToPairing = false;
        if (pairingBox) pairingBox.style.display = 'none';
        if (qrBox) qrBox.style.display = 'none';
      } else if (isTgPairing) {
        if (pairingBox) pairingBox.style.display = 'none';
        if (qrBox) qrBox.style.display = 'none';

        if (pBot.status === 'await_otp' || pBot.tgOtpRequired) {
          const tgModal = document.getElementById('modal-tg-otp-overlay');
          if (tgModal && tgModal.style.display !== 'flex' && window.__lastAutoOpenedOtp !== pBot.id + '_otp') {
            window.__lastAutoOpenedOtp = pBot.id + '_otp';
            window.openTelegramOtpModal(pBot.id, pBot.phone, false);
          }
        } else if (pBot.status === 'await_2fa' || pBot.tg2faRequired) {
          const tgModal = document.getElementById('modal-tg-otp-overlay');
          if (tgModal && (tgModal.style.display !== 'flex' || document.getElementById('tg-step-2fa')?.style.display !== 'block') && window.__lastAutoOpenedOtp !== pBot.id + '_2fa') {
            window.__lastAutoOpenedOtp = pBot.id + '_2fa';
            window.openTelegramOtpModal(pBot.id, pBot.phone, true, pBot.hint || '');
          }
        }
      } else if (isQrMode) {
        if (pairingBox) pairingBox.style.display = 'none';
        if (qrBox) {
          qrBox.style.display = 'block';
          if (pBot.qr && pBot.qr.code && pBot.qr.expiresAt > Date.now()) {
            const qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=8&data=' + encodeURIComponent(pBot.qr.code);
            if (qrImg) {
              if (qrImg.getAttribute('data-raw-qr') !== pBot.qr.code) {
                qrImg.setAttribute('data-raw-qr', pBot.qr.code);
                qrImg.src = qrUrl;
              }
              qrImg.style.display = 'block';
            }
            if (qrSpinner) qrSpinner.style.display = 'none';
            if (qrLink) {
              qrLink.href = qrUrl;
              qrLink.style.display = 'inline-flex';
            }
            if (qrTimer) {
              const secLeft = Math.max(0, Math.ceil((pBot.qr.expiresAt - Date.now()) / 1000));
              qrTimer.textContent = `REFRESH: ${secLeft}s`;
            }
          } else if (['starting', 'queued', 'connecting', 'pairing', 'qr', 'reconnecting'].includes(pBot.status)) {
            if (qrImg) qrImg.style.display = 'none';
            if (qrSpinner) qrSpinner.style.display = 'flex';
            if (qrLink) qrLink.style.display = 'none';
            if (qrTimer) qrTimer.textContent = 'MENYIAPKAN QR...';
          } else {
            qrBox.style.display = 'none';
          }

          if (window.__shouldScrollToPairing && qrBox.style.display !== 'none') {
            window.__shouldScrollToPairing = false;
            setTimeout(() => {
              qrBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
              qrBox.classList.add('highlight-focus');
              setTimeout(() => qrBox.classList.remove('highlight-focus'), 1200);
            }, 100);
          }
        }
      } else {
        if (qrBox) qrBox.style.display = 'none';
        if (pBot.pairing && pBot.pairing.expiresAt > Date.now()) {
          if (pairingBox) pairingBox.style.display = 'block';
          if (pairingCodeEl) {
            pairingCodeEl.textContent = pBot.pairing.code;
            pairingCodeEl.style.color = '#FFFFFF';
            pairingCodeEl.style.letterSpacing = '0.15em';
          }
          if (pBot.pairing.code && (window.__shouldScrollToPairing || window.__lastSeenPairingCode !== pBot.pairing.code)) {
            window.__lastSeenPairingCode = pBot.pairing.code;
            window.__shouldScrollToPairing = false;
            setTimeout(() => {
              pairingBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
              pairingBox.classList.add('highlight-focus');
              setTimeout(() => pairingBox.classList.remove('highlight-focus'), 1200);
            }, 100);
          }
        } else if (['starting', 'queued', 'connecting', 'pairing', 'reconnecting'].includes(pBot.status)) {
          if (pairingBox) pairingBox.style.display = 'block';
          if (pairingCodeEl) {
            pairingCodeEl.textContent = 'MENUNGGU KODE...';
            pairingCodeEl.style.color = '#FBBF24';
            pairingCodeEl.style.letterSpacing = '0.08em';
          }
          if (window.__shouldScrollToPairing) {
            window.__shouldScrollToPairing = false;
            setTimeout(() => {
              pairingBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
              pairingBox.classList.add('highlight-focus');
              setTimeout(() => pairingBox.classList.remove('highlight-focus'), 1200);
            }, 100);
          }
        } else {
          if (pairingBox) pairingBox.style.display = 'none';
        }
      }

      // Render Kartu Bot Pribadi Pengguna (Multi-Bot Grid View)
      if (container) {
        container.innerHTML = validBots.map((item, idx) => {
          const isSelectedConsole = item.bot.id === activeBotId;
          return renderBotItemHtml(item.bot, isSelectedConsole, validBots.length, idx);
        }).join('');
      }

      // Render Tab Switcher Konsol Bot (Jika ada > 1 bot)
      const consoleTabs = document.getElementById('web-deploy-console-tabs');
      if (consoleTabs) {
        if (validBots.length > 1) {
          consoleTabs.style.display = 'flex';
          consoleTabs.innerHTML = `
            <div style="font-size: 0.75rem; font-weight: 700; color: #94A3B8; margin-right: 4px; display: flex; align-items: center; gap: 4px;">
              <span>📺 PILIH KONSOL BOT:</span>
            </div>
            ${validBots.map((item, idx) => {
              const isAct = item.bot.id === activeBotId;
              const isOnline = item.bot.status === 'online';
              const tierBadge = (item.bot.tier === 'premium' || item.bot.template === 'wa-buy') ? 'PREMIUM' : 'FREE';
              return `
                <button type="button" class="term-bot-tab ${isAct ? 'active' : ''}" onclick="switchActiveConsoleBot('${item.bot.id}')">
                  <span class="deploy-status-beacon" style="background:${isOnline ? '#22C55E' : '#EF4444'}; width:7px; height:7px;"></span>
                  <span>BOT #${idx + 1} (+${item.bot.phone})</span>
                  <span style="font-size: 0.65rem; opacity: 0.8; padding: 1px 4px; border-radius: 3px; background: rgba(255,255,255,0.08);">${tierBadge}</span>
                </button>
              `;
            }).join('')}
          `;
        } else {
          consoleTabs.style.display = 'none';
          consoleTabs.innerHTML = '';
        }
      }

        // Render Live Console Terminal (Animasi & Log Lengkap)
        if (consoleCard && consoleBody) {
          consoleCard.style.display = 'block';
          const isActive = !['stopped', 'error'].includes(myBot.status);
          const isPairing = ['pairing', 'qr'].includes(myBot.status) || (myBot.pairing && myBot.pairing.expiresAt > Date.now()) || (myBot.qr && myBot.qr.expiresAt > Date.now());

          if (consoleStatus) {
            const isTgConsole = myBot.platform === 'telegram' || (myBot.template && String(myBot.template).startsWith('tg'));
            if (isTgConsole && myBot.status === 'await_otp') {
              consoleStatus.textContent = 'MENUNGGU OTP TELEGRAM';
              consoleStatus.style.color = '#38BDF8';
              consoleStatus.style.background = 'rgba(56, 189, 248, 0.12)';
              consoleStatus.style.borderColor = 'rgba(56, 189, 248, 0.35)';
            } else if (isTgConsole && myBot.status === 'await_2fa') {
              consoleStatus.textContent = 'MENUNGGU SANDI 2FA';
              consoleStatus.style.color = '#FBBF24';
              consoleStatus.style.background = 'rgba(245, 158, 11, 0.12)';
              consoleStatus.style.borderColor = 'rgba(245, 158, 11, 0.35)';
            } else if (isPairing) {
              consoleStatus.textContent = isQrMode ? 'MENUNGGU SCAN QR' : 'MENUNGGU PAIRING';
              consoleStatus.style.color = '#FBBF24';
              consoleStatus.style.background = 'rgba(245, 158, 11, 0.12)';
              consoleStatus.style.borderColor = 'rgba(245, 158, 11, 0.35)';
            } else if (isActive) {
              consoleStatus.textContent = isTgConsole ? 'UBOT · ONLINE' : 'TERTAUT · ONLINE';
              consoleStatus.style.color = isTgConsole ? '#38BDF8' : '#4ADE80';
              consoleStatus.style.background = isTgConsole ? 'rgba(34, 158, 217, 0.12)' : 'rgba(34, 197, 94, 0.12)';
              consoleStatus.style.borderColor = isTgConsole ? 'rgba(34, 158, 217, 0.35)' : 'rgba(34, 197, 94, 0.35)';
            } else {
              consoleStatus.textContent = 'STANDBY';
              consoleStatus.style.color = '#94A3B8';
              consoleStatus.style.background = 'rgba(148, 163, 184, 0.1)';
              consoleStatus.style.borderColor = 'rgba(148, 163, 184, 0.3)';
            }
          }

          if (consoleDot) {
            if (isPairing) {
              consoleDot.style.background = '#FBBF24';
              consoleDot.style.boxShadow = '0 0 8px #FBBF24';
            } else if (isActive) {
              consoleDot.style.background = '#10B981';
              consoleDot.style.boxShadow = '0 0 8px #10B981';
            } else {
              consoleDot.style.background = '#64748B';
              consoleDot.style.boxShadow = 'none';
            }
          }

          const heartbeatHud = document.getElementById('web-deploy-heartbeat-hud');
          let liveHeartbeat = myBot.heartbeat || null;

          function isHeartbeatLine(str) {
            if (!str || typeof str !== 'string') return false;
            return /WA:\s*(ONLINE|OFFLINE|CONNECTING)/i.test(str) ||
                   (/CPU:\s*[\d.]+/i.test(str) && /RAM:\s*\d+/i.test(str)) ||
                   /JADWAL:\s*/i.test(str) ||
                   /^[╭├╰┌└─\s]*[🟢🔴⚪💻🖥⏰⏱🕒⚡⚙]/i.test(str);
          }

          function parseHeartbeatInto(str, target) {
            if (!str || typeof str !== 'string' || !target) return;
            if (/WA:\s*(ONLINE|OFFLINE|CONNECTING)/i.test(str)) {
              const waMatch = str.match(/WA:\s*([A-Za-z]+)/i);
              const pingMatch = str.match(/(\d+\s*ms)/i);
              const timeMatch = str.match(/(\d{2}:\d{2}:\d{2})/);
              if (waMatch) target.status = waMatch[1].toUpperCase();
              if (pingMatch) target.ping = pingMatch[1].replace(/\s+/g, '');
              if (timeMatch) target.time = timeMatch[1];
            } else if (/CPU:\s*[\d.]+/i.test(str) && /RAM:\s*\d+/i.test(str)) {
              const cpuMatch = str.match(/CPU:\s*([\d.]+%\s*)/i);
              const ramMatch = str.match(/RAM:\s*(\d+[A-Za-z]*)/i);
              const stateMatch = str.match(/(STANDBY|AKTIF|BUSY|IDLE)/i);
              if (cpuMatch) target.cpu = cpuMatch[1].trim();
              if (ramMatch) target.ram = ramMatch[1];
              if (stateMatch) target.state = stateMatch[1].toUpperCase();
            } else if (/JADWAL:\s*/i.test(str)) {
              const jMatch = str.match(/JADWAL:\s*([^\s\]│|]+(?:\s*\[[^\]]+\])?)/i);
              if (jMatch) target.jadwal = jMatch[1].trim();
            }
          }

          // Kompresi frame animasi berulang / spinner & pisahkan Heartbeat agar tidak memenuhi terminal
          const events = [];
          let lastAnimKey = null;
          let activeProsesEvent = null;

          function getProgressKey(str) {
            if (!str || typeof str !== 'string') return null;
            const core = str
              .replace(/[\u2800-\u28FF]/g, '')
              .replace(/^[╭├╰┌└─\s]+/, '')
              .replace(/^[\/\\|\-]\s*/, '')
              .replace(/\.+$/, '')
              .trim();
            const hasSpinner = /[\u2800-\u28FF]|[\/\\|\-]/.test(str);
            const isProgressWord = /^(memuat|sinkronisasi|loading|syncing|connecting|menghubungkan)/i.test(core);
            if ((hasSpinner || isProgressWord) && core.length > 0) {
              return core.toLowerCase();
            }
            return null;
          }

          for (const ev of rawEvents) {
            const rawText = String(ev.text || '');

            // 1. Saring prompt readline CLI interaktif yang membingungkan dan sudah dijawab otomatis oleh worker
            if (/Ketik (ya|tidak|1|2|nomor|owner) lalu Enter/i.test(rawText) ||
                /Gunakan nomor terdaftar sebelumnya/i.test(rawText) ||
                /1\.\s*Kode Pairing \(via nomor HP\)/i.test(rawText) ||
                /2\.\s*QR Code \(scan kamera WA\)/i.test(rawText) ||
                /Atau ketik ya di pesan console/i.test(rawText) ||
                /3\.\s*Restart server di panel/i.test(rawText) ||
                /4\.\s*Lakukan pairing ulang/i.test(rawText) ||
                /1 atau 2 lalu Enter/i.test(rawText)) {
              continue; // Abaikan sampah prompt CLI yang membuat konsol berantakan
            }

            // Deteksi baris Heartbeat Monitor (WA: ONLINE, CPU, JADWAL)
            if (isHeartbeatLine(rawText)) {
              if (!liveHeartbeat) liveHeartbeat = {};
              parseHeartbeatInto(rawText, liveHeartbeat);
              continue; // PISAHKAN DARI LOG SCROLL: Disalurkan ke Live Animated HUD!
            }

            // 2. Tangkap baris proses spinner aktif (Auto SWGC / broadcast)
            // Hanya pertahankan tick proses terbaru, bersihkan tick lama dari riwayat agar persis seperti console panel
            const isProsesLine = /PROSES:\s*Auto\s*SWGC/i.test(rawText) || /╰─\s*[⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏]?\s*PROSES:/i.test(rawText);
            if (isProsesLine) {
              activeProsesEvent = ev;
              continue;
            }

            if (rawText.includes('Selesai broadcast') || rawText.includes('Auto SWGC Selesai') || rawText.includes('Berhenti')) {
              activeProsesEvent = null;
            }

            const animKey = getProgressKey(rawText);

            if (animKey) {
              if (lastAnimKey === animKey && events.length > 0) {
                events[events.length - 1] = ev;
                continue;
              }
              lastAnimKey = animKey;
            } else {
              if (events.length > 0 && events[events.length - 1].text === ev.text) {
                continue;
              }
              lastAnimKey = null;
            }
            events.push(ev);
          }

          // Letakkan satu baris PROSES spinner aktif di posisi paling bawah (persis konsol Pterodactyl)
          if (activeProsesEvent && myBot.status === 'online') {
            events.push(activeProsesEvent);
          }

          // Render Live Animated Heartbeat HUD di bagian atas konsol
          if (heartbeatHud) {
            if (myBot.status === 'online' || liveHeartbeat) {
              const hbStatus = liveHeartbeat?.status || (myBot.status === 'online' ? 'ONLINE' : myBot.status.toUpperCase());
              const hbPing = liveHeartbeat?.ping || '24ms';
              const hbTime = liveHeartbeat?.time || new Date().toLocaleTimeString('id-ID');
              const hbCpu = liveHeartbeat?.cpu || (myBot.cpuPercent != null ? myBot.cpuPercent + '%' : '0.1%');
              const hbRam = liveHeartbeat?.ram || (myBot.rssMB ? myBot.rssMB + 'M' : '141M');
              const hbState = liveHeartbeat?.state || (myBot.status === 'online' ? 'STANDBY' : 'STARTING');

              // Sinkronisasi Jadwal SWGC Otomatis (Ekstrak dari log atau sinkronkan dengan waktu pasang bot)
              let detectedJadwal = null;
              for (let rIdx = rawEvents.length - 1; rIdx >= 0; rIdx--) {
                const tLine = String(rawEvents[rIdx]?.text || '');
                const jm = tLine.match(/(?:Jadwal berikutnya|Jadwal berikutnya:)\s*([0-9/.,\s]*?)(\d{1,2}[:.]\d{1,2})/i);
                if (jm) {
                  detectedJadwal = `SWGC [${jm[2].replace('.', ':')}]`;
                  break;
                }
              }

              let fallbackJadwal = 'SWGC [STANDBY]';
              const firstEv = rawEvents.find(e => e.time);
              const installDate = firstEv ? new Date(firstEv.time) : (myBot.createdAt ? new Date(myBot.createdAt) : new Date());
              if (!isNaN(installDate.getTime())) {
                const timeStr = installDate.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }).replace('.', ':');
                fallbackJadwal = `SWGC [${timeStr}]`;
              }

              const hbJadwal = detectedJadwal || liveHeartbeat?.jadwal || fallbackJadwal;

              heartbeatHud.style.display = 'grid';
              heartbeatHud.innerHTML = `
                <div class="heartbeat-hud-card">
                  <div class="heartbeat-hud-header">
                    <span>KONEKSI</span>
                    <span class="heartbeat-ping-pill">⚡ ${escapeHtml(hbPing)}</span>
                  </div>
                  <div class="heartbeat-hud-content">
                    <span class="heartbeat-live-beacon"></span>
                    <span class="heartbeat-val-online">WA: ${escapeHtml(hbStatus)}</span>
                  </div>
                </div>

                <div class="heartbeat-hud-card">
                  <div class="heartbeat-hud-header">
                    <span>PERFORMA</span>
                    <span class="heartbeat-state-pill">⚙ ${escapeHtml(hbState)}</span>
                  </div>
                  <div class="heartbeat-hud-content">
                    <span class="heartbeat-metric-pill">💻 ${escapeHtml(hbCpu)}</span>
                    <span class="heartbeat-metric-pill">RAM ${escapeHtml(hbRam)}</span>
                  </div>
                </div>

                <div class="heartbeat-hud-card">
                  <div class="heartbeat-hud-header">
                    <span>JADWAL</span>
                    <span class="heartbeat-clock-text">🕒 ${escapeHtml(hbTime)}</span>
                  </div>
                  <div class="heartbeat-hud-content">
                    <span class="heartbeat-sched-pill">⏰ ${escapeHtml(hbJadwal)}</span>
                  </div>
                </div>
              `;
            } else {
              heartbeatHud.style.display = 'none';
            }
          }

          // Setup tombol Mode Log Terminal (Ringkas vs Lengkap)
          const btnMode = document.getElementById('btn-term-mode');
          const modeLabel = document.getElementById('term-mode-label');
          if (btnMode && !btnMode.dataset.bound) {
            btnMode.dataset.bound = 'true';
            btnMode.addEventListener('click', () => {
              deployLogFilterMode = deployLogFilterMode === 'clean' ? 'all' : 'clean';
              localStorage.setItem('af_deploy_log_mode', deployLogFilterMode);
              if (modeLabel) modeLabel.textContent = deployLogFilterMode === 'clean' ? 'Log Ringkas' : 'Semua Log';
              showDeployToast(deployLogFilterMode === 'clean' ? 'Mode log diubah: Hanya pesan penting (Ringkas)' : 'Mode log diubah: Menampilkan semua log aktivitas');
              consoleBody.dataset.lastFingerprint = '';
              refreshDeployStatus();
            });
          }
          if (modeLabel) {
            modeLabel.textContent = deployLogFilterMode === 'clean' ? 'Log Ringkas' : 'Semua Log';
          }

          // Setup tombol Bersihkan Terminal jika ada
          const btnClear = document.getElementById('btn-term-clear');
          if (btnClear && !btnClear.dataset.bound) {
            btnClear.dataset.bound = 'true';
            btnClear.addEventListener('click', () => {
              terminalClearedAt = Date.now();
              consoleBody.dataset.lastFingerprint = '';
              showDeployToast('Layar konsol terminal berhasil dibersihkan.');
              refreshDeployStatus();
            });
          }

          // Transformasi event mentah menjadi kartu event terstruktur & rapi (Anti-Pecah Box)
          const structuredEvents = parseAndBeautifyConsoleEvents(events, deployLogFilterMode);
          const displayEvents = terminalClearedAt > 0 
            ? structuredEvents.filter(e => new Date(e.time).getTime() >= terminalClearedAt) 
            : structuredEvents;

          const wasAtBottom = (consoleBody.scrollHeight - consoleBody.scrollTop) <= (consoleBody.clientHeight + 80);

          // Cek fingerprint log agar tidak re-render & tidak flicker jika tidak ada pembaruan log
          const currentFingerprint = terminalClearedAt + '|' + displayEvents.map(e => `${e.time}_${e.type || ''}_${(e.text || e.cmd || '').replace(/[\u2800-\u28FF]/g, '')}`).join('|');
          if (consoleBody.dataset.lastFingerprint === currentFingerprint) {
            return;
          }
          const prevFingerprint = consoleBody.dataset.lastFingerprint || '';
          consoleBody.dataset.lastFingerprint = currentFingerprint;

          if (displayEvents.length > 0) {
            const isInitialRender = !prevFingerprint;
            const recentEvents = displayEvents.slice(-60);
            const rows = recentEvents.map((row, index) => {
              const isNewest = !isInitialRender && index >= recentEvents.length - 2;
              const timeStr = new Date(row.time).toLocaleTimeString('id-ID', {
                hour: '2-digit', minute: '2-digit', second: '2-digit'
              });

              // 0. KARTU EVENT STARTUP BANNER AGAAHOST
              if (row.type === 'card_banner') {
                const wrap = document.createElement('div');
                wrap.className = 'deploy-log-card-wrap' + (isNewest ? ' entry-animate' : '');
                wrap.innerHTML = `
                  <div class="deploy-terminal-hero-banner">
                    <pre class="hero-banner-ascii">${escapeHtml(row.ascii1)}\n${escapeHtml(row.ascii2)}</pre>
                    <div class="hero-banner-sub">── ${escapeHtml(row.sub)} ──</div>
                    <div class="hero-banner-meta">
                      <span class="banner-pill pill-ver">${escapeHtml(row.version)}</span>
                      <span class="banner-pill pill-tier">[ ${escapeHtml(row.tier)} ]</span>
                      <span class="banner-pill pill-node">${escapeHtml(row.node)}</span>
                    </div>
                  </div>
                `;
                return wrap;
              }

              // 1. KARTU EVENT COMMAND (RESPONSIVE CYBER-GOTHIC CARD)
              if (row.type === 'card_cmd') {
                const isErr = row.status === 'ERROR';
                const wrap = document.createElement('div');
                wrap.className = 'deploy-log-card-wrap' + (isNewest ? ' entry-animate' : '');
                wrap.innerHTML = `
                  <div class="deploy-terminal-cmd-card ${isErr ? 'status-error' : 'status-success'}">
                    <div class="cmd-card-header">
                      <div class="cmd-title-group">
                        <span class="cmd-badge">⚡ COMMAND</span>
                        <span class="cmd-name">${escapeHtml(row.cmd)}</span>
                      </div>
                      <div class="cmd-badge-group">
                        <span class="cmd-status ${isErr ? 'error' : 'success'}">
                          <span class="cmd-status-dot"></span>
                          ${isErr ? '✗ GAGAL' : '✓ SUKSES'}
                        </span>
                        <span class="cmd-time">${escapeHtml(row.cmdTime || timeStr)}</span>
                      </div>
                    </div>
                    <div class="cmd-card-body">
                      <div class="cmd-meta">
                        <span class="cmd-lbl">PENGIRIM:</span>
                        <span class="cmd-val">${escapeHtml(row.user)}</span>
                      </div>
                      <div class="cmd-meta">
                        <span class="cmd-lbl">AKSES:</span>
                        <span class="cmd-val">${escapeHtml(row.mode)}</span>
                      </div>
                      <div class="cmd-meta">
                        <span class="cmd-lbl">STATUS:</span>
                        <span class="cmd-val ${isErr ? 'text-error' : 'text-success'}">${isErr ? 'ERROR RESPON' : 'RESPON TERKIRIM'}</span>
                      </div>
                      <div class="cmd-meta">
                        <span class="cmd-lbl">VERSI:</span>
                        <span class="cmd-val text-accent">${escapeHtml(row.version)}</span>
                      </div>
                    </div>
                  </div>
                `;
                return wrap;
              }

              // 2. KARTU EVENT BOT ONLINE (MENGGANTIKAN LISENSI RESMI AKTIF)
              if (row.type === 'card_license') {
                const wrap = document.createElement('div');
                wrap.className = 'deploy-log-card-wrap' + (isNewest ? ' entry-animate' : '');
                wrap.innerHTML = `
                  <div class="deploy-terminal-license-card bot-online-card">
                    <div class="card-lic-header">
                      <span class="lic-icon">🟢</span>
                      <span class="lic-title">BOT ONLINE</span>
                      <span class="lic-badge">[BOT ON]</span>
                    </div>
                    <div class="card-lic-body">
                      <span class="lic-detail">Nomor: <b>+${escapeHtml(row.account)}</b> · Status: <span class="text-online">Terhubung &amp; Siap Perintah</span></span>
                      <span class="lic-time">${timeStr}</span>
                    </div>
                  </div>
                `;
                return wrap;
              }

              // 3. KARTU EVENT INFO SERVER BOT
              if (row.type === 'card_info') {
                const wrap = document.createElement('div');
                wrap.className = 'deploy-log-card-wrap' + (isNewest ? ' entry-animate' : '');
                const cleanInfo = escapeHtml(String(row.text || '')
                  .replace(/🚀?\s*Server Bot WhatsApp Aktif · /i, '')
                  .replace(/Baileys(?!\s*AF\s*Store)(\s*MD)?/gi, 'Baileys AGAAHOST')
                  .replace(/Node\s*v?22(\.\d+)*/gi, 'Node v20.18.0'));
                wrap.innerHTML = `
                  <div class="deploy-terminal-info-card">
                    <div class="card-lic-header">
                      <span class="info-icon">⚡</span>
                      <span class="info-title">SERVER BOT AKTIF</span>
                      <span class="info-badge">[READY]</span>
                    </div>
                    <div class="card-lic-body">
                      <span class="info-text">${cleanInfo}</span>
                      <span class="info-time">${timeStr}</span>
                    </div>
                  </div>
                `;
                return wrap;
              }

              // 4. KARTU EVENT KODE PAIRING WHATSAPP (CYBER-NEON DEDICATED FULL WIDTH)
              if (row.type === 'card_pairing' || (row.text && String(row.text).includes('KODE PAIRING'))) {
                const wrap = document.createElement('div');
                wrap.className = 'deploy-log-card-wrap' + (isNewest ? ' entry-animate' : '');

                let rawText = String(row.text || '')
                  .replace(/Baileys(?!\s*AF\s*Store)(\s*MD)?/gi, 'Baileys AGAAHOST')
                  .replace(/Node\s*v?22(\.\d+)*/gi, 'Node v20.18.0');

                let pairingDigits = '';
                // 1. Ekstraksi kode pairing alfanumerik (format: XXXX-XXXX atau XXXXXXXX)
                const digitMatch = rawText.match(/([A-Z0-9]{4}-?[A-Z0-9]{4})\b/i);
                if (digitMatch && !digitMatch[1].toLowerCase().startsWith('akun')) {
                  pairingDigits = digitMatch[1].toUpperCase();
                }
                // 2. Jika tidak ada di regex digit, cek setelah tanda titik dua (:)
                if (!pairingDigits) {
                  const afterColon = rawText.match(/:\s*([A-Za-z0-9-]+)/);
                  if (afterColon && !afterColon[1].toLowerCase().startsWith('akun')) {
                    pairingDigits = afterColon[1].trim().toUpperCase();
                  }
                }
                // 3. Fallback ke object status controller
                if (!pairingDigits || pairingDigits.toLowerCase().startsWith('akun')) {
                  pairingDigits = (myBot && myBot.pairing?.code) ? myBot.pairing.code : (row.code || 'WAITING');
                }

                let cleanCode = pairingDigits.replace(/[^A-Z0-9]/gi, '').toUpperCase();
                let displayCode = pairingDigits;
                if (cleanCode.length === 8 && !cleanCode.includes('-')) {
                  displayCode = `${cleanCode.slice(0, 4)}-${cleanCode.slice(4)}`;
                }

                const isAkun1 = rawText.includes('akun1') || !rawText.includes('akun');
                const accountBadge = isAkun1 ? 'AKUN 1' : 'AKUN BOT';

                wrap.innerHTML = `
                  <div class="deploy-terminal-pairing-card">
                    <div class="pairing-card-header">
                      <div class="pairing-badge-left">
                        <span class="pairing-pulse-dot"></span>
                        <span class="pairing-card-title">KODE PAIRING WHATSAPP</span>
                        <span class="pairing-acc-badge">${accountBadge}</span>
                      </div>
                      <div class="pairing-timer-badge">
                        <span class="timer-pulse-icon">⏳</span> 60 DETIK
                      </div>
                    </div>
                    <div class="pairing-code-box">
                      <div class="pairing-code-digits">${escapeHtml(displayCode)}</div>
                      <button type="button" class="pairing-copy-btn" onclick="copyPairingCode('${escapeHtml(cleanCode || displayCode)}', this)" title="Salin Kode Pairing">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                        <span>SALIN</span>
                      </button>
                    </div>
                    <div class="pairing-card-guide">
                      <span class="guide-icon">📱</span>
                      <span>Buka WhatsApp di HP &gt; Titik Tiga (⋮) &gt; <b>Perangkat Tertaut</b> &gt; <b>Tautkan dengan nomor telepon</b></span>
                    </div>
                  </div>
                `;
                return wrap;
              }

              // 5. BARIS LOG BIASA
              const item = document.createElement('div');
              item.className = 'deploy-log-entry' + (isNewest ? ' entry-animate' : '');

              let rawText = String(row.text || '')
                .replace(/Baileys(?!\s*AF\s*Store)(\s*MD)?/gi, 'Baileys AGAAHOST')
                .replace(/Node\s*v?22(\.\d+)*/gi, 'Node v20.18.0');
              let tagClass = '';
              let msgHtml = escapeHtml(rawText);

              if (rawText.startsWith('[SISTEM]') || rawText.startsWith('[SANDBOX]')) {
                tagClass = 'tag-sistem';
                msgHtml = `<span style="color: #38BDF8;">${msgHtml}</span>`;
              } else if (rawText.startsWith('[CONFIG]') || rawText.startsWith('[TARGET]')) {
                tagClass = 'tag-sistem';
                msgHtml = `<span style="color: #818CF8;">${msgHtml}</span>`;
              } else if (rawText.startsWith('[DATABASE]')) {
                tagClass = 'tag-modul';
                msgHtml = `<span style="color: #C084FC;">${msgHtml}</span>`;
              } else if (rawText.startsWith('[LISENSI]')) {
                tagClass = 'tag-auth';
                msgHtml = `<span style="color: #FB923C;">${msgHtml}</span>`;
              } else if (rawText.startsWith('[JARINGAN]') || rawText.startsWith('[GATEWAY]')) {
                tagClass = 'tag-sistem';
                msgHtml = `<span style="color: #60A5FA;">${msgHtml}</span>`;
              } else if (rawText.startsWith('[AUTH]') || rawText.includes('Meminta 8 digit')) {
                tagClass = 'tag-auth';
                msgHtml = `<span style="color: #FBBF24; font-weight: 600;">${msgHtml}</span>`;
              } else if (rawText.includes('PANDUAN PENAUTAN')) {
                tagClass = 'tag-auth';
                msgHtml = `<span style="color: #6EE7B7; font-weight: 600;">📱 ${msgHtml}</span>`;
              } else if (/PROSES:\s*Auto\s*SWGC/i.test(rawText) || /╰─\s*[⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏]?\s*PROSES:/i.test(rawText)) {
                tagClass = 'tag-modul';
                const procMatch = rawText.match(/PROSES:\s*(.+)$/i);
                const procName = procMatch ? procMatch[1].trim() : 'Auto SWGC';

                msgHtml = `
                  <div class="deploy-terminal-live-spinner">
                    <span class="terminal-spinner-inline"></span>
                    <span class="terminal-braille-live">⠋</span>
                    <span class="deploy-spinner-label">PROSES:</span>
                    <span class="deploy-spinner-target">${escapeHtml(procName)}</span>
                  </div>
                `;
              } else if (rawText.includes('TERHUBUNG ONLINE') || (rawText.includes('online') && rawText.includes('[STATUS]'))) {
                tagClass = 'tag-online';
                msgHtml = `<strong style="color: #4ADE80; font-weight: 800; background: rgba(34,197,94,0.18); padding: 2px 6px; border-radius: 4px;">${msgHtml}</strong>`;
              } else if (rawText.includes('[AutoSwgc]') || rawText.includes('Auto SWGC')) {
                tagClass = 'tag-online';
                if (rawText.includes('Sukses upload')) {
                  msgHtml = `<span style="color: #4ADE80; font-weight: 700;">${msgHtml}</span>`;
                } else if (rawText.includes('Menunggu jeda')) {
                  msgHtml = `<span style="color: #FBBF24;">${msgHtml}</span>`;
                } else if (rawText.includes('Selesai')) {
                  msgHtml = `<span style="color: #38BDF8; font-weight: 800;">${msgHtml}</span>`;
                }
              } else if (rawText.startsWith('[ERROR]') || rawText.startsWith('[STDERR]')) {
                tagClass = 'tag-error';
                msgHtml = `<span style="color: #F87171;">${msgHtml}</span>`;
              } else if (rawText.match(/[\u2800-\u28FF]/) || rawText.includes('Memuat modul plugin') || rawText.includes('Sinkronisasi database')) {
                const cleanMsg = rawText.replace(/[\u2800-\u28FF]/g, '').trim();
                const isFinished = myBot.status === 'online' || index < recentEvents.length - 1 || recentEvents.slice(index + 1).some(next => 
                  next.text?.includes('aktif & siap') || 
                  next.text?.includes('terhubung') || 
                  next.text?.includes('ONLINE') || 
                  next.text?.includes('KODE PAIRING')
                );

                if (isFinished) {
                  tagClass = 'tag-online';
                  msgHtml = `<span class="terminal-done-check">✔</span><span style="color: #CBD5E1;">${escapeHtml(cleanMsg)}</span>`;
                } else {
                  tagClass = 'tag-modul';
                  msgHtml = `<span class="terminal-spinner-inline"></span><span style="color: #C084FC; font-weight: 600;">${escapeHtml(cleanMsg)}</span>`;
                }
              } else if (rawText.startsWith('[LOADER]') || rawText.startsWith('[MODUL]')) {
                tagClass = 'tag-modul';
                msgHtml = `<span style="color: #C084FC;">${msgHtml}</span>`;
              }

              item.innerHTML = `
                <span class="deploy-log-time">${timeStr}</span>
                <span class="deploy-log-tag ${tagClass}">[${escapeHtml(row.label || 'SISTEM')}]</span>
                <div class="deploy-log-msg">${msgHtml}</div>
              `;
              return item;
            });

            consoleBody.replaceChildren(...rows);
            if (wasAtBottom) {
              consoleBody.scrollTop = consoleBody.scrollHeight;
            }
          } else {
            const isOnline = myBot.status === 'online';

            const emptyEntry = document.createElement('div');
            emptyEntry.className = 'deploy-log-entry';
            emptyEntry.innerHTML = `
              <span class="deploy-log-time">${new Date().toLocaleTimeString('id-ID')}</span>
              <span class="deploy-log-tag ${isOnline ? 'tag-online' : 'tag-sistem'}">[SISTEM]</span>
              <div class="deploy-log-msg" style="color: ${isOnline ? '#4ADE80' : '#38BDF8'};">${isOnline ? 'Bot WhatsApp terhubung online. Server aktif &amp; siap menerima perintah chat.' : 'Menghubungkan ke gateway WhatsApp &amp; menginisialisasi server bot...'}</div>
            `;

            consoleBody.replaceChildren(emptyEntry);
          }
        }
        return;
      }

    // Default: Belum deploy bot di browser ini / bot sudah dihapus
    setActiveDeployId('');
    localStorage.removeItem('af_active_deploy_phone');
    saveLinkedBots([]);

    const limitNotice = document.getElementById('deploy-limit-notice');
    const formWorkspace = document.getElementById('deploy-form-workspace');
    if (limitNotice) limitNotice.style.display = 'none';
    if (formWorkspace) formWorkspace.style.display = 'grid';

    if (pairingBox) pairingBox.style.display = 'none';
    if (qrBox) qrBox.style.display = 'none';
    if (consoleCard) consoleCard.style.display = 'none';

    if (container) {
      container.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 40px 20px; border: 1px dashed var(--border-subtle); border-radius: var(--radius-card); background: rgba(18,25,35,0.4);">
          <p style="font-size: 0.88rem; color: #94A3B8; margin-bottom: 4px;">Kamu belum menautkan bot WhatsApp di peramban ini.</p>
          <span style="font-size: 0.75rem; color: #64748B;">Masukkan nomor WhatsApp pada formulir di atas untuk langsung mendapatkan kode pairing gratis.</span>
        </div>
      `;
    }

  } catch (err) {
    console.warn('Gagal memuat status deploy:', err);
  } finally {
    isDeployBusy = false;
  }
}
window.handleDeployAction = async function(action, targetBotId) {
  const botId = targetBotId || getActiveDeployId();
  if (!botId) return showDeployToast('Belum ada bot yang terdaftar.');

  if (action === 'stop' && botId === getActiveDeployId()) {
    terminalClearedAt = Date.now();
    const consoleBody = document.getElementById('web-deploy-console-body');
    if (consoleBody) {
      consoleBody.dataset.lastFingerprint = '';
      consoleBody.innerHTML = '';
    }
  }

  try {
    showDeployToast(`${action === 'start' ? 'Memulai' : 'Menghentikan'} bot Anda...`);
    const botToken = getBotToken(botId);
    await safeDeployFetch(`/api/deploy/bot/${botId}/${action}`, {
      method: 'POST',
      headers: botToken ? { 'x-bot-token': botToken } : {}
    });
    await refreshDeployStatus();
  } catch (err) {
    showDeployToast(`Error: ${err.message}`);
  }
}

;

window.handleDeployDelete = async function(phone, targetBotId) {
  if (isDeletingBot) return;

  const botId = targetBotId || getActiveDeployId();
  if (!botId) return showDeployToast('Belum ada bot yang terdaftar.');

  const cleanPhone = phone ? String(phone).replace(/^\+*/, '+') : 'Anda';
  const initialConfirm = confirm(
    `Hapus bot WhatsApp ${cleanPhone} dari server? Sesi bot akan dihentikan dan seluruh data sesi dihapus total.`
  );
  if (!initialConfirm) return;

  const currentToken = getBotToken(botId);
  if (!currentToken) {
    pendingDeployAuthAction = { action: 'delete', botId, phone: cleanPhone, timestamp: Date.now() };
    openVerifyPasswordModal(botId, cleanPhone.replace(/^\+/, ''), 'delete');
    return;
  }

  isDeletingBot = true;
  try {
    showDeployToast(`Menghapus bot ${cleanPhone} & membersihkan sesi...`);
    await safeDeployFetch(`/api/deploy/bot/${botId}`, {
      method: 'DELETE',
      headers: { 'x-bot-token': currentToken }
    });

    // Berhasil dihapus dari server backend
    clearBotToken(botId);
    removeLinkedBot(botId);
    sessionStorage.removeItem('af_bot_' + botId);
    sessionStorage.removeItem('af_console_' + botId);
    sessionStorage.removeItem('deploy_last_logs_' + botId);
    pendingDeployAuthAction = null;
    showDeployToast('Bot dan seluruh berkas sesi WhatsApp berhasil dihapus total.');
    await refreshDeployStatus();
  } catch (err) {
    if (err.status === 401 || err.code === 'AUTH_REQUIRED' || (err.status === 403 && err.code === 'TOKEN_INVALID')) {
      pendingDeployAuthAction = { action: 'delete', botId, phone: cleanPhone, timestamp: Date.now() };
      openVerifyPasswordModal(botId, cleanPhone.replace(/^\+/, ''), 'delete');
      showDeployToast('Verifikasi password diperlukan untuk menghapus bot.');
      return;
    }

    if (err.status === 503 || err.code === 'SERVER_OFFLINE' || err.code === 'SERVICE_UNAVAILABLE') {
      showDeployToast('Layanan deploy bot sedang offline atau gangguan koneksi. Data bot tetap tersimpan.');
      return;
    }

    showDeployToast(`Gagal menghapus bot: ${err.message}`);
  } finally {
    isDeletingBot = false;
  }
}

;

window.copyPairingCode = function(code, btn) {
  if (!code || code === 'WAITING') return;
  navigator.clipboard.writeText(code).then(() => {
    if (typeof showDeployToast === 'function') {
      showDeployToast(`Kode pairing ${code} berhasil disalin!`);
    }
    if (btn) {
      const origHtml = btn.innerHTML;
      btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg><span>TERSALIN!</span>`;
      btn.classList.add('copied');
      setTimeout(() => {
        btn.innerHTML = origHtml;
        btn.classList.remove('copied');
      }, 2000);
    }
  }).catch(() => {
    if (typeof showDeployToast === 'function') {
      showDeployToast('Gagal menyalin otomatis. Silakan salin manual.');
    }
  });
};

let lastTerminalCommandTime = 0;
let terminalHistory = [];
let terminalHistoryIndex = -1;

window.handleTerminalCommand = function(e) {
  if (e) e.preventDefault();
  const input = document.getElementById('terminal-cmd-input');
  if (!input) return;

  // 1. Anti-Spam Throttle Guard (Maksimal 1 eksekusi per 250ms)
  const now = Date.now();
  if (now - lastTerminalCommandTime < 250) {
    return;
  }
  lastTerminalCommandTime = now;

  let rawVal = String(input.value || '');
  // 2. Sanitasi Keamanan: Bersihkan karakter kontrol ASCII non-printable & whitespace
  let cmd = rawVal.replace(/[\x00-\x1F\x7F]/g, '').trim();
  if (!cmd) return;

  // 3. Batas Panjang Input: Maksimal 100 karakter guna mencegah serangan buffer / DOM denial-of-service
  if (cmd.length > 100) cmd = cmd.substring(0, 100);

  // 4. Riwayat Perintah (History Array untuk navigasi Arrow Up/Down, dibatasi 30 memori)
  terminalHistory.push(cmd);
  if (terminalHistory.length > 30) terminalHistory.shift();
  terminalHistoryIndex = terminalHistory.length;

  input.value = '';

  const consoleBody = document.getElementById('web-deploy-console-body');
  if (!consoleBody) return;

  // 5. Memory Guard: Batasi jumlah elemen di DOM untuk mencegah kebocoran memori browser
  if (consoleBody.children.length > 250) {
    const toRemove = consoleBody.children.length - 200;
    for (let k = 0; k < toRemove; k++) {
      if (consoleBody.children[1]) {
        consoleBody.removeChild(consoleBody.children[1]);
      }
    }
  }

  const timeStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  // 6. Baris Echo Perintah Pengguna (XSS-Safe via escapeHtml)
  const cmdEntry = document.createElement('div');
  cmdEntry.className = 'deploy-log-entry entry-animate';
  cmdEntry.innerHTML = `
    <span class="deploy-log-time">${timeStr}</span>
    <span class="deploy-log-label" style="color:#38BDF8; font-weight:800;">[INPUT]</span>
    <span class="deploy-log-msg"><span style="color:#FBBF24; font-weight:700;">❯</span> <span style="color:#FFF; font-weight:700;">${escapeHtml(cmd)}</span></span>
  `;
  consoleBody.appendChild(cmdEntry);

  const lowerCmd = cmd.toLowerCase();

  // 7. Perintah Clear Konsol
  if (lowerCmd === 'clear' || lowerCmd === 'cls') {
    terminalClearedAt = Date.now();
    consoleBody.dataset.lastFingerprint = '';
    consoleBody.innerHTML = '';
    showDeployToast('Layar konsol terminal berhasil dibersihkan.');
    refreshDeployStatus();
    return;
  }

  // 8. Perintah Bantuan (Help)
  if (lowerCmd === 'help' || lowerCmd === 'bantuan' || lowerCmd === '?') {
    const helpEntry = document.createElement('div');
    helpEntry.className = 'deploy-log-card-wrap entry-animate';
    helpEntry.innerHTML = `
      <div class="deploy-terminal-cmd-card status-success" style="border-left-color:#38BDF8;">
        <div class="cmd-card-header">
          <div class="cmd-title-group">
            <span class="cmd-badge" style="background:#38BDF8; color:#0F172A;">⚡ BANTUAN TERMINAL</span>
            <span class="cmd-name">DAFTAR PERINTAH KONSOL INTERAKTIF</span>
          </div>
        </div>
        <div class="cmd-card-body" style="grid-template-columns: 1fr; gap: 4px; font-size: 0.72rem;">
          <div><b style="color:#38BDF8;">status</b> : Cek status bot, koneksi WhatsApp, dan waktu aktif</div>
          <div><b style="color:#38BDF8;">ping</b> : Cek kecepatan respon koneksi server</div>
          <div><b style="color:#38BDF8;">info</b> : Informasi nomor akun, engine, dan runtime lisensi</div>
          <div><b style="color:#38BDF8;">clear / cls</b> : Bersihkan seluruh tampilan konsol</div>
          <div><b style="color:#38BDF8;">start / on</b> : Mulai / nyalakan bot WhatsApp</div>
          <div><b style="color:#38BDF8;">stop / off</b> : Hentikan bot WhatsApp & bersihkan layar</div>
          <div><b style="color:#38BDF8;">restart</b> : Jalankan ulang bot WhatsApp</div>
          <div><b style="color:#38BDF8;">.menu / .ping / .runtime</b> : Kirim tes perintah bot</div>
        </div>
      </div>
    `;
    consoleBody.appendChild(helpEntry);
    consoleBody.scrollTop = consoleBody.scrollHeight;
    return;
  }

  // 9. Perintah Ping
  if (lowerCmd === 'ping') {
    const pingEntry = document.createElement('div');
    pingEntry.className = 'deploy-log-entry entry-animate';
    pingEntry.innerHTML = `
      <span class="deploy-log-time">${timeStr}</span>
      <span class="deploy-log-label" style="color:#4ADE80;">[PONG]</span>
      <span class="deploy-log-msg" style="color:#4ADE80; font-weight:800;">⚡ Kecepatan Respon: ${Math.floor(18 + Math.random() * 15)}ms · Server Online 100%</span>
    `;
    consoleBody.appendChild(pingEntry);
    consoleBody.scrollTop = consoleBody.scrollHeight;
    return;
  }

  // 10. Perintah Status
  if (lowerCmd === 'status') {
    refreshDeployStatus();
    const statEntry = document.createElement('div');
    statEntry.className = 'deploy-log-entry entry-animate';
    statEntry.innerHTML = `
      <span class="deploy-log-time">${timeStr}</span>
      <span class="deploy-log-label" style="color:#38BDF8;">[STATUS]</span>
      <span class="deploy-log-msg" style="color:#E2E8F0;">Bot Status: <b>${escapeHtml(getActiveDeployId() ? 'TERDAFTAR & AKTIF' : 'STANDBY')}</b> · Server: <b>ONLINE</b> · Engine: <b>Baileys AGAAHOST</b> · Node: <b>v20.x</b></span>
    `;
    consoleBody.appendChild(statEntry);
    consoleBody.scrollTop = consoleBody.scrollHeight;
    return;
  }

  // 11. Kontrol Bot (Start, Stop, Restart)
  if (lowerCmd === 'start' || lowerCmd === 'on') {
    handleDeployAction('start');
    return;
  }
  if (lowerCmd === 'stop' || lowerCmd === 'off') {
    handleDeployAction('stop');
    return;
  }
  if (lowerCmd === 'restart' || lowerCmd === 'reboot') {
    handleDeployAction('restart');
    return;
  }
  if (lowerCmd === 'hapus' || lowerCmd === 'delete' || lowerCmd === 'hapusbot' || lowerCmd === '.hapusbot') {
    const savedPhone = localStorage.getItem('af_active_deploy_phone') || '';
    handleDeployDelete(savedPhone ? `+${savedPhone}` : 'bot');
    return;
  }

  // 12. Info Sistem (Baileys AGAAHOST & Node v20.x)
  if (lowerCmd === 'info') {
    const infoEntry = document.createElement('div');
    infoEntry.className = 'deploy-log-card-wrap entry-animate';
    infoEntry.innerHTML = `
      <div class="deploy-terminal-info-card">
        <span class="info-icon">ℹ️</span>
        <span class="info-text">AGAAHOST BOT SYSTEM v13.5 · Build Tier: FREE EDITION · Engine: Baileys AGAAHOST · Node: v20.x</span>
        <span class="info-time">${timeStr}</span>
      </div>
    `;
    consoleBody.appendChild(infoEntry);
    consoleBody.scrollTop = consoleBody.scrollHeight;
    return;
  }

  // 13. Perintah Berawalan Titik (Command Bot WhatsApp)
  if (cmd.startsWith('.')) {
    const botId = getActiveDeployId();
    if (botId) {
      fetch(`/api/deploy/bot/${botId}/input`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ text: cmd })
      }).catch(() => {});
    }

    const execEntry = document.createElement('div');
    execEntry.className = 'deploy-log-card-wrap entry-animate';
    execEntry.innerHTML = `
      <div class="deploy-terminal-cmd-card status-success">
        <div class="cmd-card-header">
          <div class="cmd-title-group">
            <span class="cmd-badge">⚡ CONSOLE EXEC</span>
            <span class="cmd-name">${escapeHtml(cmd)}</span>
          </div>
          <div class="cmd-badge-group">
            <span class="cmd-status success">
              <span class="cmd-status-dot"></span>
              ✓ TERKIRIM KE BOT
            </span>
            <span class="cmd-time">${timeStr}</span>
          </div>
        </div>
        <div class="cmd-card-body">
          <div class="cmd-meta"><span class="cmd-lbl">SUMBER:</span><span class="cmd-val">Web Console Terminal</span></div>
          <div class="cmd-meta"><span class="cmd-lbl">ENGINE:</span><span class="cmd-val">Baileys AGAAHOST</span></div>
          <div class="cmd-meta"><span class="cmd-lbl">RUNTIME:</span><span class="cmd-val">Node v20.x</span></div>
          <div class="cmd-meta"><span class="cmd-lbl">STATUS:</span><span class="cmd-val text-success">Perintah diproses sistem</span></div>
        </div>
      </div>
    `;
    consoleBody.appendChild(execEntry);
    consoleBody.scrollTop = consoleBody.scrollHeight;
    return;
  }

  // 14. Forwarding Jawaban / Input Pengguna Langsung ke Bot WhatsApp (Bisa Jawab Pertanyaan di Konsol)
  const botId = getActiveDeployId();
  if (botId) {
    try {
      fetch(`/api/deploy/bot/${botId}/input`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ text: cmd })
      }).catch(() => {});
    } catch {}

    const inputRespEntry = document.createElement('div');
    inputRespEntry.className = 'deploy-log-entry entry-animate';
    inputRespEntry.innerHTML = `
      <span class="deploy-log-time">${timeStr}</span>
      <span class="deploy-log-label" style="color:#4ADE80; font-weight:800;">[INPUT BOT]</span>
      <span class="deploy-log-msg" style="color:#86EFAC;">Jawaban berhasil dikirim ke bot: <b>"${escapeHtml(cmd)}"</b></span>
    `;
    consoleBody.appendChild(inputRespEntry);
    consoleBody.scrollTop = consoleBody.scrollHeight;
    return;
  }

  // 15. Perintah Tidak Dikenal (Jika Belum Deploy Bot)
  const unknownEntry = document.createElement('div');
  unknownEntry.className = 'deploy-log-entry entry-animate';
  unknownEntry.innerHTML = `
    <span class="deploy-log-time">${timeStr}</span>
    <span class="deploy-log-label" style="color:#F87171;">[SYSTEM]</span>
    <span class="deploy-log-msg" style="color:#F87171;">Perintah <b>"${escapeHtml(cmd)}"</b> tidak dikenali. Ketik <b>help</b> untuk melihat daftar perintah konsol yang aman.</span>
  `;
  consoleBody.appendChild(unknownEntry);
  consoleBody.scrollTop = consoleBody.scrollHeight;
};

function showDeployToast(msg, type = 'auto') {
  const toast = document.getElementById('toast-notice');
  if (!toast) return;

  const span = toast.querySelector('span');
  const svgWrap = toast.querySelector('svg');
  if (span) span.textContent = msg;

  let resolved = type;
  if (!resolved || resolved === 'auto') {
    const lower = String(msg || '').toLowerCase();
    if (
      lower.includes('error') ||
      lower.includes('gagal') ||
      lower.includes('salah') ||
      lower.includes('tidak cocok') ||
      lower.includes('ditolak') ||
      lower.includes('batal') ||
      lower.includes('dibatalkan') ||
      lower.includes('offline') ||
      lower.includes('forbidden') ||
      lower.includes('unauthorized') ||
      lower.includes('kadaluwarsa') ||
      lower.includes('kedaluwarsa') ||
      lower.includes('expired') ||
      lower.includes('terlalu banyak')
    ) {
      resolved = 'error';
    } else if (
      lower.includes('⚠️') ||
      lower.includes('wajib') ||
      lower.includes('minimal') ||
      lower.includes('harus') ||
      lower.includes('perlu') ||
      lower.includes('diperlukan') ||
      lower.includes('peringatan') ||
      lower.includes('batas') ||
      lower.includes('penuh') ||
      lower.includes('tanpa password') ||
      lower.includes('verifikasi owner')
    ) {
      resolved = 'warning';
    } else if (
      lower.includes('ℹ️') ||
      lower.includes('memulai') ||
      lower.includes('menyiapkan') ||
      lower.includes('memverifikasi') ||
      lower.includes('menghapus bot') ||
      lower.includes('membersihkan') ||
      lower.includes('mode log') ||
      lower.includes('masukkan password') ||
      lower.includes('sudah terdaftar')
    ) {
      resolved = 'info';
    } else {
      resolved = 'success';
    }
  }

  if (svgWrap) {
    if (resolved === 'error') {
      svgWrap.setAttribute('stroke', '#EF4444');
      svgWrap.innerHTML = '<circle cx="12" cy="12" r="9" stroke-width="2.2"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M15 9l-6 6M9 9l6 6"/>';
      toast.style.borderColor = 'rgba(239, 68, 68, 0.55)';
      toast.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.6), 0 0 16px rgba(239, 68, 68, 0.28)';
    } else if (resolved === 'warning') {
      svgWrap.setAttribute('stroke', '#F59E0B');
      svgWrap.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>';
      toast.style.borderColor = 'rgba(245, 158, 11, 0.55)';
      toast.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.6), 0 0 16px rgba(245, 158, 11, 0.28)';
    } else if (resolved === 'info') {
      svgWrap.setAttribute('stroke', '#38BDF8');
      svgWrap.innerHTML = '<circle cx="12" cy="12" r="9" stroke-width="2.2"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M12 16v-4m0-4h.01"/>';
      toast.style.borderColor = 'rgba(56, 189, 248, 0.55)';
      toast.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.6), 0 0 16px rgba(56, 189, 248, 0.28)';
    } else {
      svgWrap.setAttribute('stroke', '#22C55E');
      svgWrap.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/>';
      toast.style.borderColor = 'rgba(34, 197, 94, 0.5)';
      toast.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.6), 0 0 16px rgba(34, 197, 94, 0.28)';
    }
  }

  toast.classList.add('show');
  if (toast._timer) clearTimeout(toast._timer);
  toast._timer = setTimeout(() => {
    toast.classList.remove('show');
  }, 4200);
}
window.showDeployToast = showDeployToast;

/* ==========================================================================
   PASSWORD MODAL HANDLERS (OPSI B - SET & VERIFY PASSWORD)
   ========================================================================== */
let targetSetPassBotId = '';
let targetSetPassHasPassword = false;
let targetVerifyPassBotId = '';
let targetVerifyPassPhone = '';
let pendingDeployAuthAction = null; // { action: 'delete' | 'login', botId, phone, timestamp }
let isDeletingBot = false; // Mencegah double click dan request DELETE berulang

window.openSetPasswordModal = function(botId, phone, hasPassword = false) {
  targetSetPassBotId = botId;
  targetSetPassHasPassword = Boolean(hasPassword);
  const overlay = document.getElementById('modal-set-password-overlay');
  const phoneLabel = document.getElementById('set-pass-phone-label');
  if (phoneLabel) phoneLabel.textContent = '+' + phone;
  const groupOld = document.getElementById('group-old-bot-pass');
  const inputOld = document.getElementById('input-old-bot-pass');
  const inputNew = document.getElementById('input-new-bot-pass');
  const inputConfirm = document.getElementById('input-confirm-bot-pass');

  if (groupOld) groupOld.style.display = targetSetPassHasPassword ? 'block' : 'none';
  if (inputOld) {
    inputOld.value = '';
    inputOld.required = targetSetPassHasPassword;
  }
  if (inputNew) inputNew.value = '';
  if (inputConfirm) inputConfirm.value = '';

  if (overlay) {
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
    setTimeout(() => {
      if (targetSetPassHasPassword && inputOld) inputOld.focus();
      else if (inputNew) inputNew.focus();
    }, 150);
  }
}

;

window.closeSetPasswordModal = function() {
  const overlay = document.getElementById('modal-set-password-overlay');
  if (overlay) {
    overlay.classList.remove('active');
    document.body.style.overflow = '';
  }
}

;

window.handleSetBotPassword = async function(e) {
  e.preventDefault();
  const inputOld = document.getElementById('input-old-bot-pass');
  const inputNew = document.getElementById('input-new-bot-pass');
  const inputConfirm = document.getElementById('input-confirm-bot-pass');
  const btn = document.getElementById('btn-save-bot-pass');

  const oldPassword = inputOld?.value || '';
  const p1 = (inputNew?.value || '').trim();
  const p2 = (inputConfirm?.value || '').trim();

  if (targetSetPassHasPassword && !oldPassword) {
    return showDeployToast('Password lama wajib diisi!');
  }
  if (p1.length < 6) return showDeployToast('Password baru minimal 6 karakter!');
  if (p1 !== p2) return showDeployToast('Konfirmasi password tidak cocok!');

  const botId = targetSetPassBotId || getActiveDeployId();
  if (!botId) return showDeployToast('ID bot tidak ditemukan.');

  btn.disabled = true;
  btn.innerHTML = '<span>Menyimpan Password...</span>';

  try {
    const res = await safeDeployFetch(`/api/deploy/bot/${botId}/set-password`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ password: p1, oldPassword })
    });

    closeSetPasswordModal();
    if (res.token) {
      setBotToken(botId, res.token);
    }
    showDeployToast('Password bot berhasil diubah & sesi baru diamankan!');
    await refreshDeployStatus();
  } catch (err) {
    showDeployToast(err.message);
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<span>Simpan & Amankan Bot</span>';
  }
}

;

window.openVerifyPasswordModal = function(botId, phone, reason = 'login') {
  targetVerifyPassBotId = botId;
  targetVerifyPassPhone = phone;
  const overlay = document.getElementById('modal-verify-password-overlay');
  const titleEl = document.getElementById('verify-pass-modal-title');
  const descEl = document.getElementById('verify-pass-desc');
  const phoneLabel = document.getElementById('verify-pass-phone-label');
  const errorBox = document.getElementById('verify-pass-error');
  const inputPass = document.getElementById('input-verify-bot-pass');
  const submitBtn = document.getElementById('btn-submit-verify-pass');

  const cleanPhoneStr = phone ? (String(phone).startsWith('+') ? String(phone) : ('+' + phone)) : '';
  if (phoneLabel) phoneLabel.textContent = cleanPhoneStr;
  if (errorBox) {
    errorBox.style.display = 'none';
    errorBox.textContent = '';
  }

  if (reason === 'delete') {
    if (titleEl) titleEl.textContent = 'Verifikasi Password untuk Menghapus Bot';
    if (descEl) descEl.textContent = 'Masukkan password pengaman bot Anda untuk mengonfirmasi penghapusan bot WhatsApp ini secara permanen:';
    if (submitBtn) {
      const span = submitBtn.querySelector('span');
      if (span) span.textContent = 'Verifikasi & Lanjutkan Hapus';
      else submitBtn.textContent = 'Verifikasi & Lanjutkan Hapus';
    }
  } else {
    if (titleEl) titleEl.textContent = 'Verifikasi Password Bot';
    if (descEl) descEl.textContent = 'sudah memiliki bot yang aktif di server. Masukkan password pengaman kamu untuk masuk ke panel manajemen:';
    if (submitBtn) {
      const span = submitBtn.querySelector('span');
      if (span) span.textContent = 'Masuk ke Panel Bot';
      else submitBtn.textContent = 'Masuk ke Panel Bot';
    }
  }

  if (inputPass) {
    inputPass.value = '';
    setTimeout(() => inputPass.focus(), 150);
  }
  if (overlay) {
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

;

window.closeVerifyPasswordModal = function() {
  const overlay = document.getElementById('modal-verify-password-overlay');
  const errorBox = document.getElementById('verify-pass-error');
  if (errorBox) {
    errorBox.style.display = 'none';
    errorBox.textContent = '';
  }
  // Bersihkan konteks tindakan tertunda agar pembatalan tidak menghapus atau menghentikan bot
  pendingDeployAuthAction = null;
  if (overlay) {
    overlay.classList.remove('active');
    document.body.style.overflow = '';
  }
}

;

window.handleVerifyBotPassword = async function(e) {
  e.preventDefault();
  const inputPass = document.getElementById('input-verify-bot-pass');
  const btn = document.getElementById('btn-submit-verify-pass');
  const errorBox = document.getElementById('verify-pass-error');
  const password = (inputPass?.value || '').trim();

  if (!password) {
    if (errorBox) {
      errorBox.textContent = 'Masukkan password pengaman bot kamu!';
      errorBox.style.display = 'block';
    }
    return;
  }

  const botId = targetVerifyPassBotId;
  const phone = targetVerifyPassPhone;
  const currentPending = pendingDeployAuthAction;

  btn.disabled = true;
  const origBtnContent = btn.innerHTML;
  btn.innerHTML = '<span>Memverifikasi...</span>';
  if (errorBox) {
    errorBox.style.display = 'none';
    errorBox.textContent = '';
  }

  try {
    const res = await safeDeployFetch(`/api/deploy/bot/${botId}/login`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ password })
    });

    if (!res || !res.token) {
      throw new Error('Gagal mendapatkan token autentikasi bot dari server.');
    }

    // Password benar: Simpan token khusus bot target
    setBotToken(botId, res.token);

    // Tutup modal verifikasi
    closeVerifyPasswordModal();

    // Jika dipanggil dari alur hapus bot (pending action: delete)
    if (currentPending && currentPending.action === 'delete' && currentPending.botId === botId) {
      const cleanPhone = phone ? (String(phone).startsWith('+') ? String(phone) : ('+' + phone)) : 'Anda';
      // Tampilkan konfirmasi penghapusan terakhir
      const finalConfirm = confirm(
        `Verifikasi password berhasil.\n\nYakin ingin menghapus permanen bot WhatsApp ${cleanPhone}? Sesi bot akan dihentikan dan seluruh berkas dihapus total dari server.`
      );
      if (!finalConfirm) {
        pendingDeployAuthAction = null;
        showDeployToast('Penghapusan bot dibatalkan. Bot tetap aktif berjalan.');
        return;
      }

      // Pengguna menyetujui konfirmasi: eksekusi penghapusan dengan token baru
      if (isDeletingBot) return;
      isDeletingBot = true;
      try {
        showDeployToast(`Menghapus bot ${cleanPhone} & membersihkan sesi...`);
        await safeDeployFetch(`/api/deploy/bot/${botId}`, {
          method: 'DELETE',
          headers: { 'x-bot-token': res.token }
        });
        clearBotToken(botId);
        removeLinkedBot(botId);
        sessionStorage.removeItem('af_bot_' + botId);
        sessionStorage.removeItem('af_console_' + botId);
        sessionStorage.removeItem('deploy_last_logs_' + botId);
        pendingDeployAuthAction = null;
        showDeployToast('Bot dan seluruh berkas sesi WhatsApp berhasil dihapus total.');
        await refreshDeployStatus();
      } catch (delErr) {
        showDeployToast(`Gagal menghapus bot: ${delErr.message}`);
      } finally {
        isDeletingBot = false;
      }
      return;
    }

    // Alur login biasa ke panel bot
    addLinkedBot(botId, phone, res.token);
    showDeployToast('Verifikasi sukses! Akses bot aktif.');
    await refreshDeployStatus();

  } catch (err) {
    // Password salah atau error autentikasi: MODAL TETAP TERBUKA, pesan error tampil di modal, data bot utuh
    if (errorBox) {
      errorBox.textContent = err.message || 'Password bot tidak cocok. Silakan coba lagi.';
      errorBox.style.display = 'block';
    } else {
      showDeployToast(err.message);
    }
  } finally {
    btn.disabled = false;
    btn.innerHTML = origBtnContent;
  }
}

;

// ==========================================================================
// KLAIM / REDEEM VOUCHER DISKON BELANJA (STORE CHECKOUT)
// ==========================================================================
const STORE_VOUCHERS = {};

window.openVoucherModal = function() {
  const overlay = document.getElementById('modal-voucher-overlay');
  const inputCode = document.getElementById('input-voucher-code');
  const statusBox = document.getElementById('voucher-status-box');
  if (statusBox) {
    const active = window.getActiveVoucher ? window.getActiveVoucher() : null;
    if (active) {
      statusBox.style.display = 'block';
      statusBox.style.background = 'rgba(34, 197, 94, 0.12)';
      statusBox.style.border = '1px solid rgba(34, 197, 94, 0.3)';
      statusBox.style.color = '#4ADE80';
      statusBox.innerHTML = `<div style="display:flex; justify-content:space-between; align-items:center;"><span>Voucher Aktif: <strong>${escapeHtml(active.code || '')}</strong> (${escapeHtml(active.label || '')})</span> <button type="button" onclick="window.removeActiveVoucher()" style="background:none;border:none;color:#EF4444;font-size:0.75rem;cursor:pointer;font-weight:700;text-decoration:underline;">Hapus</button></div>`;
    } else {
      statusBox.style.display = 'none';
    }
  }
  if (inputCode) {
    inputCode.value = '';
    setTimeout(() => inputCode.focus(), 150);
  }
  if (overlay) {
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

;

window.closeVoucherModal = function() {
  const overlay = document.getElementById('modal-voucher-overlay');
  if (overlay) {
    overlay.classList.remove('active');
    document.body.style.overflow = '';
  }
}

;

window.getActiveVoucher = function() {
  try {
    const raw = localStorage.getItem('af_active_voucher');
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

;

window.removeActiveVoucher = function() {
  localStorage.removeItem('af_active_voucher');
  if (typeof updateOrderPreview === 'function') {
    updateOrderPreview();
  }
  const statusBox = document.getElementById('voucher-status-box');
  if (statusBox) statusBox.style.display = 'none';
  if (typeof showToastNotice === 'function') {
    showToastNotice('Voucher diskon dihapus.');
  }
}

;

window.handleRedeemVoucher = function(e) {
  if (e) e.preventDefault();
  const inputCode = document.getElementById('input-voucher-code');
  const statusBox = document.getElementById('voucher-status-box');
  const code = (inputCode?.value || '').trim().toUpperCase();

  if (!code) {
    if (statusBox) {
      statusBox.style.display = 'block';
      statusBox.style.background = 'rgba(239, 68, 68, 0.12)';
      statusBox.style.border = '1px solid rgba(239, 68, 68, 0.3)';
      statusBox.style.color = '#F87171';
      statusBox.textContent = 'Masukkan kode voucher terlebih dahulu!';
    }
    return;
  }

  const voucherData = STORE_VOUCHERS[code];
  if (!voucherData) {
    if (statusBox) {
      statusBox.style.display = 'block';
      statusBox.style.background = 'rgba(239, 68, 68, 0.12)';
      statusBox.style.border = '1px solid rgba(239, 68, 68, 0.3)';
      statusBox.style.color = '#F87171';
      statusBox.textContent = `Kode voucher "${code}" tidak ditemukan atau sudah kadaluarsa.`;
    }
    return;
  }

  const voucherPayload = {
    code,
    ...voucherData
  };
  localStorage.setItem('af_active_voucher', JSON.stringify(voucherPayload));

  if (statusBox) {
    statusBox.style.display = 'block';
    statusBox.style.background = 'rgba(34, 197, 94, 0.12)';
    statusBox.style.border = '1px solid rgba(34, 197, 94, 0.3)';
    statusBox.style.color = '#4ADE80';
    statusBox.innerHTML = `Voucher <strong>${escapeHtml(code)}</strong> berhasil diaktifkan! (${escapeHtml(voucherData.label || '')})`;
  }

  if (typeof updateOrderPreview === 'function') {
    updateOrderPreview();
  }

  setTimeout(() => {
    window.closeVoucherModal();
    if (typeof showToastNotice === 'function') {
      showToastNotice(`Voucher ${code} berhasil diklaim! Diskon diterapkan.`);
    }
  }, 800);
};

// ==========================================================================
// KLAIM / REDEEM TOKEN (PERPANJANG MASA AKTIF & MATIKAN AUTO-PROMOSI)
// ==========================================================================
window.openRedeemModal = function() {
  const overlay = document.getElementById('modal-redeem-token-overlay');
  const inputPhone = document.getElementById('input-redeem-phone');
  const inputCode = document.getElementById('input-redeem-code');
  if (inputPhone) {
    const activePhone = localStorage.getItem('af_active_deploy_phone') || '';
    inputPhone.value = activePhone;
  }
  if (inputCode) {
    inputCode.value = '';
    setTimeout(() => inputCode.focus(), 150);
  }
  if (overlay) {
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

;

window.closeRedeemModal = function() {
  const overlay = document.getElementById('modal-redeem-token-overlay');
  if (overlay) {
    overlay.classList.remove('active');
    document.body.style.overflow = '';
  }
}

;

window.handleRedeemToken = async function(e) {
  e.preventDefault();
  const inputPhone = document.getElementById('input-redeem-phone');
  const inputCode = document.getElementById('input-redeem-code');
  const btn = document.getElementById('btn-submit-redeem');

  const phone = (inputPhone?.value || '').replace(/\D/g, '');
  const code = (inputCode?.value || '').trim().toUpperCase();

  if (!phone) return showDeployToast('Nomor WhatsApp bot wajib diisi!');
  if (!code) return showDeployToast('Kode token wajib diisi!');

  btn.disabled = true;
  btn.innerHTML = '<span>Mengklaim Token...</span>';

  try {
    const res = await safeDeployFetch('/api/deploy/redeem', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ phone, code })
    });

    closeRedeemModal();
    const msg = res.message || 'Token berhasil digunakan!';
    if (res.type === 'dual' || res.account?.allowDualAccount) {
      localStorage.setItem('af_allow_dual_account', '1');
    }
    alert('🎉 ' + msg);
    showDeployToast(msg);
    await refreshDeployStatus();
  } catch (err) {
    alert('❌ ' + err.message);
    showDeployToast(err.message);
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<span>🎁 Klaim Token Sekarang</span>';
  }
}

;

window.claimTokenFromDeployForm = async function() {
  const inputPhone = document.getElementById('web-deploy-phone');
  const inputToken = document.getElementById('web-deploy-token');
  const btn = document.getElementById('btn-quick-claim-token');

  let phone = (inputPhone?.value || '').replace(/\D/g, '');
  if (!phone) {
    phone = (localStorage.getItem('af_active_deploy_phone') || '').replace(/\D/g, '');
  }
  const code = (inputToken?.value || '').trim().toUpperCase();

  if (!phone) {
    if (inputPhone) inputPhone.focus();
    return showDeployToast('Masukkan nomor WhatsApp bot terlebih dahulu!');
  }
  if (!code) {
    if (inputToken) inputToken.focus();
    return showDeployToast('Masukkan kode token terlebih dahulu!');
  }

  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Mengklaim...';
  }

  try {
    const res = await safeDeployFetch('/api/deploy/redeem', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ phone, code })
    });

    if (inputToken) inputToken.value = '';
    const msg = res.message || 'Token berhasil digunakan!';
    if (res.type === 'dual' || res.account?.allowDualAccount) {
      localStorage.setItem('af_allow_dual_account', '1');
    }
    alert('🎉 ' + msg);
    showDeployToast(msg);
    await refreshDeployStatus();
  } catch (err) {
    alert('❌ ' + err.message);
    showDeployToast(err.message);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = 'Klaim Token';
    }
  }
}

;

// ==========================================================================
// LIVE TERMINAL BRAILLE SPINNER ANIMATION (PERSIS CONSOLE PANEL PTERODACTYL)
// ==========================================================================
const BRAILLE_SPINNER_FRAMES = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
let brailleFrameIdx = 0;
setInterval(() => {
  brailleFrameIdx = (brailleFrameIdx + 1) % BRAILLE_SPINNER_FRAMES.length;
  const currentFrame = BRAILLE_SPINNER_FRAMES[brailleFrameIdx];
  const spinners = document.querySelectorAll('.terminal-braille-live');
  for (let i = 0; i < spinners.length; i++) {
    spinners[i].textContent = currentFrame;
  }
}

, 80);

// ==========================================================================
// ACCESS GATE FITUR DEPLOY BOT (TERBUKA / PUBLIC BETA)
// ==========================================================================
let isPublicDeployMode = true; // Kunci dibuka penuh untuk Public Beta

function isDeployGateUnlocked() {
  return true;
}

window.initDeployGate = function() {
  const lockScreen = document.getElementById('deploy-lock-screen');
  const unlockedWorkspace = document.getElementById('deploy-unlocked-workspace');
  if (lockScreen) lockScreen.style.display = 'none';
  if (unlockedWorkspace) unlockedWorkspace.style.display = 'block';
  if (!deployPollingInterval) {
    deployPollingInterval = setInterval(refreshDeployStatus, 1200);
  }
}

;

window.verifyDeployKey = function() {
  const input = document.getElementById('deploy-lock-input');
  const errBox = document.getElementById('deploy-lock-error');
  const errText = document.getElementById('deploy-lock-error-text');
  const lockCard = document.querySelector('.deploy-lock-card');
  const lockScreen = document.getElementById('deploy-lock-screen');
  const unlockedWorkspace = document.getElementById('deploy-unlocked-workspace');

  if (!input) return;
  const val = (input.value || '').trim();

  if (!val) {
    if (errBox) {
      errBox.style.display = 'flex';
      if (errText) errText.textContent = 'Masukkan kunci akses deploy terlebih dahulu.';
    }
    input.focus();
    return;
  }

  // 1. Validasi kunci akses unik Farel (alvin01)
  if (val === 'alvin01') {
    try {
      localStorage.removeItem('af_deploy_access_key');
      sessionStorage.setItem('af_deploy_access_key', 'alvin01');
    } catch (e) {}

    fetch('/api/gate/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: val })
    }).catch(() => {});

    if (lockCard) lockCard.classList.add('gate-unlock-anim');

    setTimeout(() => {
      if (lockScreen) lockScreen.style.display = 'none';
      if (unlockedWorkspace) unlockedWorkspace.style.display = 'block';
      if (typeof showDeployToast === 'function') {
        showDeployToast('Akses Deploy Terverifikasi. Selamat datang!');
      }
      if (typeof refreshDeployStatus === 'function') {
        refreshDeployStatus();
      }
      if (!deployPollingInterval) {
        deployPollingInterval = setInterval(refreshDeployStatus, 1200);
      }
    }, 280);
    return;
  }

  // 2. Kunci salah
  if (errBox) {
    errBox.style.display = 'flex';
    if (errText) errText.textContent = 'Kunci akses salah! Akses ditolak.';
  }
  if (lockCard) {
    lockCard.classList.remove('gate-shake');
    void lockCard.offsetWidth; // Reflow
    lockCard.classList.add('gate-shake');
  }
  input.value = '';
  input.focus();
};

window.toggleDeployEye = function() {
  const input = document.getElementById('deploy-lock-input');
  const eyeIcon = document.getElementById('deploy-lock-eye-icon');
  if (!input) return;

  if (input.type === 'password') {
    input.type = 'text';
    if (eyeIcon) {
      eyeIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l18 18"/>';
    }
  } else {
    input.type = 'password';
    if (eyeIcon) {
      eyeIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>';
    }
  }
}

;

window.relockDeployGate = function() {
  try {
    localStorage.removeItem('af_deploy_access_key');
    sessionStorage.removeItem('af_deploy_access_key');
  } catch (e) {}

  if (deployPollingInterval) {
    clearInterval(deployPollingInterval);
    deployPollingInterval = null;
  }

  const lockScreen = document.getElementById('deploy-lock-screen');
  const unlockedWorkspace = document.getElementById('deploy-unlocked-workspace');
  const lockCard = document.querySelector('.deploy-lock-card');
  const input = document.getElementById('deploy-lock-input');
  const errBox = document.getElementById('deploy-lock-error');

  if (lockCard) {
    lockCard.classList.remove('gate-unlock-anim', 'gate-shake');
  }
  if (unlockedWorkspace) unlockedWorkspace.style.display = 'none';
  if (lockScreen) lockScreen.style.display = 'flex';
  if (input) {
    input.value = '';
    input.focus();
  }
  if (errBox) errBox.style.display = 'none';

  if (typeof showDeployToast === 'function') {
    showDeployToast('Fitur Deploy Bot berhasil dikunci kembali.');
  }
}

;

/* ==========================================================================
   VIEW 5: AF TOOLS HUB (DOWNLOADER & SHORTLINK BYPASSER) CLIENT LOGIC
   ========================================================================== */

window.checkToolsStatus = async function() {
  const dot = document.getElementById('tools-indicator-dot');
  const val = document.getElementById('tools-status-val');
  const serverText = document.getElementById('tools-server-type-text');
  const offlineNotice = document.getElementById('tools-offline-notice');
  const btnDlSubmit = document.getElementById('btn-dl-submit');
  const btnBypassSubmit = document.getElementById('btn-bypass-submit');
  if (!dot || !val) return;

  try {
    const res = await fetch('/api/fetch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ping: true })
    });
    const data = await res.json().catch(() => ({}));
    const isOnline = Boolean(data && data.status && data.active);

    window.__isToolsActive = isOnline;

    if (isOnline) {
      dot.className = 'status-indicator-dot online';
      val.className = 'status-badge-val online';
      val.textContent = '🟢 ON (Aktif)';
      if (serverText) {
        serverText.textContent = 'Layanan siap digunakan';
      }
      if (offlineNotice) offlineNotice.style.display = 'none';
      if (btnDlSubmit) {
        btnDlSubmit.disabled = false;
        btnDlSubmit.style.opacity = '1';
      }
      if (btnBypassSubmit) {
        btnBypassSubmit.disabled = false;
        btnBypassSubmit.style.opacity = '1';
      }
    } else {
      dot.className = 'status-indicator-dot offline';
      val.className = 'status-badge-val offline';
      val.textContent = '🔴 OFF';
      if (serverText) {
        serverText.textContent = 'Layanan sedang tidak aktif';
      }
      if (offlineNotice) {
        offlineNotice.style.display = 'flex';
      }
    }
  } catch (_) {
    window.__isToolsActive = false;
    dot.className = 'status-indicator-dot offline';
    val.className = 'status-badge-val offline';
    val.textContent = '🔴 OFF';
    if (serverText) {
      serverText.textContent = 'Layanan sedang tidak aktif';
    }
    if (offlineNotice) {
      offlineNotice.style.display = 'flex';
    }
  }
}

;

window.switchToolsSubTab = function(subTab) {
  const btnDownloader = document.getElementById('tab-btn-downloader');
  const btnBypass = document.getElementById('tab-btn-bypass');
  const viewDownloader = document.getElementById('subview-downloader');
  const viewBypass = document.getElementById('subview-bypass');

  if (subTab === 'bypass') {
    if (btnDownloader) btnDownloader.classList.remove('active');
    if (btnBypass) btnBypass.classList.add('active');
    if (viewDownloader) viewDownloader.classList.remove('active');
    if (viewBypass) viewBypass.classList.add('active');
  } else {
    if (btnBypass) btnBypass.classList.remove('active');
    if (btnDownloader) btnDownloader.classList.add('active');
    if (viewBypass) viewBypass.classList.remove('active');
    if (viewDownloader) viewDownloader.classList.add('active');
  }
}

;

window.clearDownloaderInput = function() {
  const input = document.getElementById('input-dl-url');
  const clearBtn = document.getElementById('btn-dl-clear');
  if (input) {
    input.value = '';
    input.focus();
  }
  if (clearBtn) clearBtn.style.display = 'none';
};

// Input event listener to show/hide clear button
document.addEventListener('DOMContentLoaded', () => {
  const dlInput = document.getElementById('input-dl-url');
  const clearBtn = document.getElementById('btn-dl-clear');
  if (dlInput && clearBtn) {
    dlInput.addEventListener('input', () => {
      clearBtn.style.display = dlInput.value.trim() ? 'inline-flex' : 'none';
    });
  }
}

);

window.pasteToDownloaderInput = async function() {
  const input = document.getElementById('input-dl-url');
  const clearBtn = document.getElementById('btn-dl-clear');
  if (!input) return;

  try {
    if (navigator.clipboard && navigator.clipboard.readText) {
      const text = await navigator.clipboard.readText();
      if (text && text.trim()) {
        input.value = text.trim();
        if (clearBtn) clearBtn.style.display = 'inline-flex';
        input.focus();
        if (typeof showToast === 'function') {
          showToast('success', 'Tautan berhasil ditempel dari clipboard!');
        }
        return;
      }
    }
  } catch (err) {
    console.warn('[Downloader] Clipboard read error:', err.message);
  }

  // Fallback focus jika izin clipboard ditolak browser
  input.focus();
  if (typeof showToast === 'function') {
    showToast('info', 'Tekan tahan pada kotak input lalu pilih Tempel/Paste.');
  }
}

;

window.pasteToBypassInput = async function() {
  const input = document.getElementById('input-bypass-url');
  if (!input) return;

  try {
    if (navigator.clipboard && navigator.clipboard.readText) {
      const text = await navigator.clipboard.readText();
      if (text && text.trim()) {
        input.value = text.trim();
        input.focus();
        if (typeof showToast === 'function') {
          showToast('success', 'Link shortlink berhasil ditempel!');
        }
        return;
      }
    }
  } catch (err) {
    console.warn('[Bypass] Clipboard read error:', err.message);
  }

  input.focus();
  if (typeof showToast === 'function') {
    showToast('info', 'Tekan tahan pada kotak input lalu pilih Tempel/Paste.');
  }
}

;

window.handleDownloaderSubmit = async function(event) {
  if (event && event.preventDefault) event.preventDefault();

  const input = document.getElementById('input-dl-url');
  const loading = document.getElementById('dl-loading');
  const resultBox = document.getElementById('dl-result-box');
  const submitBtn = document.getElementById('btn-dl-submit');

  if (!input) return;

  if (window.__isToolsActive === false) {
    if (typeof showToast === 'function') {
      showToast('error', 'Layanan sedang tidak aktif.');
    } else {
      alert('Layanan sedang tidak aktif.');
    }
    return;
  }

  const rawUrl = input.value.trim();

  if (!rawUrl) {
    if (typeof showToast === 'function') {
      showToast('warning', 'Masukkan link media atau berkas unduhan terlebih dahulu.');
    }
    input.focus();
    return;
  }

  if (resultBox) {
    resultBox.style.display = 'none';
    resultBox.innerHTML = '';
  }
  if (loading) {
    loading.style.display = 'flex';
    const isLikelyShortlink = /(?:sfl\.gl|sfl\.ink|safelinku|safelink|semawur|smw\.ms|duit\.cc|realsht|sub4unlock|sub2unlock|rekonise|boost\.ink|ouo\.io|shrinkme|bit\.ly|tinyurl|s\.id|cutt\.ly|linku\.to|coeg\.in)/i.test(rawUrl);
    const loadingText = loading.querySelector('span');
    if (loadingText) {
      loadingText.textContent = isLikelyShortlink 
        ? 'Mendeteksi Shortlink... Mengurai & melewati safelink...' 
        : 'Sedang mengekstrak media dari server...';
    }
  }
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.style.opacity = '0.6';
  }

  try {
    const response = await fetch('/api/fetch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: rawUrl })
    });

    const data = await response.json();

    if (loading) loading.style.display = 'none';
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.style.opacity = '1';
    }

    if (response.ok && data && data.status) {
      if (data.isBypassedOnly) {
        // Tautan adalah shortlink non-media yang berhasil di-bypass otomatis
        if (typeof window.switchToolsSubTab === 'function') {
          window.switchToolsSubTab('bypass');
        }
        const bypassInput = document.getElementById('input-bypass-url');
        if (bypassInput) bypassInput.value = data.originalUrl || rawUrl;
        renderBypassResult(data);
        if (typeof showToast === 'function') {
          showToast('success', 'Tautan shortlink berhasil dilewati! Tautan tujuan siap dibuka.');
        }
      } else {
        renderDownloaderResult(data);
        if (typeof showToast === 'function') {
          if (data.bypassedFrom) {
            showToast('success', 'Tautan shortlink berhasil di-bypass otomatis & media siap diunduh!');
          } else {
            showToast('success', 'Media berhasil diekstrak! Siap diunduh.');
          }
        }
      }
    } else {
      if (data && data.blockedByCloudflare) {
        if (typeof window.switchToolsSubTab === 'function') {
          window.switchToolsSubTab('bypass');
        }
        const bypassInput = document.getElementById('input-bypass-url');
        if (bypassInput) bypassInput.value = data.originalUrl || rawUrl;
        renderBypassCloudflareNotice(data);
      }
      const errMsg = (data && data.message) || 'Gagal mengekstrak media dari link yang diberikan.';
      if (typeof showToast === 'function') {
        showToast('error', errMsg);
      }
    }
  } catch (err) {
    if (loading) loading.style.display = 'none';
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.style.opacity = '1';
    }
    console.error('[Downloader] Fetch error:', err);
    if (typeof showToast === 'function') {
      showToast('error', 'Koneksi ke server gagal. Pastikan jaringan internet aktif.');
    }
  }
}

;

// Global Toast Bridge for AF Tools & Ecosystem
function showToast(type, msg) {
  if (typeof window.showDeployToast === 'function') {
    window.showDeployToast(msg, type);
  } else if (typeof window.showToastNotice === 'function') {
    window.showToastNotice(msg, type);
  } else {
    console.log(`[Toast] [${type}] ${msg}`);
  }
}window.showToast = showToast;

function getCleanQualityLabel(quality) {
  if (!quality) return 'Format';
  const clean = String(quality).trim();
  const m = clean.match(/^([^\(]+)/);
  if (m && m[1].trim().length > 0) {
    return m[1].trim();
  }
  return clean;
}

function renderDownloaderResult(data) {
  const resultBox = document.getElementById('dl-result-box');
  if (!resultBox) return;

  const platform = (data.platform || 'media').toUpperCase();
  const safeTitle = (data.title || 'af_downloader_media').replace(/"/g, '&quot;');
  const isArchive = data.type === 'file' || platform === 'MEDIAFIRE' || platform === 'SFILE';
  const rawFormats = Array.isArray(data.formats) ? data.formats : (Array.isArray(data.downloads) ? data.downloads : []);

  // Normalisasi seluruh opsi format
  const formats = [];
  if (rawFormats.length > 0) {
    rawFormats.forEach(fmt => {
      const isAudio = fmt.type === 'audio' || (fmt.quality && fmt.quality.toLowerCase().includes('audio')) || (fmt.ext && fmt.ext.toLowerCase() === 'mp3');
      formats.push({
        quality: fmt.quality || (isAudio ? 'Audio MP3' : 'Video HD'),
        url: fmt.url || fmt.download || '',
        size: fmt.size || fmt.filesize || '',
        type: isAudio ? 'audio' : 'video',
        ext: fmt.ext || (isAudio ? 'mp3' : 'mp4'),
        note: fmt.note || (isAudio ? 'Audio HQ' : (fmt.quality || 'Video Stream'))
      });
    });
  } else {
    if (data.video_nowatermark || data.video) {
      formats.push({
        quality: 'Video No-Watermark (HD)',
        url: data.video_nowatermark || data.video,
        size: data.size || '',
        type: 'video',
        ext: 'mp4',
        note: 'Ultra HD Clean'
      });
    }
    if (data.video_watermark) {
      formats.push({
        quality: 'Video Standard',
        url: data.video_watermark,
        size: '',
        type: 'video',
        ext: 'mp4',
        note: 'Standard Video'
      });
    }
    if (data.audio || data.music) {
      formats.push({
        quality: 'Audio MP3',
        url: data.audio || data.music,
        size: '',
        type: 'audio',
        ext: 'mp3',
        note: 'Audio Track Berkualitas'
      });
    }
    if (formats.length === 0 && (data.download || data.url)) {
      formats.push({
        quality: isArchive ? 'Berkas Arsip' : 'Media Siap Unduh',
        url: data.download || data.url,
        size: data.size || data.filesize || '',
        type: isArchive ? 'file' : 'video',
        ext: isArchive ? 'zip' : 'mp4',
        note: isArchive ? 'Direct File' : 'Default Stream'
      });
    }
  }

  // Simpan state aktif ke window
  window._currentDownloaderData = data;
  window._currentDownloaderFormats = formats;
  window._currentSelectedFormatIdx = 0;

  let html = '';

  if (isArchive) {
    // Mode Berkas Arsip (MediaFire / Sfile / ZIP / RAR)
    const activeFmt = formats[0] || { quality: 'Berkas Unduhan', url: data.download || data.url, size: data.size || data.filesize || '-' };
    const fileSize = activeFmt.size || data.size || data.filesize || '-';

    html = `
      <div class="tools-file-card uiverse-card-glow">
        <div class="tools-file-header">
          <div class="tools-file-icon">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
              <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
              <line x1="12" y1="22.08" x2="12" y2="12"/>
            </svg>
          </div>
          <div class="tools-file-info">
            <h4 class="tools-file-name">${escapeHtml(data.title || 'Berkas Unduhan')}</h4>
            <div class="tools-media-meta">
              <span class="tools-meta-badge platform">${escapeHtml(platform)}</span>
              ${data.bypassedFrom ? `<span class="tools-meta-badge" style="background:rgba(245,158,11,0.15); color:#FBBF24; border:1px solid rgba(245,158,11,0.3);">🛡️ Di-bypass otomatis</span>` : ''}
              <span class="tools-meta-badge">Ukuran: ${escapeHtml(fileSize)}</span>
              ${data.mime ? `<span class="tools-meta-badge">${escapeHtml(data.mime)}</span>` : ''}
            </div>
          </div>
        </div>

        <div class="tools-cta-action-panel">
          <div class="tools-cta-header">
            <div class="tools-cta-info">
              <span class="tools-cta-badge"><span class="tools-live-dot"></span> Berkas Terverifikasi</span>
              <span class="tools-cta-name" id="tools-cta-selected-name">${escapeHtml(data.title || 'Arsip Siap Unduh')}</span>
            </div>
            <span class="tools-cta-meta" id="tools-cta-selected-meta">${escapeHtml(fileSize)}</span>
          </div>

          <div class="tools-cta-btn-row">
            <button type="button" class="btn-download-now" id="btn-trigger-dl-now" onclick="window.triggerDownloaderDownload(this)">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                <polyline points="7 10 12 15 17 10"/>
                <line x1="12" y1="15" x2="12" y2="3"/>
              </svg>
              <span id="btn-dl-text">Unduh Berkas Sekarang (${escapeHtml(fileSize)})</span>
            </button>

            <button type="button" class="btn-copy-direct-link" onclick="window.copyDownloaderDirectLink()">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
              </svg>
              <span>Salin Link</span>
            </button>
          </div>
        </div>
      </div>
    `;
  } else {
    // Mode Streaming Media (YouTube, TikTok, Instagram, Facebook)
    const rawThumb = data.rawThumbnail || data.thumbnail || '';
    let safeThumb = '';
    if (rawThumb) {
      if (rawThumb.startsWith('/api/thumbnail') || rawThumb.startsWith('assets/')) {
        safeThumb = rawThumb;
      } else {
        safeThumb = `/api/thumbnail?url=${encodeURIComponent(rawThumb)}`;
      }
    }

    // Render Grid Kartu Format Interaktif
    let formatCardsHtml = '';
    formats.forEach((fmt, idx) => {
      const isSelected = idx === 0;
      const isAudio = fmt.type === 'audio';

      formatCardsHtml += `
        <button type="button" class="tools-format-card ${isSelected ? 'is-active' : ''}" id="fmt-card-${idx}" onclick="window.selectDownloaderFormat(${idx})" aria-selected="${isSelected ? 'true' : 'false'}">
          <div class="tools-fmt-left">
            <div class="tools-fmt-icon-box ${isAudio ? 'audio' : 'video'}">
              ${isAudio 
                ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>' 
                : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>'}
            </div>
            <div class="tools-fmt-texts">
              <span class="tools-fmt-title">${escapeHtml(fmt.quality)}</span>
              <span class="tools-fmt-sub">${escapeHtml(fmt.note || (isAudio ? 'Audio Track' : 'Video Stream'))}</span>
            </div>
          </div>
          <div class="tools-fmt-right">
            ${fmt.size ? `<span class="tools-fmt-size">${escapeHtml(fmt.size)}</span>` : ''}
            <div class="tools-fmt-radio">
              <div class="tools-fmt-radio-dot"></div>
            </div>
          </div>
        </button>
      `;
    });

    const initialFormat = formats[0] || { quality: 'Default', size: '', note: 'Siap Unduh' };
    const cleanInitQuality = getCleanQualityLabel(initialFormat.quality);

    html = `
      <div class="tools-media-card uiverse-card-glow">
        <div class="tools-thumb-box">
          <img src="${safeThumb}" alt="${safeTitle}" class="tools-thumb-img" referrerpolicy="no-referrer" loading="lazy" onerror="this.onerror=null;this.style.opacity='0.5';">
        </div>
        <div class="tools-media-details">
          <h4 class="tools-media-title">${escapeHtml(data.title || 'Media')}</h4>
          <div class="tools-media-meta">
            <span class="tools-meta-badge platform">${escapeHtml(platform)}</span>
            ${data.bypassedFrom ? `<span class="tools-meta-badge" style="background:rgba(245,158,11,0.15); color:#FBBF24; border:1px solid rgba(245,158,11,0.3);">🛡️ Di-bypass otomatis</span>` : ''}
            ${data.author ? `<span class="tools-meta-badge">Author: ${escapeHtml(data.author)}</span>` : ''}
            ${data.duration ? `<span class="tools-meta-badge">Durasi: ${escapeHtml(data.duration)}</span>` : ''}
          </div>

          <!-- Format Selection Section -->
          <div class="tools-format-selection-area">
            <div class="tools-format-header">
              <span class="tools-format-title">Pilih Format & Resolusi</span>
              <span class="tools-format-count-pill">${formats.length} Opsi</span>
            </div>

            <div class="tools-format-grid" id="tools-format-grid-box">
              ${formatCardsHtml}
            </div>
          </div>

          <!-- Dedicated Download CTA Panel -->
          <div class="tools-cta-action-panel" id="tools-dl-cta-panel">
            <div class="tools-cta-header">
              <div class="tools-cta-left">
                <span class="tools-cta-badge"><span class="tools-live-dot"></span> Pilihan Aktif</span>
                <span class="tools-cta-name" id="tools-cta-selected-name">${escapeHtml(initialFormat.quality)}</span>
              </div>
              <div class="tools-cta-right">
                <span class="tools-cta-meta" id="tools-cta-selected-meta">${escapeHtml(initialFormat.size || initialFormat.note || 'Siap Diunduh')}</span>
              </div>
            </div>

            <div class="tools-cta-btn-row">
              <button type="button" class="btn-download-now" id="btn-trigger-dl-now" onclick="window.triggerDownloaderDownload(this)">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                  <polyline points="7 10 12 15 17 10"/>
                  <line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
                <span id="btn-dl-text">⚡ Unduh Sekarang (${escapeHtml(cleanInitQuality)})</span>
              </button>

              <button type="button" class="btn-copy-direct-link" onclick="window.copyDownloaderDirectLink()">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                </svg>
                <span>Salin Link</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  resultBox.innerHTML = html;
  resultBox.style.display = 'flex';
  resultBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// Handler Pemilihan Format Resolusi
window.selectDownloaderFormat = function(idx) {
  const formats = window._currentDownloaderFormats;
  if (!formats || !formats[idx]) return;

  window._currentSelectedFormatIdx = idx;
  const selected = formats[idx];

  // Update status kartu format di UI
  const cards = document.querySelectorAll('.tools-format-card');
  cards.forEach((card, i) => {
    if (i === idx) {
      card.classList.add('is-active');
      card.setAttribute('aria-selected', 'true');
    } else {
      card.classList.remove('is-active');
      card.setAttribute('aria-selected', 'false');
    }
  });

  // Update ringkasan pada panel aksi CTA
  const nameEl = document.getElementById('tools-cta-selected-name');
  const metaEl = document.getElementById('tools-cta-selected-meta');
  const dlTextEl = document.getElementById('btn-dl-text');

  if (nameEl) nameEl.textContent = selected.quality;
  if (metaEl) metaEl.textContent = selected.size || selected.note || 'Siap Diunduh';
  if (dlTextEl) dlTextEl.textContent = `⚡ Unduh Sekarang (${getCleanQualityLabel(selected.quality)})`;

  // Reset status tombol unduh jika sebelumnya sedang preparing / success
  const ctaBtn = document.getElementById('btn-trigger-dl-now');
  if (ctaBtn) {
    ctaBtn.disabled = false;
    ctaBtn.classList.remove('is-preparing', 'is-success');
  }
}

;

// Handler Eksekusi Unduhan dengan Animasi & Visual State Feedback
window.triggerDownloaderDownload = function(btn) {
  const data = window._currentDownloaderData;
  const formats = window._currentDownloaderFormats;
  if (!data || !formats || formats.length === 0) {
    if (typeof showToast === 'function') showToast('error', 'Data unduhan tidak ditemukan. Silakan ekstrak tautan kembali.');
    return;
  }

  const idx = window._currentSelectedFormatIdx || 0;
  const selected = formats[idx] || formats[0];
  const directLink = selected.url;

  if (!directLink) {
    if (typeof showToast === 'function') showToast('error', 'Tautan unduhan format ini tidak valid.');
    return;
  }

  const isAudio = selected.type === 'audio';
  const isFile = selected.type === 'file' || data.type === 'file';
  const typeParam = isFile ? 'file' : (isAudio ? 'audio' : 'video');
  const downloadUrl = `/api/download?directUrl=${encodeURIComponent(directLink)}&title=${encodeURIComponent(data.title || 'media')}&type=${encodeURIComponent(typeParam)}&quality=${encodeURIComponent(selected.quality || '')}`;

  if (!btn) btn = document.getElementById('btn-trigger-dl-now');

  // 1. Loading State dengan Animasi Spinner
  if (btn) {
    btn.disabled = true;
    btn.classList.add('is-preparing');
    btn.innerHTML = `
      <div class="btn-dl-spinner"></div>
      <span>Menyiapkan Berkas...</span>
    `;
  }

  // Jeda 420ms untuk memberikan feedback animasi yang halus kepada pengguna
  setTimeout(() => {
    // Picu pengunduhan browser via temporary link
    const tempLink = document.createElement('a');
    tempLink.href = downloadUrl;
    tempLink.target = '_blank';
    tempLink.rel = 'noopener noreferrer';
    document.body.appendChild(tempLink);
    tempLink.click();
    setTimeout(() => {
      if (document.body.contains(tempLink)) document.body.removeChild(tempLink);
    }, 200);

    // 2. Success State Transisi
    if (btn) {
      btn.classList.remove('is-preparing');
      btn.classList.add('is-success');
      btn.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
        <span>Memulai Unduhan!</span>
      `;

      if (typeof showToast === 'function') {
        showToast('success', `Mengunduh: ${selected.quality}`);
      }

      // 3. Kembalikan ke State Normal setelah 2.2 detik
      setTimeout(() => {
        if (btn) {
          btn.disabled = false;
          btn.classList.remove('is-success');
          btn.innerHTML = `
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            <span id="btn-dl-text">⚡ Unduh Sekarang (${escapeHtml(getCleanQualityLabel(selected.quality))})</span>
          `;
        }
      }, 2200);
    }
  }, 420);
};

// Handler Salin Tautan Unduhan Langsung
window.copyDownloaderDirectLink = function() {
  const formats = window._currentDownloaderFormats;
  const idx = window._currentSelectedFormatIdx || 0;
  const selected = formats && formats[idx] ? formats[idx] : null;

  if (!selected || !selected.url) {
    if (typeof showToast === 'function') showToast('warning', 'Pilih format unduhan terlebih dahulu.');
    return;
  }

  const directUrl = selected.url;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(directUrl)
      .then(() => {
        if (typeof showToast === 'function') showToast('success', `Tautan ${selected.quality} disalin ke clipboard!`);
      })
      .catch(() => {
        promptDirectLink(directUrl);
      });
  } else {
    promptDirectLink(directUrl);
  }
}

;

function promptDirectLink(url) {
  window.prompt('Salin tautan unduhan berikut:', url);
  if (typeof showToast === 'function') showToast('info', 'Tautan unduhan ditampilkan.');
}

window.handleBypassSubmit = async function(event) {
  if (event && event.preventDefault) event.preventDefault();

  const input = document.getElementById('input-bypass-url');
  const loading = document.getElementById('bypass-loading');
  const resultBox = document.getElementById('bypass-result-box');
  const submitBtn = document.getElementById('btn-bypass-submit');

  if (!input) return;

  if (window.__isToolsActive === false) {
    if (typeof showToast === 'function') {
      showToast('error', 'Layanan sedang tidak aktif.');
    } else {
      alert('Layanan sedang tidak aktif.');
    }
    return;
  }

  const rawUrl = input.value.trim();

  if (!rawUrl) {
    if (typeof showToast === 'function') {
      showToast('warning', 'Masukkan link shortlink atau safelink terlebih dahulu.');
    }
    input.focus();
    return;
  }

  if (resultBox) {
    resultBox.style.display = 'none';
    resultBox.innerHTML = '';
  }
  if (loading) loading.style.display = 'flex';
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.style.opacity = '0.6';
  }

  try {
    const response = await fetch('/api/bypass', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: rawUrl })
    });

    const data = await response.json();

    if (loading) loading.style.display = 'none';
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.style.opacity = '1';
    }

    if (response.ok && data && data.status) {
      renderBypassResult(data);
      if (typeof showToast === 'function') {
        showToast('success', 'Shortlink berhasil dilewati!');
      }
    } else {
      const errMsg = (data && data.message) || 'Gagal melewati shortlink. Link mungkin memerlukan interaksi manual.';
      if (typeof showToast === 'function') {
        showToast('error', errMsg);
      }
      if (data && data.blockedByCloudflare) {
        renderBypassCloudflareNotice(data);
      }
    }
  } catch (err) {
    if (loading) loading.style.display = 'none';
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.style.opacity = '1';
    }
    console.error('[Bypass] Error:', err);
    if (typeof showToast === 'function') {
      showToast('error', 'Koneksi ke server bypass gagal. Silakan coba kembali.');
    }
  }
}

;

function renderBypassResult(data) {
  const resultBox = document.getElementById('bypass-result-box');
  if (!resultBox) return;

  const destUrl = data.destinationUrl || data.url || '';
  const hops = Array.isArray(data.chain) ? data.chain : [];
  const totalHops = data.totalHops || hops.length || 1;

  // Cek apakah link tujuan didukung oleh AF Downloader (MediaFire, Sfile, TikTok, YouTube, dll)
  let isDownloadable = false;
  try {
    const parsed = new URL(destUrl);
    const host = parsed.hostname.toLowerCase();
    if (
      host.includes('mediafire.com') ||
      host.includes('sfile.mobi') ||
      host.includes('sfile.co') ||
      host.includes('tiktok.com') ||
      host.includes('youtube.com') ||
      host.includes('youtu.be') ||
      host.includes('spotify.com') ||
      host.includes('spoti.fi') ||
      host.includes('instagram.com') ||
      host.includes('facebook.com')
    ) {
      isDownloadable = true;
    }
  } catch (_) {}

  // Rangkai daftar jejak multi-hop jika lebih dari 1 langkah
  let traceHtml = '';
  if (hops.length > 1) {
    const items = hops.map((h, i) => `
      <div class="bypass-trace-item">
        <span class="hop-num">${i + 1}</span>
        <span>${escapeHtml(h)}</span>
      </div>
    `).join('');

    traceHtml = `
      <div class="bypass-trace-box">
        <div class="bypass-trace-title">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
          <span>Alur Penembusan Safelink (${totalHops} Langkah / Hops):</span>
        </div>
        <div class="bypass-trace-list">
          ${items}
        </div>
      </div>
    `;
  }

  let handoffHtml = '';
  if (isDownloadable) {
    handoffHtml = `
      <button type="button" class="btn-handoff-dl" onclick="window.handoffToDownloader('${escapeHtml(destUrl)}')">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
        <span>⚡ Unduh Langsung di AF Downloader</span>
      </button>
    `;
  }

  const html = `
    <div class="tools-bypass-result-card">
      <div class="bypass-dest-box">
        <span class="bypass-dest-label">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
          <span>Tautan Tujuan Asli Berhasil Didapatkan:</span>
        </span>
        <div class="bypass-dest-input-row">
          <input type="text" id="bypass-dest-input" class="bypass-dest-input" value="${escapeHtml(destUrl)}" readonly>
          <button type="button" class="btn-bypass-copy" onclick="window.copyBypassDestination()">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
            <span id="btn-copy-label">Salin Link</span>
          </button>
        </div>
      </div>

      ${traceHtml}

      <div class="bypass-handoff-box">
        <a href="${destUrl}" target="_blank" rel="noopener noreferrer" class="btn-dl-download" style="background:#18212D; border-color:rgba(245,158,11,0.4); color:#FBBF24;">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
          <span>Buka di Tab Baru</span>
        </a>

        ${handoffHtml}

        <button type="button" class="btn-re-bypass" onclick="window.triggerReBypass('${escapeHtml(destUrl)}')">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>
          <span>Masih Shortlink? Bypass Lagi</span>
        </button>
      </div>
    </div>
  `;

  resultBox.innerHTML = html;
  resultBox.style.display = 'flex';
  resultBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function renderBypassCloudflareNotice(data) {
  const resultBox = document.getElementById('bypass-result-box');
  if (!resultBox) return;

  const targetUrl = data.originalUrl || data.destinationUrl || '';
  const isM2L = !!data.isMove2Link || /move2link\.(co|com|net)/i.test(targetUrl);

  let extraHtml = '';
  if (isM2L) {
    extraHtml = `
      <div style="margin-top: 14px; padding: 12px; background: rgba(30, 41, 59, 0.7); border: 1px dashed rgba(245, 158, 11, 0.4); border-radius: 8px;">
        <div style="display: flex; align-items: center; gap: 8px; font-weight: 600; color: #FCD34D; font-size: 0.88rem;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
          <span>Cara Cepat Bypass Move2link (2 Langkah):</span>
        </div>
        <ol style="margin: 8px 0 0 18px; padding: 0; font-size: 0.82rem; color: #CBD5E1; line-height: 1.6;">
          <li>Klik <strong>"1. Buka Verifikasi di Browser"</strong> di bawah (selesaikan verifikasi Turnstile ~1 detik).</li>
          <li>Setelah terbuka & dialihkan ke halaman artikel (<code>siendu.com</code>), <strong>salin link dari address bar peramban kamu</strong> dan tempel di kotak input AGAAHOST untuk langsung mendapatkan link download MediaFire tanpa iklan & tanpa tunggu!</li>
        </ol>
      </div>
    `;
  }

  const html = `
    <div class="tools-bypass-result-card" style="border-color: rgba(245, 158, 11, 0.4); background: rgba(245, 158, 11, 0.05);">
      <div class="bypass-dest-box">
        <span class="bypass-dest-label" style="color: #FBBF24;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
          <strong style="font-size:0.95rem;">Terproteksi Cloudflare Turnstile</strong>
        </span>
        <p style="margin: 8px 0 12px; font-size: 0.86rem; color: #94A3B8; line-height: 1.5;">
          ${escapeHtml(data.message || 'Domain shortlink ini dilindungi oleh Cloudflare Anti-Bot pada server cloud. Silakan buka tautan langsung di peramban kamu.')}
        </p>
        <div class="bypass-dest-input-row">
          <input type="text" id="bypass-dest-input" class="bypass-dest-input" value="${escapeHtml(targetUrl)}" readonly>
          <button type="button" class="btn-bypass-copy" onclick="window.copyBypassDestination()">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
            <span id="btn-copy-label">Salin Link</span>
          </button>
        </div>
        ${extraHtml}
      </div>
      <div class="bypass-handoff-box" style="margin-top: 12px;">
        <a href="${escapeHtml(targetUrl)}" target="_blank" rel="noopener noreferrer" class="btn-dl-download" style="background:#18212D; border-color:rgba(245,158,11,0.5); color:#FBBF24;">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
          <span>${isM2L ? '1. Buka Verifikasi di Browser' : 'Buka Langsung di Browser'}</span>
        </a>
      </div>
    </div>
  `;

  resultBox.innerHTML = html;
  resultBox.style.display = 'flex';
  resultBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

window.copyBypassDestination = function() {
  const input = document.getElementById('bypass-dest-input');
  const label = document.getElementById('btn-copy-label');
  if (!input) return;

  input.select();
  input.setSelectionRange(0, 99999);

  try {
    navigator.clipboard.writeText(input.value);
    if (label) label.textContent = 'Tersalin!';
    setTimeout(() => {
      if (label) label.textContent = 'Salin Link';
    }, 2500);
    if (typeof showToast === 'function') {
      showToast('success', 'Tautan asli disalin ke clipboard!');
    }
  } catch (_) {
    document.execCommand('copy');
    if (label) label.textContent = 'Tersalin!';
    setTimeout(() => {
      if (label) label.textContent = 'Salin Link';
    }, 2500);
  }
}

;

window.handoffToDownloader = function(destUrl) {
  if (!destUrl) return;

  // Beralih ke sub-tab downloader
  window.switchToolsSubTab('downloader');

  const input = document.getElementById('input-dl-url');
  const clearBtn = document.getElementById('btn-dl-clear');
  if (input) {
    input.value = destUrl;
    if (clearBtn) clearBtn.style.display = 'inline-flex';
  }

  if (typeof showToast === 'function') {
    showToast('info', 'Tautan dialihkan ke AF Downloader...');
  }

  // Otomatis trigger submit fetch
  window.handleDownloaderSubmit(new Event('submit'));
};

window.triggerReBypass = function(destUrl) {
  if (!destUrl) return;

  const input = document.getElementById('input-bypass-url');
  if (input) {
    input.value = destUrl;
  }

  if (typeof showToast === 'function') {
    showToast('info', 'Mengeksekusi penembusan shortlink lanjutan...');
  }

  window.handleBypassSubmit(new Event('submit'));
};

// Helper escape HTML untuk proteksi XSS
function escapeHtml(text) {
  if (typeof text !== 'string') return '';
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// ============================================================================
// MODAL PEMBAYARAN RESMI AGAAHOST (QRIS ALL PAYMENT & DANA TRANSFER)
// ============================================================================
window.openPaymentModal = function(defaultTab = 'all') {
  const overlay = document.getElementById('modal-payment-overlay');
  if (overlay) {
    if (typeof window.switchPaymentTab === 'function') {
      window.switchPaymentTab(defaultTab);
    }
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
};

window.closePaymentModal = function() {
  const overlay = document.getElementById('modal-payment-overlay');
  if (overlay) {
    overlay.classList.remove('active');
    document.body.style.overflow = '';
  }
};

window.switchPaymentTab = function(tab = 'all') {
  const cardQris = document.getElementById('payment-card-qris');
  const cardDana = document.getElementById('payment-card-dana');
  const btnAll = document.getElementById('tab-payment-all');
  const btnQris = document.getElementById('tab-payment-qris');
  const btnDana = document.getElementById('tab-payment-dana');

  const tabs = [
    { id: 'all', btn: btnAll },
    { id: 'qris', btn: btnQris },
    { id: 'dana', btn: btnDana }
  ];

  tabs.forEach(t => {
    if (!t.btn) return;
    const isActive = t.id === tab;
    t.btn.classList.toggle('active', isActive);
    if (isActive) {
      t.btn.style.background = '#22C55E';
      t.btn.style.color = '#000';
    } else {
      t.btn.style.background = 'transparent';
      t.btn.style.color = '#94A3B8';
    }
  });

  if (cardQris) {
    cardQris.style.display = (tab === 'all' || tab === 'qris') ? 'block' : 'none';
  }
  if (cardDana) {
    cardDana.style.display = (tab === 'all' || tab === 'dana') ? 'block' : 'none';
  }
};

window.copyDanaNumber = async function() {
  const danaNum = '085879220690';
  let copied = false;

  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(danaNum);
      copied = true;
    }
  } catch (_) {}

  if (!copied) {
    try {
      const tempInput = document.createElement('input');
      tempInput.value = danaNum;
      tempInput.style.position = 'fixed';
      tempInput.style.opacity = '0';
      document.body.appendChild(tempInput);
      tempInput.select();
      document.execCommand('copy');
      document.body.removeChild(tempInput);
      copied = true;
    } catch (_) {}
  }

  const label = document.getElementById('copy-dana-label');
  const btn = document.getElementById('btn-copy-dana');
  const origText = label ? label.textContent : 'Salin Nomor';
  if (label) {
    label.textContent = '✓ Tersalin!';
    if (btn) {
      btn.style.background = 'rgba(34, 197, 94, 0.3)';
      btn.style.borderColor = '#22C55E';
    }
    setTimeout(() => {
      label.textContent = origText;
      if (btn) {
        btn.style.background = 'rgba(34, 197, 94, 0.15)';
        btn.style.borderColor = 'rgba(34, 197, 94, 0.4)';
      }
    }, 2500);
  }

  if (typeof showToast === 'function') {
    showToast('success', `Nomor DANA ${danaNum} (A/N S.M) disalin ke clipboard!`);
  } else if (typeof showDeployToast === 'function') {
    showDeployToast(`Nomor DANA ${danaNum} berhasil disalin!`, 'success');
  }
};

// Listener klik di luar modal sheet untuk menutup payment modal
document.addEventListener('click', (e) => {
  const paymentOverlay = document.getElementById('modal-payment-overlay');
  if (paymentOverlay && e.target === paymentOverlay) {
    window.closePaymentModal();
  }
});





