# AGAAHOST — Cartoon + QRIS Otomatis

## Jalankan
1. Salin `.env.example` menjadi environment variable (atau Startup Variables di Pterodactyl):
   - `ELAINA_API_KEY` — API key Elaina (JANGAN ditaruh di file frontend)
   - `ELAINA_WEBHOOK_SECRET` — secret dari menu API Keys Elaina
   - `PUBLIC_URL=https://agaahostt.my.id`
2. `node server.js` (Node.js 18+, tanpa npm install)

## Daftarkan webhook
Di dashboard Elaina → API Keys → Webhook Notifikasi, isi:
`https://agaahostt.my.id/api/elaina/webhook` lalu Simpan & Verifikasi.
Webhook wajib HTTPS dan IP publik.

## Alur QRIS
Checkout → pilih "QRIS (All Payment)" → server membuat transaksi (harga diambil dari products.json) → QR tampil → browser cek status tiap 4 detik → LUNAS otomatis.
QRIS statis/manual sudah dihapus. DANA tetap manual.
