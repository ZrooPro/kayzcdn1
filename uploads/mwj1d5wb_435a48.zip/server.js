/**
 * AGAAHOST — Server
 * 1. Melayani file statis (index.html, css, js, images)
 * 2. QRIS otomatis per pesanan via Elaina Payment H2H API
 *    - POST /api/qris/create        → buat transaksi (harga dihitung di server)
 *    - GET  /api/qris/status/:id    → cek status ke Elaina (polling dari browser)
 *    - POST /api/elaina/webhook     → notifikasi otomatis dari Elaina (HMAC-SHA256)
 *
 * Node.js >= 18. Tanpa dependensi npm.
 * API key HANYA dibaca dari environment variable, tidak pernah dikirim ke browser.
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const ROOT = __dirname;
const PORT = Number(process.env.PORT) || 3000;
const PUBLIC_URL = (process.env.PUBLIC_URL || 'https://agaahostt.my.id').replace(/\/+$/, '');
const ELAINA_BASE = (process.env.ELAINA_BASE_URL || 'https://elainapg.my.id').replace(/\/+$/, '');
const API_KEY = (process.env.ELAINA_API_KEY || '').trim();
const WEBHOOK_SECRET = (process.env.ELAINA_WEBHOOK_SECRET || '').trim();
const ORDERS_FILE = path.join(ROOT, 'data', 'orders.json');
const PRODUCTS_FILE = path.join(ROOT, 'js', 'products.json');
const FETCH_TIMEOUT_MS = 15000;
const CREATE_LIMIT_PER_MIN = 10;

const FINAL_STATES = new Set(['paid', 'expired', 'canceled']);
const EVENT_TO_STATE = {
  'payment.success': 'paid',
  'payment.expired': 'expired',
  'payment.canceled': 'canceled',
};

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

// ---------------------------------------------------------------------------
// Penyimpanan order sederhana (JSON file) agar tidak hilang saat restart
// ---------------------------------------------------------------------------
const orders = new Map();
const processedDeliveries = new Set();

function loadOrders() {
  try {
    const raw = JSON.parse(fs.readFileSync(ORDERS_FILE, 'utf8'));
    for (const o of raw.orders || []) orders.set(o.orderId, o);
    for (const d of raw.deliveries || []) processedDeliveries.add(d);
  } catch (_) { /* file belum ada */ }
}

function saveOrders() {
  try {
    fs.mkdirSync(path.dirname(ORDERS_FILE), { recursive: true });
    const tmp = ORDERS_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify({
      orders: [...orders.values()].slice(-2000),
      deliveries: [...processedDeliveries].slice(-5000),
    }));
    fs.renameSync(tmp, ORDERS_FILE);
  } catch (err) {
    console.error('[orders] gagal menyimpan:', err.message);
  }
}

loadOrders();

// ---------------------------------------------------------------------------
// Helper
// ---------------------------------------------------------------------------
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function readBody(req, limit = 64 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(new HttpError(413, 'Body terlalu besar'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

async function readJson(req, limit) {
  const buf = await readBody(req, limit);
  try {
    return JSON.parse(buf.toString('utf8') || '{}');
  } catch (_) {
    throw new HttpError(400, 'JSON tidak valid');
  }
}

function clientIp(req) {
  return (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || 'unknown';
}

const createHits = new Map();
function allowCreate(ip) {
  const now = Date.now();
  const hits = (createHits.get(ip) || []).filter((t) => now - t < 60_000);
  if (hits.length >= CREATE_LIMIT_PER_MIN) {
    createHits.set(ip, hits);
    return false;
  }
  hits.push(now);
  createHits.set(ip, hits);
  return true;
}

function loadProducts() {
  return JSON.parse(fs.readFileSync(PRODUCTS_FILE, 'utf8'));
}

/** Panggil Elaina API. Mengembalikan isi `data` dari envelope {code, success, data}. */
async function elainaRequest(urlPath, init = {}) {
  if (!API_KEY) {
    throw new HttpError(503, 'Pembayaran QRIS belum aktif (ELAINA_API_KEY belum diatur di server).');
  }
  let r;
  try {
    r = await fetch(ELAINA_BASE + urlPath, {
      ...init,
      headers: {
        Authorization: `Bearer ${API_KEY}`,
        Accept: 'application/json',
        'Content-Type': 'application/json',
        ...(init.headers || {}),
      },
      signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
    });
  } catch (err) {
    throw new HttpError(502, 'Gagal menghubungi server pembayaran. Coba lagi sebentar.');
  }
  const text = await r.text();
  let json = null;
  try { json = JSON.parse(text); } catch (_) { /* bukan JSON */ }

  if (r.status === 429) throw new HttpError(429, 'Terlalu banyak permintaan ke server pembayaran. Coba lagi sebentar.');
  if (!r.ok || !json || json.success === false) {
    const msg = (json && (json.message || json.error)) || `Server pembayaran merespons HTTP ${r.status}`;
    console.error('[elaina]', r.status, urlPath, msg);
    throw new HttpError(502, msg);
  }
  return json.data !== undefined ? json.data : json;
}

function normalizeState(status) {
  const s = String(status || '').toLowerCase();
  if (s === 'completed' || s === 'success' || s === 'paid') return 'paid';
  if (s === 'expired') return 'expired';
  if (s === 'canceled' || s === 'cancelled') return 'canceled';
  return 'pending';
}

function publicOrder(o) {
  return {
    orderId: o.orderId,
    productName: o.productName,
    variantName: o.variantName,
    buyerName: o.buyerName,
    amount: o.amount,
    fee: o.fee,
    totalPayment: o.totalPayment,
    status: o.status,
    qrisData: o.qrisData,
    paymentUrl: o.paymentUrl,
    expiredAt: o.expiredAt,
    createdAt: o.createdAt,
    paidAt: o.paidAt || null,
  };
}

// ---------------------------------------------------------------------------
// Route: buat transaksi QRIS
// ---------------------------------------------------------------------------
async function handleCreate(req, res) {
  if (!allowCreate(clientIp(req))) {
    return sendJson(res, 429, { error: 'Terlalu sering membuat pesanan. Tunggu 1 menit.' });
  }

  const body = await readJson(req, 16 * 1024);
  const products = loadProducts();
  const product = products.find((p) => p.id === body.productId);
  if (!product) throw new HttpError(400, 'Produk tidak ditemukan');

  // Harga SELALU diambil dari products.json di server, bukan dari browser
  const variants = Array.isArray(product.variants) ? product.variants : [];
  const variant = variants.find((v) => v.id === body.variantId) || variants[0] || null;
  const price = variant ? variant.price : product.price;
  const amount = Math.round(Number(price));
  if (!Number.isFinite(amount) || amount <= 0) throw new HttpError(400, 'Harga produk tidak valid');

  const buyerName = String(body.buyerName || '').replace(/[\u0000-\u001F]/g, '').trim().slice(0, 60);
  if (!buyerName) throw new HttpError(400, 'Nama pemesan wajib diisi');

  const orderId = 'AGA-' + Date.now().toString(36).toUpperCase() + '-' + crypto.randomBytes(3).toString('hex').toUpperCase();

  const data = await elainaRequest('/api/v1/transaction/create', {
    method: 'POST',
    body: JSON.stringify({ amount, order_id: orderId }),
  });

  const record = {
    orderId,
    productId: product.id,
    productName: product.name,
    variantName: variant ? variant.name : '',
    buyerName,
    notes: String(body.notes || '').slice(0, 200),
    amount: data.amount ?? amount,
    fee: data.fee ?? 0,
    totalPayment: data.total_payment ?? amount + (data.fee ?? 0),
    status: 'pending',
    qrisData: data.qris_data || '',
    paymentUrl: data.payment_url || '',
    expiredAt: data.expired_at || '',
    createdAt: new Date().toISOString(),
    paidAt: null,
  };
  orders.set(orderId, record);
  saveOrders();

  sendJson(res, 200, { success: true, order: publicOrder(record) });
}

// ---------------------------------------------------------------------------
// Route: cek status (polling dari browser)
// ---------------------------------------------------------------------------
async function handleStatus(req, res, orderId) {
  if (!/^[A-Za-z0-9-]{3,64}$/.test(orderId)) throw new HttpError(400, 'Order ID tidak valid');
  const record = orders.get(orderId);
  if (!record) throw new HttpError(404, 'Pesanan tidak ditemukan');

  if (!FINAL_STATES.has(record.status)) {
    const data = await elainaRequest('/api/v1/transaction/status/' + encodeURIComponent(orderId));
    const next = normalizeState(data.status);
    if (next !== record.status) {
      record.status = next;
      if (next === 'paid') record.paidAt = new Date().toISOString();
      saveOrders();
    }
  }
  sendJson(res, 200, { success: true, order: publicOrder(record) });
}

// ---------------------------------------------------------------------------
// Route: webhook Elaina
// ---------------------------------------------------------------------------
function safeEqualHex(a, b) {
  const ba = Buffer.from(a, 'utf8');
  const bb = Buffer.from(b, 'utf8');
  return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
}

async function handleWebhook(req, res) {
  const raw = await readBody(req, 256 * 1024);
  let payload;
  try { payload = JSON.parse(raw.toString('utf8')); } catch (_) {
    return sendJson(res, 400, { error: 'JSON tidak valid' });
  }

  // Handshake saat endpoint didaftarkan: echo balik nilai challenge
  if (payload && payload.challenge !== undefined && !payload.event) {
    return sendJson(res, 200, { challenge: payload.challenge });
  }

  if (!WEBHOOK_SECRET) {
    console.error('[webhook] ELAINA_WEBHOOK_SECRET belum diatur, request ditolak');
    return sendJson(res, 503, { error: 'Webhook belum dikonfigurasi' });
  }
  const sigHeader = String(req.headers['x-elaina-signature'] || '');
  const expected = 'sha256=' + crypto.createHmac('sha256', WEBHOOK_SECRET).update(raw).digest('hex');
  if (!safeEqualHex(sigHeader, expected)) {
    return sendJson(res, 401, { error: 'Invalid signature' });
  }

  const deliveryId = String(payload.delivery_id || req.headers['x-elaina-delivery'] || '');
  if (deliveryId && processedDeliveries.has(deliveryId)) {
    return sendJson(res, 200, { ok: true, duplicate: true });
  }

  const nextState = EVENT_TO_STATE[payload.event];
  const orderId = payload.data && payload.data.order_id;
  const record = orderId && orders.get(orderId);
  if (record && nextState && !FINAL_STATES.has(record.status)) {
    record.status = nextState;
    if (nextState === 'paid') record.paidAt = new Date().toISOString();
  }
  if (deliveryId) processedDeliveries.add(deliveryId);
  saveOrders();
  sendJson(res, 200, { ok: true });
}

// ---------------------------------------------------------------------------
// Static files
// ---------------------------------------------------------------------------
const BLOCKED = /^\/(data|node_modules|\.env|server\.js|package(-lock)?\.json|README\.md)/i;

function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  if (BLOCKED.test(rel)) { res.writeHead(404); return res.end('Not found'); }

  const filePath = path.normalize(path.join(ROOT, rel));
  if (!filePath.startsWith(ROOT + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }

  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); return res.end('Not found'); }
    const type = MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': type,
      'Content-Length': st.size,
      'Cache-Control': type.startsWith('text/html') ? 'no-cache' : 'public, max-age=300',
      'X-Content-Type-Options': 'nosniff',
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(filePath).pipe(res);
  });
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const { pathname } = url;
  try {
    if (pathname.startsWith('/api/')) {
      if (pathname === '/api/qris/create' && req.method === 'POST') return await handleCreate(req, res);

      const statusMatch = pathname.match(/^\/api\/qris\/status\/([^/]+)$/);
      if (statusMatch && req.method === 'GET') return await handleStatus(req, res, statusMatch[1]);

      if (pathname === '/api/elaina/webhook' && req.method === 'POST') return await handleWebhook(req, res);

      // Telemetri & notifikasi lama dari frontend: cukup diterima tanpa efek
      if ((pathname === '/api/visitor-log' || pathname === '/api/order-notify') && req.method === 'POST') {
        await readBody(req, 16 * 1024).catch(() => {});
        res.writeHead(204);
        return res.end();
      }
      return sendJson(res, 404, { error: 'Endpoint tidak ditemukan' });
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405); return res.end();
    }
    return serveStatic(req, res, pathname);
  } catch (err) {
    if (err instanceof HttpError) return sendJson(res, err.status, { error: err.message });
    console.error('[server]', err);
    return sendJson(res, 500, { error: 'Terjadi kesalahan di server' });
  }
});

server.listen(PORT, () => {
  console.log(`AGAAHOST berjalan di port ${PORT}`);
  if (!API_KEY) console.warn('PERINGATAN: ELAINA_API_KEY kosong — QRIS otomatis tidak aktif.');
  if (!WEBHOOK_SECRET) console.warn('PERINGATAN: ELAINA_WEBHOOK_SECRET kosong — webhook akan ditolak.');
  console.log(`Daftarkan webhook di Elaina: ${PUBLIC_URL}/api/elaina/webhook`);
});
